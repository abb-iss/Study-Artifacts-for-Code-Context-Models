To try out Freemind map sharing via Jabber servers:


1. Install freemind to two PCs.

On PC number 1:

2. Start Freemind.
3. Select "File -> New" to create a new, blank mind map.
4. Go to 'File -> Share'.
5. Enter the following:

Server Name: jabbermind.servequake.com
Username:    user-a
Password:    password

6. Click 'Next'.

7. Select the option "Wait for another user to share a map" and click "Next".

The window title should now be "Freemind - Connected". 


On PC number 2:

8. Start Freemind.
9. Select "File -> New" to create a new, blank mind map.
10. Go to 'File -> Share'.
11. Enter the following:

Server Name: jabbermind.servequake.com
Username:    user-b
Password:    password

12. Click 'Next'.

13. Select the option "Share this map with another user" (the default) and click "Next".

14. Enter the username 'user-a@jabbermind.servequake.com' and click "Next". 

The 'Waiting for user to accept invitation to share map...' message appears.

On PC number 1:

The message 'user-b@jabbermind.servequake.com wants to share a map with you.' appears.

15. Select "Accept".

On PC number 2:

The message 'You are now sharing the current map with user-a@jabbermind.servequake.com' appears.

16. Click "Close". 

Now, the maps are shared and you can edit them together.

Note, that you don't have to start with a blank map. 


To disconnect from the Jabber server, go to "File -> Stop Sharing".

Good luck.

Robert


