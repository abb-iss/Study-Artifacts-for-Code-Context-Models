<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#ff0000" CREATED="1124560950701" ID="ID_911274459" MODIFIED="1228309505186">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body width="">
    <p align="center">
      FreeMind<br /><small>- free mind mapping software -</small>&#160;
    </p>
    <p align="center">
      <font size="2">translated by Jan Kr&#252;mmel </font>
    </p>
    <p align="center">
      <font size="2">0.9.0 b20</font>
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="Dialog" SIZE="18"/>
<node CREATED="1124560950701" ID="ID_1120116737" LINK="http://freemind.sourceforge.net" MODIFIED="1224486501603" POSITION="left" TEXT="FreeMind&apos;s Hjemmeside">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1091417446" MODIFIED="1227780198462" POSITION="left" TEXT="Key mappings tabel">
<node CREATED="1124560950701" ID="ID_1069493165" MODIFIED="1225372850667">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fil kommandoer:<br />Ny map&#160;&#160;&#160; &#160;&#160;&#160;- Ctrl+N<br />&#197;bn map&#160;&#160; &#160;&#160;&#160;- Ctrl+O<br />Gem map&#160;&#160; &#160;&#160;&#160;- Ctrl+S<br />Gem som&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+A<br />Udskriv&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+P<br />Luk&#160;&#160;&#160;&#160; &#160;&#160;&#160; &#160;- Ctrl+W<br />Afslut&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+Q<br />Forrige map - Ctrl+LEFT<br />N&#230;ste Map&#160;&#160;&#160;&#160;- Ctrl+RIGHT<br />Exporter fil til HTML&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+E<br />Exporter branch til HTML&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+H<br />Exporter branch til ny MM fil - Alt+A<br />&#197;ben f&#248;rste fil i historik &#160;&#160;&#160;- Ctrl+Shift+W<br /><br />Rediger kommandoer:<br />Find&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160;- Ctrl+F<br />Find n&#230;ste&#160; &#160;- Ctrl+G<br />Klip&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160;- Ctrl+X<br />Kopier&#160;&#160;&#160;&#160;&#160; &#160;- Ctrl+C<br />Kopier single - Ctrl+Y<br />Inds&#230;t&#160;&#160;&#160;&#160; &#160; &#160;- Ctrl+V<br /><br />Mode kommandoer:<br />MindMap mode - Alt+1<br />Browse mode&#160;&#160;- Alt+2&#160;<br />Fil mode&#160;&#160;&#160; &#160;- Alt+3<br /><br />Node formatterings kommandoer:<br />Italicize&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160;&#160; - Ctrl+I<br />Fed &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160;&#160;- Ctrl+B<br />Sky &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160;&#160;&#160; &#160;&#160;- Ctrl+Shift+B<br />&#198;ndre node farve &#160; &#160;&#160;&#160;&#160;&#160; &#160;&#160;&#160;- Alt+C<br />Blend node color&#160;&#160;&#160;&#160;&#160;&#160;&#160; &#160; &#160;&#160;- Alt+B<br />&#198;ndre node kant farve &#160; &#160;&#160; &#160;- Alt+E<br />For&#248;ge node skriftst&#248;rrelse&#160;&#160;- Ctrl+L<br />Mindske node skriftst&#248;rrelse&#160;- Ctrl+M<br />Increase branch font size - Ctrl+Shift+L<br />Decrease branch font size - Ctrl+Shift+M<br /><br />Node navigation commands:<br />Go to root&#160;&#160;- ESCAPE<br />Move up&#160;&#160;&#160;&#160;&#160;- UP<br />Move down&#160;&#160;&#160;- DOWN<br />Move left&#160;&#160;&#160;- LEFT<br />Move right&#160;&#160;- RIGHT<br />Follow link - Ctrl+ENTER<br />Zoom out&#160;&#160;&#160;&#160;- Alt+UP<br />Zoom in&#160;&#160;&#160;&#160;&#160;- Alt+DOWN<br /><br />Ny node kommandoer:<br />Add sibling node&#160;&#160;&#160;- ENTER<br />Add child node&#160;&#160;&#160;&#160;&#160;- INSERT<br />Add sibling before - Shift+ENTER<br /><br />Node redigerings kommandoer:<br />Rediger valgte node&#160;&#160;&#160;&#160;&#160;&#160;&#160;- F2<br />Rediger lang node&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+ENTER<br />Join noder&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+J<br />Toggle folded&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- SPACE<br />Toggle children folded&#160;&#160;&#160;&#160;- Ctrl+SPACE<br />Set link by filechooser&#160;&#160;&#160;- Ctrl+Shift+K<br />Set link by text entry&#160;&#160;&#160;&#160;- Ctrl+K<br />Set image by filechooser&#160;&#160;- Alt+K<br />Flyt node op&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+UP<br />Flyt node ned &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+DOWN<br />
    </p>
  </body>
</html></richcontent>
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node COLOR="#006633" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_904501221" MODIFIED="1227780203521" POSITION="left" TEXT="Installation">
<node COLOR="#006699" CREATED="1124560950701" ID="_Freemind_Link_1911559485" MODIFIED="1124560950701" TEXT="Links">
<node CREATED="1124560950701" ID="ID_1620747952" LINK="http://java.sun.com/javase/downloads/index.jsp" MODIFIED="1225872396859" TEXT="Download Java Runtime Environment (mindst J2RE1.4)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1612101865" LINK="http://freemind.sourceforge.net/wiki/index.php/Download#Download" MODIFIED="1225872422718" TEXT="Download Applikationen(Freemind)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_139664576" MODIFIED="1226050702015">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at installere FreeMind p&#229; <b>Microsoft Windows</b>, installer Java fra Sun og install FreeMind ved brug af FreeMind installer.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1380352758" LINK="http://freemind.sourceforge.net/wiki/index.php/FreeMind_on_Linux" MODIFIED="1226051125792">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at installere FreeMind p&#229; <b>Linux</b> eller <b>unix</b>, download Java Runtime Environment samt selve FreeMind applikationen. Installer f&#248;rst Java, udpak derefter FreeMind. For at k&#248;re FreeMind, eksekver freemind.sh.
    </p>
    <p>
      
    </p>
    <p>
      Log p&#229; som ROOT for at installere Freemind lokalt og g&#248;r f&#248;lgende:
    </p>
    <pre># mkdir -p /usr/local/share/freemind  <i>(opretter en mappe til freemind applikationen)</i>
# unzip freemind*.zip -d /usr/local/share/freemind  <i>(unzipper freemind til mappen)</i>
# chmod +x /usr/local/share/freemind/freemind.sh  <i>(g&#248;r at freemind kan eksekveres)</i>
# ln -s /usr/local/share/freemind/freemind.sh /usr/local/bin/freemind  <i>(laver et symbolsk link til freemind)</i></pre>
    <p>
      Dette vil kopiere indholdet af .zip filen til <tt>/usr/local/share/freemind</tt> og oprette et symbolsk link til FreeMind scriptet i t /usr/local/bin mappen.
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <h4>
      <font size="5">Ubuntu &amp; Kubuntu</font>
    </h4>
    <h5>
      <font size="3">Easiest method (tested under Gutsy Gibbon) </font>
    </h5>
    <p>
      <font size="3">This is how to install the most-recently-packaged version of FreeMind. Start the Synaptic Package Manager (under the System menu), and then do the following: </font>
    </p>
    <ul>
      <li>
        <font size="3">Add the following repositories using the Menu <tt>Settings &#8658; Repositories</tt>: </font>

        <ul>
          <li>
            <font size="3"><tt>deb http://eric.lavar.de/comp/linux/debian/ unstable/</tt> (&quot;Third Party Software&quot; tab) </font>
          </li>
          <li>
            <font size="3"><tt>deb http://eric.lavar.de/comp/linux/debian/ ubuntu/</tt> (&quot;Third Party Software&quot; tab) </font>
          </li>
          <li>
            <font size="3">The <i>multiverse</i> and <i>universe</i> repositories (&quot;Ubuntu Software&quot; tab) </font>
          </li>
        </ul>
      </li>
      <li>
        <font size="3">&quot;Reload&quot; the package list using the corresponding icon. </font>
      </li>
      <li>
        <font size="3">Mark the following packages for installation (or make sure they are already installed): </font>

        <ul>
          <li>
            <font size="3"><tt>sun-java6-jre</tt>. </font>
          </li>
          <li>
            <font size="3"><tt>javahelp2</tt> </font>
          </li>
          <li>
            <font size="3"><tt>freemind</tt> </font>
          </li>
          <li>
            <font size="3">And, as you need them, <tt>freemind-plugins-help</tt>, <tt>freemind-plugins-svg</tt> and <tt>freemind-plugins-time</tt> (you might search for &quot;freemind&quot; and install everything you find...). </font>
          </li>
        </ul>
      </li>
      <li>
        <font size="3">Apply the changes. That's it, FreeMind appears under the &quot;Office&quot; sub-menu! </font>
      </li>
    </ul>
    <dl>
      <dt>
        <font size="3">Note 1&#160; </font>
      </dt>
      <dd>
        <font size="3">I've added the <tt>libbatik-java</tt> package under my personal <tt>ubuntu</tt> repository, be aware that (security) updates might not happen timely. It shouldn't bother anybody much, but just in case... </font>
      </dd>
    </dl>
    <dl>
      <dt>
        <font size="3">Note 2&#160; </font>
      </dt>
      <dd>
        <font size="3">Ubuntu's online documentation explains <a class="external" href="https://help.ubuntu.com/community/SynapticHowto" title="https://help.ubuntu.com/community/SynapticHowto" rel="nofollow">Synaptic</a>&#160;(<i>https://help.ubuntu.com/community/SynapticHowto</i>) and how to <a class="external" href="https://help.ubuntu.com/7.10/add-applications/C/extra-repositories-adding.html" title="https://help.ubuntu.com/7.10/add-applications/C/extra-repositories-adding.html" rel="nofollow">add extra repositories</a>&#160;(<i>https://help.ubuntu.com/7.10/add-applications/C/extra-repositories-adding.html</i>). </font>
      </dd>
    </dl>
    <dl>
      <dt>
        <font size="3">Note 3&#160; </font>
      </dt>
    </dl>
    <p>
      <font size="3">2008-04-18 </font>
    </p>
    <p>
      <font size="3">Synaptic shows JAVAHELP2 has been packaged. When you search for JAVAHELP, you may see javahelp2 - the <i>2</i> is a version number). </font>
    </p>
    <p>
      <font size="3">Synaptic shows FreeMind 0.8.1 has been packaged. </font>
    </p>
    <p>
      <font size="3">FreeMind 0.8.0 doesn't work properly with Java 6. </font>
    </p>
    <p>
      <font size="3">0.9.0.betaX is not yet packaged, check therefore <a href="http://freemind.sourceforge.net/wiki/index.php/FreeMind_on_Linux#On_any_UN.2AX_kind_of_system_.28also_Linux.29" title="">the UN*X installation method</a> </font>
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1808511462" MODIFIED="1225973121965">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      P&#229; Microsoft Windows og Mac OS X, kan du ogs&#229; bare dobbeltklikke p&#229; filen freemind.jar placeret i mappen lib for at starte FreeMind.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_353522063" MODIFIED="1228214966303" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Bladre rundt i filerne p&#229; din computer
    </p>
  </body>
</html></richcontent>
<node CREATED="1124560950701" ID="ID_546434291" MODIFIED="1225974814704">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at bladre rund i filerne p&#229; din computer, skift til fil mode i Menuen: <b>Mindmaps &gt; File mode.</b>
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="ID_813277102" MODIFIED="1225974850373">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du bladrer rundt i filerne som var det en normal mind map.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="ID_601215853" MODIFIED="1227785742499">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at g&#248;re en mappe til den centrale node p&#229; mappen, brug <b>Center</b> i dropdown menuen.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="ID_1721007071" MODIFIED="1227785534850">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at se, redigere eller eksekvere en fil, f&#248;lg linket i dens node.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_279880616" MODIFIED="1227785680739">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fil mode er for nuv&#230;rende ikke s&#230;rligt brugbar. Den er en demonstration af at det ikke er for sv&#230;rt at f&#248;de data ind i tr&#230;et fra andre kilder end mind map. Der er ikke noget vidnesbyrd om at folk aktuelt vil bruge denne mode.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1530607683" MODIFIED="1228305847180" POSITION="left" TEXT="Browse mind maps">
<node CREATED="1124560950701" ID="ID_1524984605" MODIFIED="1227781038300">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at browse mind maps i stedet for at redigere dem, skift til browse mode i Menuen: Mindmaps &gt; Browse. Med mindre denne mode bruges i FreeMind applet, er funktionen ubrugelig.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="ID_925150130" MODIFIED="1227781158890">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#197;rsagen til at have en seperat browse mode er teknisk. Browsning er det eneste du kan g&#248;re i FreeMind applet, som kan inds&#230;ttes p&#229; din hjemmeside. Normalt vil du ikke bruge browse mode i FreeMind.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1136088046" MODIFIED="1228214970109" POSITION="left" TEXT="Om modes">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1713057526" MODIFIED="1227780720014">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Selvom Freemind prim&#230;rt er et v&#230;rkt&#248;j til at redigere mind maps, er det designet til at kunne vise data der kommer fra forskellige datakilder.&#160;&#160;For at g&#248;re en specific data kilde tilg&#230;ngelig til visning i FreeMind, skal en programm&#248;r have skrevet en s&#229; kaldt <b>mode </b>til den data kilde. Fil mode er et eksempel. Vi har ikke kendskab til andre modes der er implementeret. Det er endnu ikke klart om nogen overhovedet &#248;nsker at g&#248;re brug af denne arkitektur; den er her s&#229; den kan 'udforskes' hvis nogen &#248;nsker det.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_700085988" MODIFIED="1227781344389">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Der findes n&#230;sten klar kode til skema mode som g&#248;r dig i stand til at redigere skema programmer. Men igen er brugbarheden af moden langt fra klarlagt. Til forskel fra mind map mode, er andre modes mere en demonstration af hvad der er muligt, frem for noget der faktisk bruges.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1525986009" MODIFIED="1228214972262" POSITION="left" TEXT="Installering af FreeMind applet p&#xe5; din hjemmeside">
<node COLOR="#000000" CREATED="1124560950701" ID="ID_227263393" MODIFIED="1227781399025" TEXT="Du kan installere appletten p&#xe5; din hjemmeside s&#xe5; andre brugere kan browse dine mind maps.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_190456880" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1227781438033">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Download appletten, som er freemind-browser.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="ID_306791794" MODIFIED="1227781542648">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Det downloadede arkiv indeholder freemindbrowser.jar og freemindbrowser.html. Opret et link fra din side til freemindbrowser.html. I freemindbrowser.html: &#230;ndre stien indeni s&#229; den peger p&#229; dit mind map.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950701" ID="ID_1382314716" MODIFIED="1227781649545">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Applet'tens jar file skal v&#230;re placeret p&#229; samme server som mappen selv, af java sikkerheds &#229;rsager. Du skal uoade FreeMind applet jar filen og din mind map fil til din hjemmeside.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1083756111" MODIFIED="1228214973728" POSITION="left" TEXT="Brugen af FreeMind appletten">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_514864900" MODIFIED="1227785242602">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      I FreeMind appletten, kan du kun bruge browse mode; du kan ikke redigere fjerntliggende maps. Klik p&#229; en node for at skifte folding eller f&#248;lge et link. Tr&#230;k i baggrunden for at flytte mappen. For at s&#248;ge i mappen, brug nodens dropdown menu.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_784043927" MODIFIED="1228214995849" POSITION="left" TEXT="Kilder (credits)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_415458128" MODIFIED="1225973157601" TEXT="Forfattere">
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1896457660" MODIFIED="1124560950701" TEXT="Joerg Mueller">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:ponders@t-online.de" MODIFIED="1124560950701" TEXT="ponders@t-online.de">
<font NAME="Dialog" SIZE="10"/>
</node>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="University of Freiburg, Germany">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_984984595" LINK="http://danpolansky.blogspot.com/" MODIFIED="1216753531920" TEXT="Daniel Polansky">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_459203293" MODIFIED="1124560950701" TEXT="Petr Novak">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_875814410" MODIFIED="1124560950701" TEXT="Christian Foltin">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:christian.foltin@gmx.de" MODIFIED="1124560950701" TEXT="christian.foltin@gmx.de">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1415293905" MODIFIED="1124560950701" TEXT="Dimitri Polivaev">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_816166020" MODIFIED="1225973717313" TEXT="Mindre bidrag">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" ID="ID_805941234" MODIFIED="1124560950701" TEXT="Andrew Iggleden">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1487355920" MODIFIED="1225973750388" TEXT="Installer til Windows">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1096673251" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1768319472" MODIFIED="1124560950701" TEXT="Eclipse howto">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1024053399" MODIFIED="1124560950701" TEXT="David Butt">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Tutorial flash">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="David Low">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1801544898" MODIFIED="1225973735399" TEXT="Hj&#xe6;lpfuld">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_360501151" LINK="http://freemind.sourceforge.net/wiki/index.php/Translation" MODIFIED="1225973199857" TEXT="Overs&#xe6;ttelser">
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_807977431" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Italian translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1853214917" MODIFIED="1225973191608" TEXT="Jan Kr&#xfc;mmel">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1909237339" MODIFIED="1225973221580" TEXT="Dansk overs&#xe6;ttelse">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1676529317" MODIFIED="1124560950701" TEXT="Takeshi Kakeda">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_753119596" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562983644" ID="Freemind_Link_1172193026" MODIFIED="1124562984816" TEXT="Kohichi Aoki">
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1964309375" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Alex Dukal">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1111930472" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562998159" ID="Freemind_Link_757563697" MODIFIED="1124563008034" TEXT="Hugo Gayosso">
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1783275246" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_929540960" MODIFIED="1124560950701" TEXT="Sylvain Gamel">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="French translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" ID="Freemind_Link_946171164" MODIFIED="1124561245019" TEXT="Koen Roggemans">
<node COLOR="#999999" CREATED="1124561245957" ID="Freemind_Link_1819881845" MODIFIED="1124561251675" TEXT="Dutch translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" ID="Freemind_Link_235962981" MODIFIED="1124561376718" TEXT="Rafal Kraik">
<node COLOR="#999999" CREATED="1124561377702" ID="Freemind_Link_459079511" MODIFIED="1124561382155" TEXT="Polish translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561969717" ID="Freemind_Link_653284985" MODIFIED="1124561972920" TEXT="Goliath">
<node COLOR="#999999" CREATED="1124561438294" ID="Freemind_Link_1387213811" MODIFIED="1124561445950" TEXT="Korean translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561753254" ID="Freemind_Link_35211963" MODIFIED="1124563712385" TEXT="Martin Srebotnjak (nick: Miles a.k.a. filmsi)">
<node COLOR="#999999" CREATED="1124561491886" ID="Freemind_Link_835144271" MODIFIED="1124561506386" TEXT="Slovenian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561814721" ID="Freemind_Link_1008886206" MODIFIED="1124561818580" TEXT="William Chen">
<node COLOR="#999999" CREATED="1124561497308" ID="Freemind_Link_1960552629" MODIFIED="1124561506011" TEXT="Chinese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561823877" ID="Freemind_Link_1650138043" MODIFIED="1124561876907" TEXT="Radek &#x160;varc">
<node COLOR="#999999" CREATED="1124561515761" ID="Freemind_Link_768227373" MODIFIED="1124561519885" TEXT="Czech translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562250475" ID="Freemind_Link_901975324" MODIFIED="1124562252007" TEXT="Bal&#xe1;zs M&#xe1;rton">
<node COLOR="#999999" CREATED="1124562252585" ID="Freemind_Link_557911120" MODIFIED="1124562258428" TEXT="Hungarian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562948942" ID="Freemind_Link_290351026" MODIFIED="1124562950270" TEXT="Luis Ferreira ">
<node COLOR="#999999" CREATED="1124562956332" ID="Freemind_Link_6081004" MODIFIED="1124562961879" TEXT="Portuguese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124563066204" ID="Freemind_Link_23652566" MODIFIED="1225973661097">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kilderne til overs&#230;ttelserne er h&#248;jst sandsynlige ufuldente. Hvis vi har glemt dig, s&#229; lad os det vide. Alle folk som vi har kendskab til der har deltaget med mindst en ufuldst&#230;ndig overs&#230;ttelse er listet.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="ID_1238769160" MODIFIED="1225439609718" POSITION="right" TEXT="Tast Ctrl + F for at s&#xf8;ge. Tast Ctrl + G for at finde den n&#xe6;ste. For at g&#xf8;re s&#xf8;gningen global, tast Esc f&#xf8;r s&#xf8;gningen."/>
<node COLOR="#0033ff" CREATED="1124560950701" ID="ID_182998712" MODIFIED="1225439659204" POSITION="right" TEXT="Tast h&#xf8;jre piletast for at udfolde en tekst boks."/>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1596161299" MODIFIED="1228309815461" POSITION="right" TEXT="Introduktion">
<node CREATED="1124560950701" ID="ID_1231248176" MODIFIED="1225439293949" TEXT="FreeMind g&#xf8;r det muligt at oprette s&#xe5;kaldte mind maps. Dog er der mange mennesker der bruger den som et alternativ til en tabbed notebook eller en personlig informations manager."/>
<node CREATED="1124560950701" ID="ID_331120432" MODIFIED="1225439430826" TEXT="Informationen er gemt i tekst bokse, kaldet noder. Noder er forbundet sammen ved hj&#xe6;lp af kurvede linier kaldet edges."/>
<node CREATED="1124560950701" ID="ID_856663938" MODIFIED="1225439512960" TEXT="Dette er en dokumentation for FreeMind 0.8.0. Keyboard mappings og positioner af funktioner i menuerne kan v&#xe6;re forskellig fra version til version."/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_706084071" MODIFIED="1228309821772" POSITION="right" TEXT="Demonstration af nogle features">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_735193624" MODIFIED="1228309369522" TEXT="Udseende">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_528377460" MODIFIED="1225439733547" TEXT="Noder kan have forskellige farver.">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1124560950701" ID="ID_867862586" MODIFIED="1225439738139" TEXT="R&#xf8;d">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#009900" CREATED="1124560950701" ID="ID_1820644144" MODIFIED="1225439742660" TEXT="Gr&#xf8;n">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0000cc" CREATED="1124560950701" ID="ID_1827192106" MODIFIED="1225439746340" TEXT="Bl&#xe5;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_" MODIFIED="1225439879981" TEXT="Noder kan have forskellige baggrunds farver.">
<node CREATED="1124560950701" ID="_Freemind_Link_1358611533" MODIFIED="1124560950701" TEXT="This"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1317973766" MODIFIED="1124560950701" TEXT="That"/>
</node>
<node CREATED="1124560950701" ID="ID_1414391472" MODIFIED="1225439922942" TEXT="Noder kan have forskellige skrift stile.">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1992212664" MODIFIED="1225439932890" TEXT="Fed">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1153826682" MODIFIED="1225439939542" TEXT="Kursiv">
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_676211594" MODIFIED="1225439950020" TEXT="Fed og kursiv">
<font BOLD="true" ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="ID_1829231852" MODIFIED="1225869435258" TEXT="Skrifttyper i noderne kan have forskellige st&#xf8;rrelser">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_206677422" MODIFIED="1225440093660" TEXT="sm&#xe5;">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node CREATED="1124560950701" ID="ID_595929534" MODIFIED="1124560950701" TEXT="normal">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node CREATED="1124560950701" ID="ID_398681589" MODIFIED="1225440140121" TEXT="st&#xf8;rre">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node CREATED="1124560950701" ID="ID_507795071" MODIFIED="1225440132544" TEXT="Stor">
<font NAME="SansSerif" SIZE="20"/>
<node CREATED="1124560950701" ID="ID_805025967" MODIFIED="1124560950701" TEXT="OOh">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node CREATED="1124560950701" ID="ID_451873877" MODIFIED="1225869443791" TEXT="Forskellige skrifttyper kan anvendes">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_183959290" MODIFIED="1225440253799" TEXT="Denne">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1568731425" MODIFIED="1225440275184" TEXT="eller denne her">
<font NAME="Verdana" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1656359497" MODIFIED="1225440290883" TEXT="Eller denne..">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1193071041" MODIFIED="1225869438572" TEXT="Forskellige node stile kan bruges">
<node CREATED="1124560950701" ID="_Freemind_Link_1979277285" MODIFIED="1225869341958" TEXT="gaffel">
<node CREATED="1124560950701" ID="_Freemind_Link_89124429" MODIFIED="1225869346904" TEXT="Gaffel"/>
<node CREATED="1124560950701" ID="_Freemind_Link_173850525" MODIFIED="1225869352168" TEXT="Gaffel"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1001811541" MODIFIED="1225869413982" STYLE="bubble" TEXT="Bobbel">
<node CREATED="1124560950701" ID="_Freemind_Link_1677737286" MODIFIED="1225869418725" STYLE="bubble" TEXT="Bobbel"/>
<node CREATED="1124560950701" ID="_Freemind_Link_978246353" MODIFIED="1225869425576" STYLE="bubble" TEXT="Bobbel"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="ID_1515754322" MODIFIED="1228309377161" TEXT="Noder kan foldes">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_307016912" MODIFIED="1228309375393" TEXT="Fold">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Hidden">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1488567837" MODIFIED="1228309373598" TEXT="Tr&#xe6;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Oak">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Beech">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Elm">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="ID_894308350" MODIFIED="1228309380869" TEXT="Noder kan indeholde f&#xf8;lgbare links til... ">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" ID="ID_88099123" MODIFIED="1225869556168" TEXT="Hjemmesider">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1149779301" LINK="http://www.google.com/" MODIFIED="1124560950701" TEXT="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_100687440" LINK="www.google.com" MODIFIED="1124560950701" TEXT="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_931405214" MODIFIED="1225870246045" TEXT="Freemind tror dette link er eksekverbart :)">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="ID_1870767901" MODIFIED="1225869572116" TEXT="Lokale mapper">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1248757505" LINK="C:/Program%20Files/" MODIFIED="1225869681577" TEXT="C:/Programmer/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_845618316" LINK="/home/" MODIFIED="1124560950701" TEXT="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="ID_1053043933" MODIFIED="1225869583025" TEXT="Programmer">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_37699584" LINK="%SystemRoot%\regedit.exe" MODIFIED="1124560950701" TEXT="%SystemRoot%\regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006600" CREATED="1124560950701" ID="ID_1678040830" MODIFIED="1225869663799" TEXT="Du ser at noden er eksekverbar p&#xe5; ikonet.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_1049506322" MODIFIED="1225869624287" TEXT="Ethvert dokument p&#xe5; din lokale computer eller firmas netw&#xe6;rk">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_839677176" MODIFIED="1225963384677" TEXT="Multiline nodes">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1423568963" MODIFIED="1225963252596">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du kan opfatte multilinie noder som et afsnit eller som flere afsnit. Hvis du vil til at opbygge en videns database omkring FreeMind, Kan du ikke komme uden om at bruge dem. I stedet for at have en almindelig tekst fil med alle dine noter, kan du have en kort node med mange multilinie noder som den b&#248;rn.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1750585847" MODIFIED="1225963045872" TEXT="Du kan have grafiske links">
<node CREATED="1124560950717" ID="_Freemind_Link_1212380407" MODIFIED="1225869022419" TEXT="Der forbinder en node">
<arrowlink DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="41;0;" ID="Arrow_ID_854000001" STARTARROW="None" STARTINCLINATION="41;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1249400461" MODIFIED="1225869033264" TEXT="Med en anden">
<arrowlink COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" STARTARROW="None" STARTINCLINATION="47;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_880551392" MODIFIED="1225869045314" TEXT="Med forskellige farver">
<arrowlink DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="82;44;" ID="Freemind_Arrow_Link_1672464612" STARTARROW="None" STARTINCLINATION="82;44;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1789233193" MODIFIED="1225869062191" TEXT="og forskellige ruter"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1686184172" MODIFIED="1225963380268">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &quot;Videnskab er fakta; Ligesom huse er lavet af sten, s&#229; er videnskaben baseret p&#229; fakts; men en bunke sten er ikke et hus og en samling fakta er ikke n&#248;dvendigvis videnskab.&quot; --Henri Poincar&#233;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="ID_990460494" MODIFIED="1225963031093" TEXT="Korte multilinie noder med linieskift">
<node CREATED="1124560950717" ID="_Freemind_Link_1957797574" MODIFIED="1225869318812" TEXT="Linie,&#xa;en anden,&#xa;&#xa;og endnu &#xe9;n vil g&#xe5;,&#xa;s&#xe5; hvad mener du om det?"/>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="ID_936428765" MODIFIED="1225963032994" TEXT="Du kan emulere m&#xe6;rkede delinger">
<node CREATED="1124560950717" ID="ID_1749018067" MODIFIED="1225869086398" TEXT="Tr&#xe6;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_1529165237" MODIFIED="1124560950717" TEXT="is a">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_343716854" MODIFIED="1225869830976" TEXT="Eg">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_1620232513" MODIFIED="1124560950717" TEXT="is a">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_972241525" MODIFIED="1225869841502" TEXT="B&#xf8;g">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_903671418" MODIFIED="1124560950717" TEXT="is a">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1696334802" MODIFIED="1124560950717" TEXT="Elm">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_1838766055" MODIFIED="1225869091176" TEXT="Tr&#xe6;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_457437874" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1576453643" MODIFIED="1225869823824" TEXT="Blad">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_1620039195" MODIFIED="1225440345836" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1118177798" MODIFIED="1225869815742" TEXT="Stamme">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="ID_3731915" MODIFIED="1225440379037" TEXT="Du kan have ikoner i en node">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_318937820" MODIFIED="1225963038144" TEXT="Du kan have skyer">
<cloud/>
<node CREATED="1124560950717" ID="ID_1247128898" MODIFIED="1225868978292" TEXT="Med tilpassede farver">
<cloud COLOR="#f1ede6"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_127668276" MODIFIED="1225963040785" TEXT="Noder kan placeres frit">
<node CREATED="1124560950717" ID="_Freemind_Link_894936766" MODIFIED="1225869878091" TEXT="Den ene"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1942481455" MODIFIED="1225869889751" TEXT="efter den anden"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1709752669" MODIFIED="1228309818945" POSITION="right" TEXT="Oprettelse og sletning af noder">
<node CREATED="1124560950717" ID="ID_952436417" MODIFIED="1228309560971">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at oprette en barne node tast <b>Insert</b>.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1905673852" MODIFIED="1228309622983">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at oprette en barne node mens man redigerer en anden node, tast <b>Insert</b> mens der redigeres.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="ID_53184561" MODIFIED="1228309651476">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at oprette en s&#248;skende node, tast <b>Enter</b>.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1128020437" MODIFIED="1228309684439">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at oprette en s&#248;skende node over nuv&#230;rende node, tast <b>Shift + Enter</b>.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1762966152" MODIFIED="1228309718342">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at slette en node, tast <b>Delete</b>.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="ID_61692138" MODIFIED="1228309763627">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at slette en node, men beholde den til inds&#230;ttelse, tast <b>Ctrl + X</b>.
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950717" ID="ID_128107148" MODIFIED="1228309810740">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Alternativt, brug node dropdown menuen ved at h&#248;jreklikke p&#229; en node.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#338800" CREATED="1225962629993" FOLDED="true" ID="ID_956458429" MODIFIED="1228309510333" POSITION="right" TEXT="Oprettelse af Noter">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Noter oprettes ved at skrive i dialogboksen nederst i vinduet, noten oprettes i tilknytning til den node der er valg n&#229;r der skrives.
    </p>
  </body>
</html></richcontent>
<node CREATED="1225962682143" ID="ID_824175133" MODIFIED="1228305093153" TEXT="Noter oprettes ved at skrive i dialogboksen nederst i vinduet, noten oprettes i tilknytning til den node der er valg n&#xe5;r der skrives."/>
<node CREATED="1225962710270" ID="ID_1363067710" MODIFIED="1228309486213">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Note editoren vises/fjernes via menuen <b>Vis &gt; Vis/Skjul Note Vindue</b> (on/off funktion) eller tast <b>Ctrl + Shift + &lt;</b>.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1700974092" MODIFIED="1228309823900" POSITION="right" TEXT="Redigering af node tekst">
<node CREATED="1124560950717" ID="_Freemind_Link_519923426" MODIFIED="1225878744778">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at redigere en node, tast <b>F2</b>, <b>HOME</b> ellerr <b>END</b> tasterne, eller brug menuen Rediger. To finish editing a node, press<b> ENTER</b>.
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="_Freemind_Link_519923426" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_1179992477" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node CREATED="1124560950717" ID="ID_1762405386" MODIFIED="1225878778533" TEXT="For at erstatte teksten i en node, begynd at skrive."/>
<node CREATED="1124560950717" ID="ID_787028715" MODIFIED="1225878730512">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at fremtvinge en lang node n&#229;r der skal redigeres en kort node, tast <b>Alt + Enter</b>.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_665203643" MODIFIED="1225878861761">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at opsplitte en lang node, brug knappen <b>Split</b> i lang node editoren, eller tast <b>Alt + S</b> i lang node editoren.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_328364891" MODIFIED="1225878937564">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at inds&#230;tte en ny linie i lang node editoren, tast <b>Control + Enter</b>. Du kan ikke inds&#230;tte linieskift i e kort node editoren.
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="_Freemind_Link_1445647544" ENDARROW="Default" ENDINCLINATION="118;0;" ID="Freemind_Arrow_Link_1628309717" STARTARROW="None" STARTINCLINATION="118;0;"/>
</node>
<node CREATED="1124560950717" ID="ID_1057489630" MODIFIED="1225879922545">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at kopiere noget valgt til clipboard mens du redigerer en lang node, tast h&#248;jre musseknap og v&#230;lg kopier.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_525028732" MODIFIED="1225879062661">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at inds&#230;tte special symboler s&#229; som &#169;, inds&#230;t det i dit favorite tekstbehandlingsprogram s&#229; som Microsoft Word f&#248;rst, klip det ud og inds&#230;t det s&#229; i FreeMind.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1445647544" MODIFIED="1225879821574">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Normalt afslutter <b>Enter</b> redigeringen af en lang node, og <b>Ctrl + Enter</b> inds&#230;tter en ny linie. Ved af fjerne markeringen i afkrydsningsboksen &quot;Enter confirms&quot; kan du 'omvende' funktionen af de n&#230;vnte taste kombinationer, d.v.s. <b>ENTER</b> indf&#248;rer linieskift og <b>Ctrl + ENTER</b> afslutter redigering. Du kan s&#230;tte standard v&#230;rdien i preferencess. Endvidere, bliver v&#230;rdien af boksen gemt i l&#248;bet af en session af FreeMind.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_154525032" MODIFIED="1225879734332">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind underst&#248;tter fuldt ud unicode. Derfor kan du bruge script efter eger eget valg.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1660149394" MODIFIED="1228309825588" POSITION="right" TEXT="Formattering ef en node">
<node CREATED="1124560950717" ID="ID_818022420" MODIFIED="1225873572746">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at g&#248;re en node <b>Fed</b>, tast Ctrl + B.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_157362179" MODIFIED="1225873591416">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at g&#248;re en node <i>kursiv</i>, tast Ctrl + i.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1124560950717" ID="ID_289635265" MODIFIED="1225874008341" TEXT="For at &#xe6;ndre farven p&#xe5; teksten i noden, tast Alt + shift + F.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node BACKGROUND_COLOR="#cc3300" CREATED="1124560950717" ID="ID_1237787190" MODIFIED="1228305469508">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at &#230;ndre baggrundsfarven p&#229; en node, v&#230;lg <b>Formater &gt; Node baggrundsfarve</b> i nodens dropdown menu.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_254571585" MODIFIED="1228305413375">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at for&#248;ge skriftst&#248;rrelsen, klik <b>Formater -&gt; St&#248;rre (Node) Skriftst&#248;rrelse</b> i nodens dropdown menu.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="13"/>
</node>
<node CREATED="1124560950717" ID="ID_1766839246" MODIFIED="1228305405150">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at formindske skriftst&#248;rrelsen, klik <b>Formater -&gt; Mindre Node Skriftst&#248;rrelse</b> i nodens dropdown menu.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="11"/>
</node>
<node CREATED="1124560950717" ID="ID_341294853" MODIFIED="1225874476517">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at &#230;ndre skrifttypen, brug feltet p&#229; v&#230;rkt&#248;jslinien.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_368591979" MODIFIED="1225874272148">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at kopiere formatet p&#229; en node, tast <b>Alt + C</b>
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_912955055" MODIFIED="1225874283379">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at inds&#230;tte et format i en node, tast <b>Alt + V</b>.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_526328879" MODIFIED="1228309828058" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Brug af fysiske stile
    </p>
  </body>
</html></richcontent>
<node CREATED="1124560950717" ID="ID_1713193012" MODIFIED="1228304802923">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at p&#229;f&#248;re en fysisk stil til en node, v&#230;lg <b>Fysisk stil &gt; Stil efter dit valg</b> i nodens dropdown menu. For at g&#248;re det hurtigt, v&#230;lg de tastaturgenveje som bliver vist i dropdown menuen.
    </p>
  </body>
</html></richcontent>
<node CREATED="1228304429469" HGAP="21" ID="ID_1327945259" MODIFIED="1228304510516" VSHIFT="5">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Default</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#000000" CREATED="1228304470307" HGAP="21" ID="ID_597244379" MODIFIED="1228304507769">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Normal</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#338800" CREATED="1228304166397" ID="ID_662341963" MODIFIED="1228304237322">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>OK</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#990000" CREATED="1228304205434" ID="ID_970666043" MODIFIED="1228304262118">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil ' <b>needs action</b>'
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1228304278286" ID="ID_23080120" MODIFIED="1228304316285">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Hot</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#999999" CREATED="1228304332891" ID="ID_890956871" MODIFIED="1228304384411">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Detail</b>'
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="10"/>
</node>
<node COLOR="#006699" CREATED="1228304388280" ID="ID_1185393753" MODIFIED="1228304411719">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Folder</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#669900" CREATED="1228304536709" ID="ID_1948436746" MODIFIED="1228304846216">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Topic</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#006633" CREATED="1228304540869" ID="ID_1261248802" MODIFIED="1228304858326">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Larger Topic</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#b3b95c" CREATED="1228304542957" ID="ID_1508318862" MODIFIED="1228304865449">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Waiting topic</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#996600" CREATED="1228304544204" ID="ID_1522008176" MODIFIED="1228304883024">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Object / keyword</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#cc6600" CREATED="1228304545373" ID="ID_256555556" MODIFIED="1228304891676">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Object of code'</b>
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#999900" CREATED="1228304546916" ID="ID_55997048" MODIFIED="1228304898792">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Question</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#cc3300" CREATED="1228304633592" ID="ID_1685042880" MODIFIED="1228304905188">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Open question</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#990099" CREATED="1228304635719" ID="ID_1976491339" MODIFIED="1228304914506">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Bad'</b>
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#0033ff" CREATED="1228304637039" ID="ID_119662730" MODIFIED="1228304920818">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Blue</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#ff6666" CREATED="1228304638199" ID="ID_1678224893" MODIFIED="1228304937071">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Pink</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#009999" CREATED="1228304639383" ID="ID_1402710445" MODIFIED="1228304945378">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Cyan</b>'
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#000000" CREATED="1228304705531" ID="ID_250833654" MODIFIED="1228304953472">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Automatic MindMap Root</b>'
    </p>
  </body>
</html></richcontent>
<edge COLOR="#000000" WIDTH="8"/>
</node>
<node COLOR="#0033ff" CREATED="1228304707451" ID="ID_1887331472" MODIFIED="1228304961604">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>Mind Map1</b>'
    </p>
  </body>
</html></richcontent>
<edge COLOR="#0033ff" WIDTH="4"/>
</node>
<node COLOR="#00b439" CREATED="1228304708868" ID="ID_860135697" MODIFIED="1228304969482">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>MindMap2</b>'
    </p>
  </body>
</html></richcontent>
<edge COLOR="#00b439" WIDTH="2"/>
</node>
<node COLOR="#990000" CREATED="1228304763248" ID="ID_1329588649" MODIFIED="1228304981244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>MindMap3</b>'
    </p>
  </body>
</html></richcontent>
<edge COLOR="#990000" WIDTH="1"/>
</node>
<node COLOR="#111111" CREATED="1228304766768" ID="ID_1815641830" MODIFIED="1228304989266">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fysisk stil '<b>MindMapDefault</b>'
    </p>
  </body>
</html></richcontent>
<edge COLOR="#111111" WIDTH="thin"/>
</node>
</node>
<node CREATED="1124560950717" ID="ID_909179752" MODIFIED="1228304048251">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at tilf&#248;je din egen fysiske stil, givet at du er en teknisk mined bruger, rediger dem i filen &quot;patterns.xml&quot; placeret i mappen &quot;.freemind&quot; i din hjemmemappe.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1697687428" MODIFIED="1228309830260" POSITION="right" TEXT="Fremh&#xe6;velse af noder med skyer">
<node CREATED="1124560950717" ID="ID_55101481" MODIFIED="1225873443788" TEXT="Skyer er gode til at markere en region. Markeringen g&#xe6;lder noden og alle dens efterkommere (b&#xf8;rn)."/>
<node CREATED="1124560950717" ID="ID_992146775" MODIFIED="1225873294912">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at tilf&#248;je en sky, tryk <b>Ctrl + Shift + B</b> eller i menuen brug <b>Ins&#230;t &gt; Sky</b>.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_552712509" MODIFIED="1225873121445">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at &#230;ndre skyens farve, brug <b>Formater &gt; Sky</b> farve i menuen.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_855373685" MODIFIED="1225869998967" TEXT="Skyer kan have forskellige baggrunds farver s&#xe5; som gr&#xf8;n...">
<cloud COLOR="#e1f2e1"/>
<node CREATED="1124560950717" ID="ID_1111402163" MODIFIED="1225870007203" TEXT="... eller brun.">
<cloud COLOR="#ede5d5"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_203858515" MODIFIED="1228309831803" POSITION="right" TEXT="Tilf&#xf8;jning af hyperlink">
<node CREATED="1124560950717" ID="ID_119150257" MODIFIED="1225872759576" TEXT="For at tilf&#xf8;je et hyperlink til en node, tast Ctrl + K eller i menuen v&#xe6;lg  Inds&#xe6;t -&gt; Angiv link."/>
<node CREATED="1124560950717" ID="ID_1262402627" MODIFIED="1225872814902" TEXT="For at fjerne et hyperlink, g&#xf8;r hyperlinket tomt efter at have tastet Ctrl + K."/>
<node CREATED="1124560950717" ID="ID_836217873" MODIFIED="1225870181069">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at linke til en mail adresse, s&#230;t hyperlinket som <i>mailto:don.bonton@supermail.com</i>.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_346666934" MODIFIED="1225872898879">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at linke til en mail adresse med et givent emne, s&#230;t hyperlinket som
    </p>
    <p>
      <i>mailto:don.bonton@supermail.com?subject=Sidste Telefonopkald</i>.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_470753883" MODIFIED="1225872932011" TEXT="Hyperlinks kan linke til hjemmesider, lokale filer, eller email addresser."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1044397139" MODIFIED="1228309833639" POSITION="right" TEXT="Tilf&#xf8;jning af Ikoner">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_30774378" MODIFIED="1224670444146" TEXT="En node kan have flere ikoner. "/>
<node CREATED="1124560950717" ID="ID_1091699260" MODIFIED="1225963666023">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at tilf&#248;je ikoner til en node, v&#230;lg en node og klik p&#229; en af ikonerne vist i den venste v&#230;rkt&#248;jslinie. Hold<b> Alt</b> eller <b>Ctrl</b> mens du flytter musemark&#248;ren til venstre v&#230;rkt&#248;jslinie, s&#229; du ikke mister fokus p&#229; noden.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1228305519453" ID="ID_373397481" MODIFIED="1228305621143">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du kan ogs&#229; inds&#230;tte en ikon ved at v&#230;lge <b>Ikoner -&gt; selvvalgt Ikon</b> i nodens dropdown menu
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="wizard"/>
</node>
<node CREATED="1124560950717" ID="ID_935140259" MODIFIED="1225963756712">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at fjerne &#233;n ikon, klik p&#229; det r&#248;de kryds &#248;verst i ikon v&#230;rkt&#248;jslinien.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1670649993" MODIFIED="1225963799586">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at fjerne alle ikoner, klik p&#229; papirkurven i toppen af ikon v&#230;rkt&#248;jslinien.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_421224980" MODIFIED="1225963851703">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at tilf&#248;je et ikon uden at bruge v&#230;rkt&#248;jslinien, tast <b>Alt + i</b>.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1003373244" MODIFIED="1225963922839">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Der er ingen option s&#229; du kan bruge dine egne ikoner; du kan kun v&#230;lge mellem de ikoner som FreeMind tilbyder.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1076611470" MODIFIED="1225964223003">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at gemme eller vise ikon v&#230;rkt&#248;jslinien; i menuen <b>Vis</b> brug <b>Skift venstre toolbar</b> til at skifte mellem gem/vis. Ikon v&#230;rkt&#248;jslinien kaldes Venstre Toolbar i menuen.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1535221827" MODIFIED="1225880031007" TEXT="Ikonerne  tilknyttet denne node er inkluderede, og mange flere.">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1996597932" MODIFIED="1228309837787" POSITION="right" TEXT="Tilf&#xf8;jning af grafiske links">
<node CREATED="1124560950717" ID="ID_985897417" MODIFIED="1228223342629">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at oprette et grafisk link mellem to noder, tr&#230;k en node og drop den p&#229; en anden node alt imens b&#229;de shift og ctrl taserne holdes nede; slip museknappen f&#248;r shift og ctrl tasterne slippes.
    </p>
  </body>
</html></richcontent>
<arrowlink COLOR="#ff0000" DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="255;0;" ID="Freemind_Arrow_Link_1428344028" STARTARROW="None" STARTINCLINATION="255;0;"/>
</node>
<node CREATED="1216753755454" ID="ID_1564001222" MODIFIED="1228223431516">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Alternativt kan du v&#230;lge to noder ved brug af Ctrl og s&#229; v&#230;lge &quot;Tilf&#248;j grafisk link&quot; fra &quot;Inds&#230;t&quot; menuen eller dens genvej Ctrl+L.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_208378337" MODIFIED="1228223110124">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at &#230;ndre farve p&#229; linket, brug linkets dropdown menu ved at h&#248;jreklikke p&#229; det grafiske link.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1484370636" MODIFIED="1228223044608" TEXT="For at &#xe6;ndre pilene i et link, brug linkets dropdown menu."/>
<node CREATED="1124560950717" ID="ID_1970882825" MODIFIED="1228216927302" TEXT="For at slette et link, brug linkets dropdown menu."/>
<node CREATED="1124560950717" ID="_Freemind_Link_266716332" MODIFIED="1228223592600">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at navigere til den ene af endenoderne i et grafisk link, brug linkets dropdown menu.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1015289745" MODIFIED="1228223592600" TEXT="For at &#xe6;ndre ruten p&#xe5; et pilelink, tr&#xe6;k i det og flyt det.">
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="809;77;" ID="Freemind_Arrow_Link_1273596772" STARTARROW="None" STARTINCLINATION="293;88;"/>
</node>
<node CREATED="1124560950717" ID="ID_1872914317" MODIFIED="1227782251298">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Et eksempel p&#229; et grafisk link f&#248;lger:
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_46167995" MODIFIED="1226057524195" TEXT="Eksempel">
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1170112929" MODIFIED="1124560950717" TEXT="Link to another part">
<arrowlink COLOR="#9999ff" DESTINATION="_Freemind_Link_1492563156" ENDARROW="Default" ENDINCLINATION="115;0;" ID="Freemind_Arrow_Link_33407992" STARTARROW="Default" STARTINCLINATION="30;0;"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_582387124" MODIFIED="1228223211593" TEXT="Node med foldet subnode">
<node CREATED="1124560950717" ID="_Freemind_Link_1492563156" MODIFIED="1124560950717" TEXT="Subnode"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1370577235" MODIFIED="1228223184459" TEXT="Et andet link">
<arrowlink DESTINATION="_Freemind_Link_1170112929" ENDARROW="Default" ENDINCLINATION="61;0;" ID="Freemind_Arrow_Link_1872050149" STARTARROW="None" STARTINCLINATION="61;0;"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_423038022" MODIFIED="1228309839767" POSITION="right" TEXT="S&#xf8;gning">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_966700848" MODIFIED="1226054419656">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at finde tekst i en node og all dens efterkommere, tast <b>Ctrl + F</b> eller brug <b>Find</b> i &quot;Rediger&quot; menuen.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1646223708" MODIFIED="1226054521234">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at finde den n&#230;ste match i din s&#248;gning, tast <b>Ctrl + G</b> eller klik <b>Find n&#230;ste</b> i &quot;Rediger&quot; menuen.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_488311689" MODIFIED="1226054595841">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at gennems&#248;ge hele mappen, v&#230;lg den centrale node ved at taste <b>Esc</b> tasten inden s&#248;gning.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_829330412" MODIFIED="1226054825511">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#248;gningen er en kommer f&#248;rst s&#248;gning. Det falder i tr&#229;d med ideen om at jo dybere noden er jo st&#248;rre er detaljerne i noden.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_779591913" MODIFIED="1226054668665">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Husk at det ikke er hele mappen der gennems&#248;ges, men kun den valgte node og den efterf&#248;lgere.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_653540280" MODIFIED="1228309841471" POSITION="right" TEXT="Valg af flere noder">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1435652978" MODIFIED="1225872514313" TEXT="For at v&#xe6;lge flere nodes, hold control eller shift mens du klikker. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_741729737" MODIFIED="1226052381737">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at tilf&#248;je en enkelt nodes til en allerede valgt node, hold <b>ctrl</b> mens du klikker.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_133089768" MODIFIED="1226052359747">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at v&#230;lge en kontinuert r&#230;kke af noder, hold <b>shift</b> mens du klikker, eller hold <b>shift</b> mens du flytter fundt med piletasterne.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_350782537" MODIFIED="1226052539663">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at v&#230;lge et komplet undertr&#230;, hold <b>AltGr</b> mens du klikker, eller hold <b>shift</b> mens du med piletasterne flytter fra en node til dens for&#230;ldre. slutteligt g&#248;r <b>Ctrl+Shift+A</b> det same via keyboardet.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_451303534" MODIFIED="1226052595527">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at annullere valget af flere noder, klik p&#229; mappen baggrund eller p&#229; en ikke valgt node.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1024903226" MODIFIED="1228309842899" POSITION="right" TEXT="Tr&#xe6;k og slip">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_177010647" MODIFIED="1226051914238">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du kan flytte noder rundt ved brug af tr&#230;k og slip.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1985233315" MODIFIED="1228215100266" TEXT="For at inds&#xe6;tte en node som et barn, placer curseren p&#xe5; den yderste del af noden mens der &apos;slippes&apos;.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1089041083" MODIFIED="1228215235277">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at inds&#230;tte en node som en s&#248;skende, placer curseren i den &#248;verste del af den node der skal v&#230;re s&#248;skende mens der 'slippes'.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1994214827" MODIFIED="1228215307746">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at kopiere en node frem for at flytte den, hold control mens der tr&#230;kkes, eller tr&#230;k med den midterse museknap.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1696385635" MODIFIED="1228215486000">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at redigere en eksisterende map, tr&#230;k dens fil ind og slip den p&#229; baggrunden i FreeMind; dette virker i det mindste i Microsoft Windows operativ systemer.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_708852610" MODIFIED="1228215534570">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at oprette et grafisk link, tr&#230;k og slip mens h&#248;jre musetast holdes.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1815223533" MODIFIED="1228215397400">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis du har valgt flere noder bliver de alle flyttet eller kopieret.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_613179623" MODIFIED="1228215605293">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du kan 'droppe' data fra eksterne applikationer, s&#229; som filer p&#229; Microsoft Windows operativsystem, eller dele af tekst valgt i Microsoft Internet Explorer.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_958781924" MODIFIED="1228309845348" POSITION="right" TEXT="Kopiering og inds&#xe6;tning">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1014406316" MODIFIED="1225976280763">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du kan kopiere og inds&#230;tte (flere) noder mellem mindmaps (som forventet). I tilgift, kan du inds&#230;tte normal tekst eller HTML fra andre applikationer.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_897725033" MODIFIED="1225976414802">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis du inds&#230;tter almindelig tekst, bliver flere linier indsat som flere noder, hvor deres 'dybde' bestemmes af antallet af mellemrum f&#248;r teksten i linien.
    </p>
    <p>
      Et eksempel f&#248;lger.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1874523615" MODIFIED="1225975366448">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Tr&#230;<br />&#160;&#160;&#160;&#160;&#160;Eg<br />&#160;&#160;&#160;&#160;&#160;B&#248;g<br />&#160;&#160;&#160;&#160;&#160;
    </p>
  </body>
</html></richcontent>
<node CREATED="1124560950717" ID="ID_1051195019" MODIFIED="1225975381585">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      bliver indsat som
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1379923659" MODIFIED="1225975391543" TEXT="Tr&#xe6;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_749854158" MODIFIED="1225975395741" TEXT="Eg">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_262363385" MODIFIED="1225975403006" TEXT="B&#xf8;g">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_696872193" MODIFIED="1225975596986">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis du inds&#230;tter HTML, bliver det indsat som almindelig tekst. Desuden bliver links indeholdt i HTML indsat som b&#248;rn af en ekstra node med teksten &quot;Links&quot;. Eksempel f&#248;lger.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1177009830" MODIFIED="1225975629652">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Eksempel p&#229; resultat efter inds&#230;tning:
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_778514621" MODIFIED="1124560950717" TEXT="Shopping (120236)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1117094611" MODIFIED="1124560950717" TEXT="Urban Living (19)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_119984976" MODIFIED="1124560950717" TEXT="Links">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1761254695" LINK="http://directory.google.com/Top/Shopping/" MODIFIED="1124560950717" TEXT="Shopping">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_473826587" LINK="http://directory.google.com/Top/Home/Urban_Living/" MODIFIED="1124560950717" TEXT="Urban Living">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_247716142" MODIFIED="1226051293677">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis du inds&#230;tter en filliste valgt i Explorer i Microsoft Windows, bliver det indsat som et s&#230;t af links til filerne.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_141214740" MODIFIED="1225976604553">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis du i FreeMind kopierer en gren og inds&#230;tter det i en tekst editor, vises tr&#230; strukturen ved indrykning. Hyperlinks bliver indsat i &lt;&gt; paranteser. Et eksempel f&#248;lger.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1310174515" MODIFIED="1225976433112" TEXT="Tr&#xe6;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_489673647" MODIFIED="1225976437330" TEXT="Eg">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_135344444" MODIFIED="1225976446380" TEXT="B&#xf8;g">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1899359229" MODIFIED="1225976484137" TEXT="bliver indsat som">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_205184258" MODIFIED="1225976461889">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Tr&#230;<br />&#160;&#160;&#160;&#160;&#160;Eg<br />&#160;&#160;&#160;&#160;&#160;B&#248;g<br />&#160;&#160;&#160;&#160;&#160;Google &lt;http://www.google.com/&gt;<br />
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_733150382" LINK="http://www.google.com/" MODIFIED="1124560950732" TEXT="Google">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="ID_1838737364" MODIFIED="1226056704149">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis du i FreeMind kopierer en gren og inds&#230;tter det i en editor der forst&#229;r rich text format, vil formatteringen inklusive farve og skrifttyper ogs&#229; blive indsat. Hyperlinks bliver indsat i &lt;&gt; parantesersom almindelig tekst. Editorer der forst&#229;r rich text format indbefatter Microsoft Word, Wordpad eller Microsoft Outlook, eller nogle tabbed notebooks i Linux.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1879256225" MODIFIED="1226056671967">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at kopiere en node uden dens efterkommere, tast <b>Ctrl + shift + C</b> eller v&#230;lg <i>kopier enkelt</i> i nodens genvejsmenu.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="_Freemind_Link_1540212684" MODIFIED="1228309846858" POSITION="right" TEXT="Navigering">
<node CREATED="1124560950732" ID="ID_902466989" MODIFIED="1225870345993" TEXT="For at flytte mark&#xf8;ren op, ned, til venstre eller h&#xf8;jre, brug pile-tasterne."/>
<node CREATED="1124560950732" ID="ID_612274989" MODIFIED="1228215938135" TEXT="For at flytte til toppen af det nuv&#xe6;rende undertr&#xe6;, tast PageUp."/>
<node CREATED="1124560950732" ID="ID_672093819" MODIFIED="1228215965497" TEXT="For at flytte til bunden af det nuv&#xe6;rende undertr&#xe6;, tast PageDown."/>
<node CREATED="1124560950732" ID="ID_613066796" MODIFIED="1228215757424" TEXT="For at flytte til den centrale node, tast Escape."/>
<node CREATED="1124560950732" ID="_Freemind_Link_97763226" MODIFIED="1228215861507">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at positionere en node frit s&#229; tr&#230;k den i dens usynlige h&#229;ndtag, placeret i siden af noden i retning mod roden, og flyt den.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_4727471" MODIFIED="1228215972689" POSITION="right" TEXT="Foldning og udfoldning">
<node CREATED="1124560950732" ID="ID_212883424" MODIFIED="1226057643859">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at folde en node, tast <b>mellemrumstasten</b>, tast <i>Skift mellem ind- og udfoldet</i> i nodens genvejsmenu(h&#248;jreklik) eller klik p&#229; den bl&#229; minusknap i hoved v&#230;rkt&#248;jslinien..
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_285135499" MODIFIED="1226057591518">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at udfolde en node, tast <b>mellemrumstasten</b>, klik <i>Skift mellem ind- og udfoldet </i>i nodens genvejsmenu(h&#248;jreklik) , tast en piletast i udfoldningens retning eller klik p&#229; den bl&#229; plus knap i hoved v&#230;rkt&#248;jslinien.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1130520464" MODIFIED="1226058057734">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at folde eller udfolde noder i niveauer, hold <b>Alt</b> mens du bruge musehjulet, eller tast <b>Alt + PageUp</b> eller <b>Alt + PageDown</b>. P&#229; store maps b&#248;r du bruge denne funktion med forsigtighed, da den kan lede til hukommelsesproblemer.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_907573663" MODIFIED="1226057447437">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at udfolde alt, klik p&#229; den gr&#229; plusknap i hoved v&#230;rkt&#248;jslinien, eller klik p&#229; <i>Naviger &gt; Udfold Alt</i> i menuen.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1257737750" MODIFIED="1226057434671">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at folde alt, klik p&#229; den gr&#229; minus knap i hoved v&#230;rkt&#248;jslinien, eller klik p&#229; <i>Naviger &gt; Fold Alt </i>i menuen.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_500979532" MODIFIED="1226057183681">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      En foldet node er markeret med en lille cirkel tilf&#248;jet i den udg&#229;ende retning.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_516331171" MODIFIED="1228215974483" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Skift til en anden mind map
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1480909148" MODIFIED="1226056598272">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at skifte til en anden, allerede &#229;bnet, mind map, h&#248;jreklik i baggrunden og v&#230;lg en anden map i genvejsmenuen.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_467411537" MODIFIED="1228215975699" POSITION="right" TEXT="Scrolling af mappen">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_422751877" MODIFIED="1226057866675">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at skrolle en map, tr&#230;k i baggrunden og flyt den rundt, eller brug musens hjul. for at skrolle horisontalt med musens hjul, hold <b>shift </b>eller en af museknapperne.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913137192" MODIFIED="1228215977072" POSITION="right" TEXT="Zooming">
<node CREATED="1124560950732" ID="ID_1314068784" MODIFIED="1226056041949">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at zoome, brug musehjulet men du holder Ctrl tasten, eller tast <b>Alt + pil op</b> eller <b>pil ned</b>. Alternativt kan du bruge zooming feltet i v&#230;rkt&#248;jslinien.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1318678369" MODIFIED="1228215978679" POSITION="right" TEXT="Brug af Fortryd">
<node CREATED="1124560950732" ID="ID_289967727" MODIFIED="1227781753047" TEXT="For at fortryde, tast Control + Z, eller i pull-down menuen brug Rediger &gt; Fortryd."/>
<node CREATED="1124560950732" ID="ID_504027865" MODIFIED="1227781801515" TEXT="For at gendanne, tast Control + Y, eller i pull-down menuen brug Rediger &gt; Gendan"/>
<node CREATED="1124560950732" ID="ID_694036875" MODIFIED="1227782165997">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at s&#230;tte antallet af trin der gemmes til gendannelse, brug pull-down menuen V&#230;rkt&#248;jer &gt; Indstillinger.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#336600" CREATED="1225973884795" FOLDED="true" ID="ID_498992512" MODIFIED="1228305888918" POSITION="right" TEXT="Eksportering">
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_22510332" MODIFIED="1228305885182" TEXT="Exportering til HTML">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_770955070" MODIFIED="1228302691248">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at eksportere en gren til HTML, tast <b>Ctrl + H</b>. Den eksporterede HTML side kan indeholde foldnings support, alt afh&#230;ngig af indstilligerne i indstillinger.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1657433102" MODIFIED="1228302865395">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at bruge en anden eksport funktion, brug <b>Filer &gt;Eksport &gt; Som XHTML (JavaScript version)</b> i menuen.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_556182262" MODIFIED="1228302846075">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at eksportere en map med et ovebliks billede til HTML, brug <b>Filer &gt; Export &gt; Som XHTML (Klikbar kort image version)</b> i menuen.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1908686168" MODIFIED="1228305886574" TEXT="Exportering som bitmap eller vektor billede">
<node CREATED="1124560950732" ID="ID_907952079" MODIFIED="1228302517531">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at eksportere mappen til et PNG billede, brug <b>Filer &gt; Eksport &gt; Som PNG</b> i menuen.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_447307683" MODIFIED="1228302534332">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at eksportere mappen til et JPEG(JPG) billede, brug <b>Filer &gt; Eksport &gt; Som JPG</b> i menuen.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1828591637" MODIFIED="1228302551681">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at eksportere mappen til et SVG billede, brug <b>Filer &gt; Eksport &gt; Som SVG</b> i menuen.<br />Denne funktion er kun valgbar, hvis du har installeret SVG plug-in.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_329770204" MODIFIED="1228305888266" TEXT="Exportering til andre XML formater">
<node CREATED="1124560950732" ID="ID_1103188173" MODIFIED="1228302394356">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at eksportere en map til et andet XML format, for hvilket du har et 'XSLT transformation sheet', brug <b>Filer &gt; Export &gt; Bruger XSLT</b> i menuen.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1467924241" MODIFIED="1228302485139">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at eksportere en map til et OpenOffice 1.4 Writer dokument, brug <b>Filer &gt; Eksport &gt; Som OpenOffice Dokument</b> i menuen.
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#336600" CREATED="1225973914025" FOLDED="true" ID="ID_233447667" MODIFIED="1228216004325" POSITION="right" TEXT="Importering">
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1841136119" MODIFIED="1228215999146" TEXT="Importering af mappe struktur">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_141591900" MODIFIED="1227785056548">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at importere en mappe struktur, v&#230;lg <b>Filer &gt; Importer &gt; Importer filmappestruktur</b> i menuen. Du vil blive spurgt hvilken mappe struktur du vil importere. Ved struktur mener vi tr&#230;et af alle (ikke n&#248;dvendigvis direkte) undermapper med links til fillerne i disse undermapper. Et eksempel p&#229; en indsat struktur f&#248;lger:
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_1252989083" MODIFIED="1226052657751" TEXT="Eksempel">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_922210493" MODIFIED="1226052667259" TEXT="Valgt mappe">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" LINK="C:\Program%20Files\Microsoft%20Office\Office\Bitmaps" MODIFIED="1124560950732" TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/" MODIFIED="1124560950732" TEXT="Dbwiz">
<node CREATED="1124560950732" ID="ID_1000158712" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ASSETS.GIF" MODIFIED="1124560950732" TEXT="ASSETS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF" MODIFIED="1124560950732" TEXT="CONTACTS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF" MODIFIED="1124560950732" TEXT="EVTMGMT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF" MODIFIED="1124560950732" TEXT="EXPENSES.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF" MODIFIED="1124560950732" TEXT="INVENTRY.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/LEDGER.GIF" MODIFIED="1124560950732" TEXT="LEDGER.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF" MODIFIED="1124560950732" TEXT="ORDPROC.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF" MODIFIED="1124560950732" TEXT="RESOURCE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/SERVICE.GIF" MODIFIED="1124560950732" TEXT="SERVICE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF" MODIFIED="1124560950732" TEXT="TIMEBILL.GIF"/>
</node>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/" MODIFIED="1124560950732" TEXT="Styles">
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLENDS.GIF" MODIFIED="1124560950732" TEXT="ACBLENDS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLUPRT.GIF" MODIFIED="1124560950732" TEXT="ACBLUPRT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACEXPDTN.GIF" MODIFIED="1124560950732" TEXT="ACEXPDTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACINDSTR.GIF" MODIFIED="1124560950732" TEXT="ACINDSTR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACRICEPR.GIF" MODIFIED="1124560950732" TEXT="ACRICEPR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSNDSTN.GIF" MODIFIED="1124560950732" TEXT="ACSNDSTN.GIF"/>
<node CREATED="1124560950732" ID="ID_432398793" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSUMIPT.GIF" MODIFIED="1124560950732" TEXT="ACSUMIPT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_269203785" MODIFIED="1228216001361" TEXT="Importering af Internet Explorer favoritter">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_260446736" MODIFIED="1227785024999">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at importere Explorer favoritter ind i FreeMind, v&#230;lg <b>Filer &gt; Importer &gt; Importer Explorer Favoritter</b> i menuen. Du vil blive bedt om at indtaste stien til mappen, hvor dine favoritter er gemt. Mappens navn er &quot;Favorites&quot; og du kan finde den p&#229; din disk. P&#229; Windows 2000 er stien C:\Documents and Settings\&lt;user&gt;\Favorites.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#999999" CREATED="1124560950732" ID="ID_41235661" MODIFIED="1227784847645" TEXT="N&#xf8;gleord: Microsoft Internet Explorer, MSIE, MS IE.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1709974530" MODIFIED="1228216003124" TEXT="Importering af MindManager X5 mind map">
<node CREATED="1124560950732" ID="ID_452431111" MODIFIED="1227784555890">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at importere MindManager X5 et mind map, brug <b>Filer &gt; Importer &gt; MindManager X5 map</b> i menuen.
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913645795" MODIFIED="1228303207607" POSITION="right" TEXT="Integration med Word eller Outlook">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1201525019" MODIFIED="1228303009559">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du kan inds&#230;tte (paste) map's eller grene i Microsoft Word, Wordpad eller Outlook meddelelser. Generelt set kan du inds&#230;tte det i enhver applikation der forst&#229;r rich text formatet. Tekst formatteringen og links inds&#230;ttes ogs&#229;.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_283241136" LINK="mailto:don.bonton@supermail.com" MODIFIED="1228303088874">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Klik p&#229; et mail link (mailto:don.bonton@supermail.com) vil &#229;bne Outlook for oprettelse af en ny meddelelse, hvis ikke Windows er indstillet til noget andet.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1114432548" LINK="mailto:don.bonton@supermail.com?subject=Last%20phone%20call" MODIFIED="1228303120502">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du kan bruge emne(subject) i mail links.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1766045343" MODIFIED="1228303205282">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      En alternativ m&#229;de at inds&#230;tte en mind map i Microsoft Word er ved at eksportere den til HTML baseret p&#229; overskrifter(headings), kopiere HTML'en og inds&#230;tte det i Word.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1822195277" MODIFIED="1228215634340" POSITION="right" TEXT="&#xc6;ndre Indstillinger">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_403174837" MODIFIED="1227782449857">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at redigere indstillinger, v&#230;lg <b>V&#230;rkt&#248;jer &gt; Indstillinger</b> i pull-down menuen. De fleste &#230;ndringer tr&#230;der f&#248;rst i kraft efter en genstart af FreeMind.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1553236072" MODIFIED="1227782543777">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Instillinger inkluderer keyboard mapping, opf&#248;rsel n&#229;r der eksporteres HTML, m&#229;den node valg med musen fremtr&#230;der, valg af antialiasing, og mere.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#999999" CREATED="1124560950732" ID="ID_1233548507" MODIFIED="1124560950732" TEXT="Key words: customizing.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1528828442" MODIFIED="1228305837761" POSITION="right" TEXT="Udskrivning">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1477433926" MODIFIED="1228303594053">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Du kan udskrive ved enten at tilpasse hele mappen til en side, eller udskrive mappen p&#229; flere ark. Dette valg kan &#230;ndres i menuen: <b>Filer &gt; Side &gt; ...</b> og afkrydse <b>Tilpas siden</b> i dialogboksen <b>Udskrivningsindstillinger</b>.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1015761632" MODIFIED="1228303672028">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at udnytte pladsen optimalt, v&#230;lg landscape i sideops&#230;tning.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_506264631" MODIFIED="1228305820282">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      kan se hvordan udskriften kommer til at se ud ved at v&#230;lge <b>Filer &gt; Vis Udskrift ...</b> i menuen
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_841140408" MODIFIED="1228216589334" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Brug af rich text ved hj&#230;lp af HTML i noder
    </p>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="ID_951006510" MODIFIED="1228216436066">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Noder der begynder med &lt;html&gt; bliver vist med brug af den indeholdte HTML kode. Denne feature er kun brugbar for teknisk mindede folk. Et eksempel f&#248;lger:
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1013225003" MODIFIED="1228216264677">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <h3>
      HTML Eksempel
    </h3>
    <p class="msonormal">
      Der er flere punkter:
    </p>
    <ul type="disc">
      <li class="msonormal">
        Punkt et
      </li>
      <li class="msonormal">
        Punkt to
      </li>
    </ul>
    <p class="msonormal">
      Og vi har <b>fed</b> eller <i>kursiv</i>. <u>Underlinieret</u> og en <strike>streg-igennem</strike> . Vi kan have tabeller:
    </p>
    <table class="msonormaltable" cellpadding="0" border="1" cellspacing="0" style="border: none">
      <tr>
        <td style="padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt; padding-left: .75pt; border: solid windowtext 1.0pt">
          <p class="msonormal">
            Celle1
          </p>
        </td>
        <td style="padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt; padding-left: .75pt; border-left: none; border: solid windowtext 1.0pt">
          <p class="msonormal">
            Celle2
          </p>
        </td>
      </tr>
      <tr>
        <td style="border-top: none; padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt; padding-left: .75pt; border: solid windowtext 1.0pt">
          <p class="msonormal">
            Celle3
          </p>
        </td>
        <td style="border-right: solid windowtext 1.0pt; border-top: none; padding-right: .75pt; border-bottom: solid windowtext 1.0pt; padding-top: .75pt; padding-bottom: .75pt; padding-left: .75pt; border-left: none">
          <p class="msonormal">
            Celle4.
          </p>
        </td>
      </tr>
    </table>
    <p class="msonormal">
      Og vi kan have varierende <font color="#999900">forgrunds</font> <font color="#336600">farver</font>.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_996198214" MODIFIED="1228216586920">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Der er ikke support for HTML nodes og billeder n&#229;r der eksporteres til tekst eller RTF (Word, Wordpad). I det mindste er brugen af HTML praktisk til publicering p&#229; Internettet ved brug af Freemind's Applet.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_271176250" MODIFIED="1228216020565" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Bruge billeder i noder
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1288351528" MODIFIED="1227783499392">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at inds&#230;tte et billede i FreeMind, tast <b>Alt + K</b>, eller brug <b>Inds&#230;t &gt; Billede</b> i menuen. Ved at inds&#230;tte et billede mister du al teksten du havde i den node. Billeder insat p&#229; denne m&#229;de bliver ikke indsat korrekt uden for FreeMind og bliver ikke n&#248;dvendigvis korrekt eksporteret til HTML. Billeder i FreeMind er en forel&#248;big feature.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_263192076" MODIFIED="1227782794015" TEXT="Underst&#xf8;ttede billed formater er PNG, JPEG og GIF."/>
<node CREATED="1124560950732" ID="ID_1902277424" MODIFIED="1227783781147">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fr at g&#248;re links til billeder til synlige billeder, tast <b>Alt + K</b>. Du kan tr&#230;kke og slippe flere billedfiler ind i FreeMind, v&#230;lg dem som multiple nodes, og g&#248;r dem til billeder ved at taste <b>Alt + K</b>.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#000000" CREATED="1124560950732" ID="ID_823040549" MODIFIED="1227783623939">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      En mere teknisk og ikke s&#230;rlig brugervenlig m&#229;de at inds&#230;tte billeder f&#248;lger. Det er muligt at inkludere HTML i noderne. Du skal starte nodens indhold med taggen &lt;html&gt;. P&#229; denne m&#229;de kan du have billeder i dine noder.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_275805767" MODIFIED="1227782759472">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For eksempel:<br />&#160;&#160;&lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;<br />&#160;&#160;&lt;html&gt;&lt;img src=&quot;file://C:/Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;<br />
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1931467517" MODIFIED="1227782662465" TEXT="Du kan bruge relative links til billederne.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_1825247742" MODIFIED="1227782735455">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Eksempel p&#229; billeder (virker p&#229; nogle Windows distributioner).
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1643818893" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_915809058" MODIFIED="1226052829040">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="ID_947954944" MODIFIED="1226052861779">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Programmer/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF" />
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1124560950732" ID="ID_176171336" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="ID_133417683" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="ID_1890878954" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF"/>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_568961443" MODIFIED="1228216016993" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Bruge eksperimential fill&#229;sning
    </p>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="ID_1776952945" MODIFIED="1227784213287">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Nuv&#230;rende version af FreeMind har Eksperimential fill&#229;sning, disabled som standard. Nuv&#230;rende implementation forhindrer ikke 'race conditions' perfekt, men skulle v&#230;re fin til de fleste praktiske form&#229;l.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_524514323" MODIFIED="1227784328616">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Fill&#229;sning sikrer at der ikke er flere brugere der redigerer den samme map samtidigt, forhindrer dem i tilf&#230;ldigt at overskrive informationer fra hinanden.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_90490052" MODIFIED="1227784445744">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      For at enable Eksperimental fill&#229;sning, v&#230;lg V&#230;rkt&#248;jer &gt; Indstillinger i menuen, g&#229; til omgivelser og afkryds i boksen Eksperimental fill&#229;sning.
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</map>
