<map version="0.8.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#993300" CREATED="1124560950701" ID="Freemind_Link_1869696144" MODIFIED="1213113771788" TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body width=&quot;&quot;&gt;&#xa;    &lt;p align=&quot;center&quot;&gt;&#xa;      FreeMind&lt;br&gt;&lt;small&gt;- h&#xe3;y gi&#x1ea3;i ph&#xf3;ng t&#x1b0; duy c&#x1ee7;a b&#x1ea1;n -&lt;/small&gt;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;&#xa;">
<font BOLD="true" NAME="Dialog" SIZE="18"/>
<node CREATED="1124560950701" LINK="http://freemind.sourceforge.net" MODIFIED="1124560950701" POSITION="left" TEXT="Trang ch&#x1ee7; c&#x1ee7;a FreeMind">
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1091417446" MODIFIED="1125175911388" POSITION="left" TEXT="C&#xe1;c ph&#xed;m t&#x1eaf;t">
<node CREATED="1124560950701" ID="Freemind_Link_307658988" MODIFIED="1213147465274" TEXT="L&#x1ec7;nh v&#x1ec1; t&#x1ead;p tin:&#xa;S&#x1a1; &#x111;&#x1ed3; m&#x1edb;i - Ctrl+N&#xa;M&#x1edf; - Ctrl+O&#xa;L&#x1b0;u - Ctrl+S&#xa;L&#x1b0;u d&#x1ea1;ng - Ctrl+A&#xa;In - Ctrl+P&#xa;&#x110;&#xf3;ng - Ctrl+W&#xa;Tho&#xe1;t - Ctrl+Q&#xa;S&#x1a1; &#x111;&#x1ed3; tr&#x1b0;&#x1edb;c - Ctrl+LEFT&#xa;S&#x1a1; &#x111;&#x1ed3; k&#x1ebf; - Ctrl+RIGHT&#xa;Xu&#x1ea5;t ra HTML - Ctrl+E&#xa;Xu&#x1ea5;t nh&#xe1;nh ra HTML - Ctrl+H&#xa;Xu&#x1ea5;t nh&#xe1;nh ra s&#x1a1; &#x111;&#x1ed3; m&#x1edb;i - Alt+A&#xa;M&#x1edf; t&#x1ead;p tin l&#x1ea7;n tr&#x1b0;&#x1edb;c - Ctrl+Shift+W&#xa;&#xa;L&#x1ec7;nh ch&#x1ec9;nh s&#x1eed;a:&#xa;T&#xec;m - Ctrl+F&#xa;T&#xec;m ti&#x1ebf;p - Ctrl+G&#xa;C&#x1eaf;t - Ctrl+X&#xa;Ch&#xe9;p - Ctrl+C&#xa;Ch&#xe9;p ri&#xea;ng - Ctrl+Y&#xa;D&#xe1;n - Ctrl+V&#xa;&#xa;L&#x1ec7;nh chuy&#x1ec3;n ch&#x1ebf; &#x111;&#x1ed9;:&#xa;Ch&#x1ebf; &#x111;&#x1ed9; S&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy - Alt+1&#xa;Ch&#x1ebf; &#x111;&#x1ed9; duy&#x1ec7;t - Alt+2 &#xa;Ch&#x1ebf; &#x111;&#x1ed9; t&#x1ead;p tin - Alt+3&#xa;&#xa;C&#xe1;c l&#x1ec7;nh &#x111;&#x1ecb;nh d&#x1ea1;ng n&#xfa;t:&#xa;Ch&#x1eef; nghi&#xea;ng - Ctrl+I&#xa;Ch&#x1eef; &#x111;&#x1ead;m - Ctrl+B&#xa;M&#xe2;y - Ctrl+Shift+B&#xa;&#x110;&#x1ed5;i m&#xe0;u n&#xfa;t - Alt+C&#xa;Blend node color - Alt+B&#xa;Change node edge color - Alt+E&#xa;T&#x103;ng c&#x1ee1; ch&#x1eef; cho n&#xfa;t - Ctrl+L&#xa;Gi&#x1ea3;m c&#x1ee1; ch&#x1eef; cho n&#xfa;t - Ctrl+M&#xa;T&#x103;ng c&#x1ee1; ch&#x1eef; cho nh&#xe1;nh - Ctrl+Shift+L&#xa;Gi&#x1ea3;m c&#x1ee1; ch&#x1eef; cho nh&#xe1;nh - Ctrl+Shift+M&#xa;&#xa;L&#x1ec7;nh di chuy&#x1ec3;n gi&#x1eef;a c&#xe1;c n&#xfa;t:&#xa;V&#x1ec1; n&#xfa;t g&#x1ed1;c  - ESCAPE&#xa;&#x110;i l&#xea;n - UP&#xa;&#x110;i xu&#x1ed1;ng - DOWN&#xa;Sang tr&#xe1;i - LEFT&#xa;Sang ph&#x1ea3;i - RIGHT&#xa;M&#x1edf; li&#xea;n k&#x1ebf;t - Ctrl+ENTER&#xa;Thu nh&#x1ecf; - Alt+UP&#xa;Ph&#xf3;ng to - Alt+DOWN&#xa;&#xa;L&#x1ec7;nh t&#x1ea1;o n&#xfa;t m&#x1edb;i:&#xa;Th&#xea;m n&#xfa;t anh - ENTER&#xa;Th&#xea;m n&#xfa;t con - INSERT&#xa;Th&#xea;m n&#xfa;t anh ph&#xed;a tr&#x1b0;&#x1edb;c - Shift+ENTER&#xa;&#xa;L&#x1ec7;nh s&#x1eed;a n&#xfa;t:&#xa;S&#x1eed;a n&#xfa;t &#x111;&#xe3; ch&#x1ecd;n - F2&#xa;S&#x1eed;a n&#xfa;t d&#xe0;i - Alt+ENTER&#xa;Join nodes - Ctrl+J&#xa;M&#x1edf; r&#x1ed9;ng/Thu g&#x1ecd;n - SPACE&#xa;M&#x1edf; r&#x1ed9;ng/Thu g&#x1ecd;n c&#x1ea5;p con - Ctrl+SPACE&#xa;&#x110;&#x1eb7;t li&#xea;n k&#x1ebf;t b&#x1eb1;ng b&#x1ed9; duy&#x1ec7;t t&#x1ead;p tin - Ctrl+Shift+K&#xa;&#x110;&#x1eb7;t li&#xea;n k&#x1ebf;t b&#x1eb1;ng &#xf4; v&#x103;n b&#x1ea3;n - Ctrl+K&#xa;&#x110;&#x1eb7;t &#x1ea3;nh b&#x1eb1;ng b&#x1ed9; duy&#x1ec7;t t&#x1ead;p tin - Alt+K&#xa;Move node up - Ctrl+UP&#xa;&#x110;em n&#xfa;t xu&#x1ed1;ng - Ctrl+DOWN&#xa;">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#006633" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_904501221" MODIFIED="1124560950701" POSITION="left" TEXT="C&#xe0;i &#x111;&#x1eb7;t">
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1911559485" MODIFIED="1124560950701" TEXT="Li&#xea;n k&#x1ebf;t">
<node CREATED="1124560950701" LINK="http://java.sun.com/j2se" MODIFIED="1124560950701" TEXT="T&#x1ea3;i v&#x1ec1; Java Runtime Environment (&#xed;t nh&#x1ea5;t l&#xe0; J2RE1.4)">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1612101865" LINK="http://sourceforge.net/project/showfiles.php?project_id=7118" MODIFIED="1124560950701" TEXT="T&#x1ea3;i ch&#x1b0;&#x1a1;ng tr&#xec;nh v&#x1ec1;">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_139664576" MODIFIED="1124560950701" TEXT="&#x110;&#x1ec3; c&#xe0;i &#x111;&#x1eb7;t FreeMind tr&#xea;n Microsoft Windows, h&#xe3;y c&#xe0;i Java tr&#xea;n trang ch&#x1ee7; c&#x1ee7;a Sun v&#xe0; c&#xe0;i FreeMind b&#x1eb1;ng b&#x1ed9; c&#xe0;i c&#xf3; tr&#xea;n trang ch&#x1ee7; Freemind."/>
<node CREATED="1124560950701" ID="_Freemind_Link_1380352758" MODIFIED="1124560950701" TEXT="&#x110;&#x1ec3; c&#xe0;i FreeMind tr&#xea;n Linux, t&#x1ea3;i b&#x1ed9; Java Runtime Environment v&#xe0; c&#x1ea3; &#x1ee9;ng d&#x1ee5;ng FreeMind v&#x1ec1;. C&#xe0;i Java tr&#x1b0;&#x1edb;c, r&#x1ed3;i gi&#x1ea3;i n&#xe9;n FreeMind. &#x110;&#x1ec3; ch&#x1ea1;y FreeMind, h&#xe3;y ch&#x1ea1;y t&#x1ead;p tin freemind.sh."/>
<node CREATED="1124560950701" ID="_Freemind_Link_1808511462" MODIFIED="1124560950701" TEXT="Tr&#xea;n Microsoft Windows v&#xe0; Mac OS X, b&#x1ea1;n c&#x169;ng c&#xf3; th&#x1ec3; ch&#x1ec9; c&#x1ea7;n b&#x1ea5;m &#x111;&#xfa;p v&#xe0;o t&#x1ead;p tin freemind.jar n&#x1eb1;m trong th&#x1b0; m&#x1ee5;c lib &#x111;&#x1ec3; kh&#x1edf;i &#x111;&#x1ed9;ng FreeMind."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_353522063" MODIFIED="1124560950701" POSITION="left" TEXT="Duy&#x1ec7;t c&#xe1;c t&#x1ead;p tin c&#xf3; tr&#xea;n m&#xe1;y">
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="&#x110;&#x1ec3; duy&#x1ec7;t c&#xe1;c t&#x1ead;p tin c&#xf3; tr&#xea;n m&#xe1;y, h&#xe3;y chuy&#x1ec3;n sang ch&#x1ebf; &#x111;&#x1ed9; t&#x1ead;p tin b&#x1eb1;ng c&#xe1;ch ch&#x1ecd;n Ch&#x1ebf; &#x111;&#x1ed9; &gt; T&#x1ead;p tin."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Ta c&#xf3; th&#x1ec3; duy&#x1ec7;t c&#xe2;y t&#x1ead;p tin d&#x1b0;&#x1edb;i d&#x1ea1;ng s&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="&#x110;&#x1ec3; chuy&#x1ec3;n m&#x1ed9;t th&#x1b0; m&#x1ee5;c v&#xe0;o th&#xe0;nh n&#xfa;t ch&#xed;nh gi&#x1eef;a s&#x1a1; &#x111;&#x1ed3;, trong tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t, ch&#x1ecd;n V&#xe0;o gi&#x1eef;a."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="&#x110;&#x1ec3; xem, s&#x1eed;a ho&#x1eb7;c th&#x1ef1;c thi m&#x1ed9;t t&#x1ead;p tin, h&#xe3;y m&#x1edf; li&#xea;n k&#x1ebf;t tr&#xea;n n&#xfa;t &#x1ee9;ng v&#x1edb;i n&#xf3;."/>
<node CREATED="1124560950701" ID="_Freemind_Link_279880616" MODIFIED="1124560950701" TEXT="Hi&#x1ec7;n th&#x1edd;i, ch&#x1ebf; &#x111;&#x1ed9; t&#x1ead;p tin ch&#x1b0;a th&#x1ef1;c s&#x1ef1; c&#xf3; &#xed;ch. N&#xf3; ch&#x1ec9; cho ta h&#xec;nh dung &#x111;&#x1b0;&#x1ee3;c r&#x1eb1;ng ta c&#xf3; th&#x1ec3; &#x111;&#x1b0;a d&#x1eef; li&#x1ec7;u v&#xe0;o trong c&#xe2;y t&#x1eeb; nh&#x1eef;ng ngu&#x1ed3;n b&#xea;n ngo&#xe0;i s&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy. T&#xf4;i kh&#xf4;ng ch&#x1eaf;c r&#x1eb1;ng b&#x1ea1;n s&#x1ebd; c&#xf3; l&#xfa;c d&#xf9;ng ch&#x1ebf; &#x111;&#x1ed9; n&#xe0;y."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1530607683" MODIFIED="1124560950701" POSITION="left" TEXT="Duy&#x1ec7;t s&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy">
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="&#x110;&#x1ec3; duy&#x1ec7;t s&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy, nh&#x1b0;ng kh&#xf4;ng hi&#x1ec7;u ch&#x1ec9;nh n&#xf3;, h&#xe3;y chuy&#x1ec3;n sang ch&#x1ebf; &#x111;&#x1ed9; duy&#x1ec7;t b&#x1eb1;ng c&#xe1;ch ch&#x1ecd;n Ch&#x1ebf; &#x111;&#x1ed9; &gt; Duy&#x1ec7;t. Ch&#x1ee9;c n&#x103;ng n&#xe0;y ch&#x1ec9; h&#x1eef;u &#xed;ch khi &#x111;&#x1b0;&#x1ee3;c d&#xf9;ng trong ti&#x1ec3;u d&#x1ee5;ng FreeMind."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="L&#xfd; do ph&#x1ea3;i c&#xf3; m&#x1ed9;t ch&#x1ebf; &#x111;&#x1ed9; duy&#x1ec7;t t&#xe1;ch ri&#xea;ng kh&#x1ecf;i ch&#x1ebf; &#x111;&#x1ed9; S&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy l&#xe0; &#x111;&#x1ec3; ph&#x1ee5;c v&#x1ee5; ti&#x1ec3;u d&#x1ee5;ng FreeMind khi &#x111;&#x103;ng l&#xea;n trang web n&#xe0;o &#x111;&#xf3;. Th&#xf4;ng th&#x1b0;&#x1edd;ng, ta ch&#x1eb3;ng bao gi&#x1edd; d&#xf9;ng ch&#x1ebf; &#x111;&#x1ed9; n&#xe0;y b&#xea;n trong ch&#x1b0;&#x1a1;ng tr&#xec;nh c&#x1ea3;."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1136088046" MODIFIED="1124560950701" POSITION="left" TEXT="V&#x1ec1; c&#xe1;c ch&#x1ebf; &#x111;&#x1ed9;">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1713057526" MODIFIED="1212776176900" TEXT="D&#xf9; Freemind ch&#x1ec9; th&#x1b0;&#x1edd;ng &#x111;&#x1b0;&#x1ee3;c d&#xf9;ng trong vi&#x1ec7;c v&#x1ebd; c&#xe1;c s&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy, ch&#x1b0;&#x1a1;ng tr&#xec;nh c&#xf2;n cho ph&#xe9;p bi&#x1ec3;u di&#x1ec5;n d&#x1eef; li&#x1ec7;u t&#x1eeb; nh&#x1eef;ng ngu&#x1ed3;n kh&#xe1;c nhau. &#x110;&#x1ec3; ch&#x1b0;&#x1a1;ng tr&#xec;nh bi&#x1ec3;u di&#x1ec5;n &#x111;&#x1b0;&#x1ee3;c m&#x1ed9;t ngu&#x1ed3;n d&#x1eef; li&#x1ec7;u n&#xe0;o &#x111;&#xf3;, nh&#xe0; l&#x1ead;p tr&#xec;nh ph&#x1ea3;i vi&#x1ebf;t m&#x1ed9;t ch&#x1ebf; &#x111;&#x1ed9; &#x111;&#x1ec3; xem d&#x1eef; li&#x1ec7;u cho ngu&#x1ed3;n m&#xec;nh c&#x1ea7;n x&#x1eed; l&#xfd;. Ch&#x1ebf; &#x111;&#x1ed9; T&#x1ead;p tin l&#xe0; m&#x1ed9;t v&#xed; d&#x1ee5; v&#x1ec1; vi&#x1ec7;c n&#xe0;y. Nh&#xf3;m ph&#xe1;t tri&#x1ec3;n kh&#xf4;ng bi&#x1ebf;t &#x111;&#x1b0;&#x1ee3;c s&#x1ebd; c&#xf3; bao nhi&#xea;u ch&#x1ebf; &#x111;&#x1ed9; &#x111;&#x1b0;&#x1ee3;c vi&#x1ebf;t ra sau n&#xe0;y, c&#x169;ng nh&#x1b0; c&#xf3; bao nhi&#xea;u ng&#x1b0;&#x1edd;i s&#x1ebd; t&#x1ead;n d&#x1ee5;ng &#x111;&#x1b0;&#x1ee3;c &#x111;&#x1eb7;c &#x111;i&#x1ec3;m n&#xe0;y. N&#x1ebf;u b&#x1ea1;n c&#x1ea7;n l&#x1ea5;y d&#x1eef; li&#x1ec7;u t&#x1eeb; m&#x1ed9;t ngu&#x1ed3;n kh&#xe1;c, h&#xe3;y th&#x1eed; xem!">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_700085988" MODIFIED="1212776316199" TEXT="Hi&#x1ec7;n &#x111;&#xe3; c&#xf3; m&#xe3; ngu&#x1ed3;n cho ch&#x1ebf; &#x111;&#x1ed9; x&#x1eed; l&#xfd; s&#x1a1; &#x111;&#x1ed3;. Kh&#xf4;ng gi&#x1ed1;ng nh&#x1b0; ch&#x1ebf; &#x111;&#x1ed9; S&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy, c&#xe1;c ch&#x1ebf; &#x111;&#x1ed9; kh&#xe1;c th&#x1b0;&#x1edd;ng ch&#x1ec9; &#x111;&#x1ec3; bi&#x1ec3;u di&#x1ec5;n c&#x1ea5;u tr&#xfa;c v&#xe0; t&#xed;nh n&#x103;ng c&#x1ee7;a ch&#x1b0;&#x1a1;ng tr&#xec;nh, h&#x1a1;n l&#xe0; c&#xf3; t&#xe1;c d&#x1ee5;ng th&#x1ef1;c s&#x1ef1; trong &#x111;&#x1edd;i s&#x1ed1;ng.">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1525986009" MODIFIED="1212775956312" POSITION="left" TEXT="C&#xe0;i &#x111;&#x1eb7;t ti&#x1ec3;u d&#x1ee5;ng FreeMind v&#xe0;o 1 trang web">
<node COLOR="#000000" CREATED="1124560950701" ID="Freemind_Link_1795495302" MODIFIED="1213147541802" TEXT="C&#xf3; th&#x1ec3; c&#xe0;i &#x111;&#x1eb7;t ti&#x1ec3;u d&#x1ee5;ng Freemind l&#xea;n trang web &#x111;&#x1ec3; ng&#x1b0;&#x1edd;i d&#xf9;ng xem c&#xe1;c s&#x1a1; &#x111;&#x1ed3; tr&#xea;n &#x111;&#xf3;.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1776430598" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1213147559788" TEXT="T&#x1ea3;i ti&#x1ec3;u d&#x1ee5;ng Freemind-browser v&#x1ec1;."/>
<node CREATED="1124560950701" ID="Freemind_Link_758844596" MODIFIED="1213147633070" TEXT="Kho n&#xe9;n &#x111;&#x1b0;&#x1ee3;c t&#x1ea3;i v&#x1ec1; s&#x1ebd; bao g&#x1ed3;m c&#xe1;c t&#x1ead;p tin freemindbrowser.jar v&#xe0; freemindbrowser.html. T&#x1ea1;o li&#xea;n k&#x1ebf;t t&#x1eeb; trang web t&#x1edb;i trang freemindbrowser.html. Trong t&#x1ead;p tin freemindbrowser.html, h&#xe3;y &#x111;&#x1ed5;i l&#x1ea1;i &#x111;&#x1b0;&#x1edd;ng d&#x1eab;n &#x111;&#x1ec3; n&#xf3; ch&#x1ec9; t&#x1edb;i s&#x1a1; &#x111;&#x1ed3; c&#x1ea7;n cho ng&#x1b0;&#x1edd;i kh&#xe1;c xem."/>
<node CREATED="1124560950701" ID="Freemind_Link_939698300" MODIFIED="1213147706542" TEXT="T&#x1ead;p tin jar ph&#x1ea3;i &#x111;&#x1b0;&#x1ee3;c &#x111;&#x1eb7;t tr&#xea;n m&#xe1;y ch&#x1ee7; ch&#x1ee9;a c&#xe1;c s&#x1a1; &#x111;&#x1ed3;, v&#xec; y&#xea;u c&#x1ea7;u b&#x1ea3;o m&#x1ead;t c&#x1ee7;a java. B&#x1ea1;n s&#x1ebd; ph&#x1ea3;i &#x111;&#x1b0;a c&#xe1;c s&#x1a1; &#x111;&#x1ed3; l&#xea;n c&#xf9;ng v&#x1edb;i t&#x1ead;p tin jar c&#x1ee7;a Freemind l&#xea;n trang web c&#x1ee7;a m&#xec;nh."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1083756111" MODIFIED="1212775897175" POSITION="left" TEXT="S&#x1eed; d&#x1ee5;ng ti&#x1ec3;u d&#x1ee5;ng FreeMind">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_514864900" MODIFIED="1212776444244" TEXT="Trong ti&#x1ec3;u d&#x1ee5;ng FreeMind, b&#x1ea1;n ch&#x1ec9; c&#xf3; th&#x1ec3; d&#xf9;ng ch&#x1ebf; &#x111;&#x1ed9; duy&#x1ec7;t; b&#x1ea1;n kh&#xf4;ng th&#x1ec3; hi&#x1ec7;u ch&#x1ec9;nh s&#x1a1; &#x111;&#x1ed3; t&#x1eeb; xa. B&#x1ea5;m v&#xe0;o m&#x1ed9;t n&#xfa;t &#x111;&#x1ec3; m&#x1edf; r&#x1ed9;ng ho&#x1eb7;c thu g&#x1ecd;n, ho&#x1eb7;c m&#x1edf; li&#xea;n k&#x1ebf;t t&#x1ea1;i n&#xfa;t &#x111;&#xf3;. Mu&#x1ed1;n di chuy&#x1ec3;n b&#xea;n trong s&#x1a1; &#x111;&#x1ed3;, b&#x1ea1;n b&#x1ea5;m chu&#x1ed9;t v&#xe0;o n&#x1ec1;n v&#xe0; di sang v&#x1ecb; tr&#xed; kh&#xe1;c. &#x110;&#x1ec3; t&#xec;m ki&#x1ebf;m b&#xea;n trong s&#x1a1; &#x111;&#x1ed3;, h&#xe3;y d&#xf9;ng tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh d&#xe0;nh cho n&#xfa;t.">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_784043927" MODIFIED="1212775921719" POSITION="left" TEXT="C&#xf4;ng tr&#x1ea1;ng">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_415458128" MODIFIED="1213147137068" TEXT="C&#xe1;c t&#xe1;c gi&#x1ea3;">
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1896457660" MODIFIED="1124560950701" TEXT="Joerg Mueller">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:ponders@t-online.de" MODIFIED="1124560950701" TEXT="ponders@t-online.de">
<font NAME="Dialog" SIZE="10"/>
</node>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="University of Freiburg, Germany">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_984984595" LINK="http://mujweb.cz/www/danielpolansky" MODIFIED="1124560950701" TEXT="Daniel Polansky">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_459203293" MODIFIED="1124560950701" TEXT="Petr Novak">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_875814410" MODIFIED="1124560950701" TEXT="Christian Foltin">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:christian.foltin@gmx.de" MODIFIED="1124560950701" TEXT="christian.foltin@gmx.de">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1415293905" MODIFIED="1124560950701" TEXT="Dimitri Polivaev">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_816166020" MODIFIED="1213147145506" TEXT="Nh&#x1eef;ng ng&#x1b0;&#x1edd;i &#x111;&#xf3;ng g&#xf3;p">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1797108956" MODIFIED="1124560950701" TEXT="Andrew Iggleden">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Installer Windows">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1096673251" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Eclipse howto">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1024053399" MODIFIED="1124560950701" TEXT="David Butt">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Tutorial flash">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_226818637" MODIFIED="1124560950701" TEXT="David Low">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Helpful">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_360501151" MODIFIED="1213147151585" TEXT="D&#x1ecb;ch gi&#x1ea3;">
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_807977431" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Italian translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1853214917" MODIFIED="1124560950701" TEXT="Knud Riish&#xf8;jg&#xe5;rd">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Danish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1676529317" MODIFIED="1124560950701" TEXT="Takeshi Kakeda">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562983644" FOLDED="true" ID="Freemind_Link_1172193026" MODIFIED="1124562984816" TEXT="Kohichi Aoki">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_74531183" MODIFIED="1124560950701" TEXT="Alex Dukal">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562998159" FOLDED="true" ID="Freemind_Link_757563697" MODIFIED="1124563008034" TEXT="Hugo Gayosso">
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1783275246" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_929540960" MODIFIED="1124560950701" TEXT="Sylvain Gamel">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="French translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" FOLDED="true" ID="Freemind_Link_946171164" MODIFIED="1124561245019" TEXT="Koen Roggemans">
<node COLOR="#999999" CREATED="1124561245957" ID="Freemind_Link_1819881845" MODIFIED="1124561251675" TEXT="Dutch translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" FOLDED="true" ID="Freemind_Link_235962981" MODIFIED="1124561376718" TEXT="Rafal Kraik">
<node COLOR="#999999" CREATED="1124561377702" ID="Freemind_Link_459079511" MODIFIED="1124561382155" TEXT="Polish translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561969717" FOLDED="true" ID="Freemind_Link_653284985" MODIFIED="1124561972920" TEXT="Goliath">
<node COLOR="#999999" CREATED="1124561438294" ID="Freemind_Link_1387213811" MODIFIED="1124561445950" TEXT="Korean translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561753254" FOLDED="true" ID="Freemind_Link_35211963" MODIFIED="1124563712385" TEXT="Miles a.k.a. filmsi">
<node COLOR="#999999" CREATED="1124561491886" ID="Freemind_Link_835144271" MODIFIED="1124561506386" TEXT="Slovenian translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561814721" FOLDED="true" ID="Freemind_Link_1008886206" MODIFIED="1124561818580" TEXT="William Chen">
<node COLOR="#999999" CREATED="1124561497308" ID="Freemind_Link_1960552629" MODIFIED="1124561506011" TEXT="Chinese translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561823877" FOLDED="true" ID="Freemind_Link_1650138043" MODIFIED="1124561876907" TEXT="Radek &#x160;varc">
<node COLOR="#999999" CREATED="1124561515761" ID="Freemind_Link_768227373" MODIFIED="1124561519885" TEXT="Czech translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562250475" FOLDED="true" ID="Freemind_Link_901975324" MODIFIED="1124562252007" TEXT="Bal&#xe1;zs M&#xe1;rton">
<node COLOR="#999999" CREATED="1124562252585" ID="Freemind_Link_557911120" MODIFIED="1124562258428" TEXT="Hungarian translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562948942" FOLDED="true" ID="Freemind_Link_290351026" MODIFIED="1124562950270" TEXT="Luis Ferreira ">
<node COLOR="#999999" CREATED="1124562956332" ID="Freemind_Link_6081004" MODIFIED="1124562961879" TEXT="Portuguese translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1213147159232" FOLDED="true" ID="Freemind_Link_1061045577" MODIFIED="1213147225461" TEXT="Nguy&#x1ec5;n &#x110;&#xec;nh Trung">
<edge COLOR="#808080" WIDTH="thin"/>
<node COLOR="#999999" CREATED="1213147189082" ID="Freemind_Link_1638585257" MODIFIED="1213147216201" TEXT="Vietnamese translation">
<edge COLOR="#808080" WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124563066204" ID="Freemind_Link_23652566" MODIFIED="1124563189197" TEXT="The credits for translations are probably incomplete. If we have forggoten you, let us know. All people who we know to contribute a least an incomplete translation are listed.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="Freemind_Link_1601947891" MODIFIED="1212776538748" POSITION="right" TEXT="Ctrl + F &#x111;&#x1ec3; t&#xec;m. Ctrl + G &#x111;&#x1ec3; t&#xec;m ti&#x1ebf;p. &#x110;&#x1ec3; t&#xec;m to&#xe0;n b&#x1ed9; s&#x1a1; &#x111;&#x1ed3;, nh&#x1ea5;n Esc tr&#x1b0;&#x1edb;c khi t&#xec;m"/>
<node COLOR="#0033ff" CREATED="1124560950701" ID="Freemind_Link_1925380454" MODIFIED="1212776582485" POSITION="right" TEXT="Nh&#x1ea5;n m&#x169;i t&#xea;n ph&#x1ea3;i &#x111;&#x1ec3; m&#x1edf; r&#x1ed9;ng 1 &#xf4; v&#x103;n b&#x1ea3;n."/>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1596161299" MODIFIED="1212776590278" POSITION="right" TEXT="Gi&#x1edb;i thi&#x1ec7;u">
<node CREATED="1124560950701" ID="Freemind_Link_491870889" MODIFIED="1212776709356" TEXT="FreeMind gi&#xfa;p ta t&#x1ea1;o ra c&#xe1;c s&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy. Hi&#x1ec7;n nay, r&#x1ea5;t nhi&#x1ec1;u ng&#x1b0;&#x1edd;i d&#xf9;ng s&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy thay cho s&#x1ed5; ghi nh&#x1edb; ho&#x1eb7;c gi&#x1ea5;y nh&#x1eaf;c vi&#x1ec7;c, &#x111;&#x1ec3; qu&#x1ea3;n l&#xfd; th&#xf4;ng tin c&#xe1; nh&#xe2;n."/>
<node CREATED="1124560950701" ID="Freemind_Link_1952418424" MODIFIED="1212776749187" TEXT="Th&#xf4;ng tin &#x111;&#x1b0;&#x1ee3;c l&#x1b0;u trong c&#xe1;c &#xf4; v&#x103;n b&#x1ea3;n, g&#x1ecd;i l&#xe0; n&#xfa;t. C&#xe1;c n&#xfa;t &#x111;&#x1b0;&#x1ee3;c n&#x1ed1;i v&#x1edb;i nhau th&#xf4;ng qua c&#xe1;c &#x111;&#x1b0;&#x1edd;ng n&#x1ed1;i."/>
<node CREATED="1124560950701" ID="Freemind_Link_626602938" MODIFIED="1212777070820" TEXT="T&#xe0;i li&#x1ec7;u n&#xe0;y &#xe1;p d&#x1ee5;ng cho FreeMind 0.8.0. C&#xe1;c ph&#xed;m t&#x1eaf;t v&#xe0; v&#x1ecb; tr&#xed; c&#xe1;c l&#x1ec7;nh tr&#xea;n thanh tr&#xec;nh &#x111;&#x1a1;n c&#xf3; th&#x1ec3; thay &#x111;&#x1ed5;i trong c&#xe1;c phi&#xea;n b&#x1ea3;n t&#x1edb;i."/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_706084071" MODIFIED="1212777082295" POSITION="right" TEXT="Tr&#xec;nh di&#x1ec5;n m&#x1ed9;t s&#x1ed1; t&#xed;nh n&#x103;ng">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_735193624" MODIFIED="1212777551435" TEXT="Di&#x1ec7;n m&#x1ea1;o">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_990796211" MODIFIED="1212777213835" TEXT="M&#x1ed7;i n&#xfa;t c&#xf3; th&#x1ec3; c&#xf3; m&#x1ed9;t m&#xe0;u ri&#xea;ng">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1124560950701" ID="Freemind_Link_1928775947" MODIFIED="1212777159263" TEXT="&#x110;&#x1ecf;">
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#009900" CREATED="1124560950701" ID="Freemind_Link_1270985808" MODIFIED="1212777153600" TEXT="Xanh l&#xe1; c&#xe2;y">
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#0000cc" CREATED="1124560950701" ID="Freemind_Link_1751102424" MODIFIED="1212777147831" TEXT="Xanh n&#x1b0;&#x1edb;c bi&#x1ec3;n">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_" MODIFIED="1212777209261" TEXT="M&#x1ed7;i n&#xfa;t c&#xf3; th&#x1ec3; c&#xf3; m&#x1ed9;t m&#xe0;u n&#x1ec1;n ri&#xea;ng">
<node BACKGROUND_COLOR="#17a4f4" CREATED="1124560950701" ID="_Freemind_Link_1358611533" MODIFIED="1212777276140" TEXT="Th&#x1ebf; n&#xe0;y"/>
<node BACKGROUND_COLOR="#f4c317" CREATED="1124560950701" ID="_Freemind_Link_1317973766" MODIFIED="1212777257400" TEXT="Ho&#x1eb7;c th&#x1ebf; n&#xe0;y"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1213254128" MODIFIED="1212777308799" TEXT="M&#x1ed7;i n&#xfa;t c&#xf3; ki&#x1ec3;u ch&#x1eef; ri&#xea;ng">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_578683610" MODIFIED="1212777358885" TEXT="Ch&#x1eef; &#x111;&#x1ead;m">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_706890134" MODIFIED="1212777370515" TEXT="Ch&#x1eef; nghi&#xea;ng">
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1978135326" MODIFIED="1212777390992" TEXT="Ch&#x1eef; v&#x1eeb;a &#x111;&#x1ead;m v&#x1eeb;a nghi&#xea;ng">
<font BOLD="true" ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1131981254" MODIFIED="1124560950701" TEXT="K&#xed;ch c&#x1ee1; ph&#xf4;ng tr&#xea;n c&#xe1;c n&#xfa;t c&#xf3; th&#x1ec3; kh&#xe1;c nhau">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="nh&#x1ecf;">
<font NAME="Dialog" SIZE="11"/>
</node>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="b&#xec;nh th&#x1b0;&#x1edd;ng">
<font NAME="Dialog" SIZE="13"/>
</node>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="l&#x1edb;n">
<font NAME="Dialog" SIZE="15"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_547633802" MODIFIED="1124560950701" TEXT="L&#x1eda;N">
<font NAME="Dialog" SIZE="20"/>
<node CREATED="1124560950701" ID="Freemind_Link_1471232064" MODIFIED="1212777407803" TEXT="C&#x1ef0;C L&#x1eda;N">
<font NAME="Dialog" SIZE="123"/>
</node>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1920779160" MODIFIED="1212777432244" TEXT="D&#xf9;ng h&#x1ecd; ph&#xf4;ng kh&#xe1;c nhau cho m&#x1ed7;i n&#xfa;t">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_363896058" MODIFIED="1212777444214" TEXT="Times">
<font NAME="Dialog" SIZE="16"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1568731425" MODIFIED="1212777454684" TEXT="Ho&#x1eb7;c Verdana">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_655292275" MODIFIED="1212777478602" TEXT="Ho&#x1eb7;c Arial">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1193071041" MODIFIED="1212777501990" TEXT="N&#xfa;t c&#x169;ng c&#xf3; ki&#x1ec3;u d&#xe1;ng ri&#xea;ng">
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1979277285" MODIFIED="1212777517406" TEXT="V&#x1ea1;ch">
<node CREATED="1124560950701" ID="_Freemind_Link_89124429" MODIFIED="1212777524177" TEXT="V&#x1ea1;ch"/>
<node CREATED="1124560950701" ID="_Freemind_Link_173850525" MODIFIED="1212777528283" TEXT="V&#x1ea1;ch"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1001811541" MODIFIED="1212777512462" STYLE="bubble" TEXT="Bao">
<node CREATED="1124560950701" ID="_Freemind_Link_1677737286" MODIFIED="1212777533715" STYLE="bubble" TEXT="Bao"/>
<node CREATED="1124560950701" ID="_Freemind_Link_978246353" MODIFIED="1212777537373" STYLE="bubble" TEXT="Bao"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_529813828" MODIFIED="1212777568093" TEXT="Thu g&#x1ecd;n c&#xe1;c n&#xfa;t">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_307016912" MODIFIED="1212777574812" TEXT="Thu g&#x1ecd;n">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_445954768" MODIFIED="1212777586138" TEXT="&#x1ea8;n">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1488567837" MODIFIED="1212777578738" TEXT="C&#xe2;y">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_1469000164" MODIFIED="1212777599197" TEXT="S&#x1ed3;i">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1452025216" MODIFIED="1212777636660" TEXT="B&#x1ea1;ch &#x110;&#xe0;n">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1692720585" MODIFIED="1212777644092" TEXT="D&#x1eeb;a">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_926405317" MODIFIED="1124560950701" TEXT="C&#xe1;c n&#xfa;t c&#xf3; th&#x1ec3; ch&#x1ee9;a c&#xe1;c li&#xea;n k&#x1ebf;t m&#x1edf; &#x111;&#x1b0;&#x1ee3;c t&#x1edb;i ... ">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1096564272" MODIFIED="1124560950701" TEXT="c&#xe1;c trang Web">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" LINK="http://www.google.com/" MODIFIED="1124560950701" TEXT="http://www.google.com/">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_840079380" LINK="www.google.com" MODIFIED="1124560950701" TEXT="www.google.com">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Freemind coi &#x111;&#xf3; l&#xe0; th&#x1ef1;c thi &#x111;&#x1b0;&#x1ee3;c :)">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_137912631" MODIFIED="1212777679733" TEXT="C&#xe1;c th&#x1b0; m&#x1ee5;c tr&#xea;n m&#xe1;y">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" LINK="C:/Program Files/" MODIFIED="1124560950701" TEXT="C:/Program Files/">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" LINK="/home/" MODIFIED="1124560950701" TEXT="/home/">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_774013517" MODIFIED="1212777689162" TEXT="C&#xe1;c ch&#x1b0;&#x1a1;ng tr&#xec;nh">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_26552136" LINK="%SystemRoot%\regedit.exe" MODIFIED="1124560950701" TEXT="%SystemRoot%\regedit.exe">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#006600" CREATED="1124560950701" ID="Freemind_Link_741962292" MODIFIED="1212777731703" TEXT="Nh&#x1eef;ng n&#xfa;t n&#xe0;o ta c&#xf3; th&#x1ec3; kh&#x1edf;i ch&#x1ea1;y &#x111;&#x1b0;&#x1ee3;c th&#xec; s&#x1ebd; c&#xf3; bi&#x1ec3;u t&#x1b0;&#x1ee3;ng b&#xea;n c&#x1ea1;nh">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1730775912" MODIFIED="1212777751830" TEXT="B&#x1ea5;t k&#x1ef3; t&#xe0;i li&#x1ec7;u n&#xe0;o c&#xf3; tr&#xea;n m&#xe1;y ho&#x1eb7;c tr&#xea;n m&#x1ea1;ng n&#x1ed9;i b&#x1ed9; c&#x1ee7;a c&#xf4;ng ty b&#x1ea1;n">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_839677176" MODIFIED="1212777781964" TEXT="N&#xfa;t c&#xf3; nhi&#x1ec1;u d&#xf2;ng">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1423568963" MODIFIED="1212778004892" TEXT="B&#x1ea1;n c&#xf3; th&#x1ec3; xem c&#xe1;c n&#xfa;t nhi&#x1ec1;u d&#xf2;ng gi&#x1ed1;ng nh&#x1b0; m&#x1ed9;t &#x111;o&#x1ea1;n v&#x103;n ho&#x1eb7;c th&#x1ead;m ch&#xed; v&#xe0;i &#x111;o&#x1ea1;n v&#x103;n. N&#x1ebf;u b&#x1ea1;n d&#xf9;ng FreeMind &#x111;&#x1ec3; t&#x1ed5;ng h&#x1ee3;p ki&#x1ebf;n th&#x1ee9;c cho m&#xec;nh, &#x111;i&#x1ec1;u n&#xe0;y c&#x1ef1;c k&#x1ef3; kh&#xf3; tr&#xe1;nh. Thay v&#xec; ph&#x1ea3;i t&#x1ea1;o ra m&#x1ed9;t t&#x1ead;p tin kh&#xe1;c &#x111;&#x1ec3; ghi c&#xe1;c l&#x1b0;u &#xfd;, b&#x1ea1;n c&#xf3; th&#x1ec3; t&#x1ea1;o m&#x1ed9;t n&#xfa;t ng&#x1eaf;n v&#x1edb;i nhi&#x1ec1;u n&#xfa;t c&#x1ea5;p con c&#xf3; nhi&#x1ec1;u d&#xf2;ng."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1686184172" MODIFIED="1212777863429" TEXT="&quot;Khoa h&#x1ecd;c l&#xe0; s&#x1ef1; th&#x1ead;t; gi&#x1ed1;ng nh&#x1b0; nh&#xe0; &#x111;&#x1b0;&#x1ee3;c l&#xe0;m b&#x1eb1;ng &#x111;&#xe1; v&#x1ead;y, t&#x1ee9;c l&#xe0; khoa h&#x1ecd;c &#x111;&#x1b0;&#x1ee3;c x&#xe2;y d&#x1ef1;ng t&#x1eeb; s&#x1ef1; th&#x1ead;t; nh&#x1b0;ng m&#x1ed9;t &#x111;&#x1ed1;ng &#x111;&#xe1; ch&#x1b0;a ch&#x1eaf;c &#x111;&#xe3; l&#xe0; nh&#xe0;, v&#xe0; m&#x1ed9;t m&#x1edb; s&#x1ef1; th&#x1ead;t th&#xec; kh&#xf4;ng nh&#x1ea5;t thi&#x1ebf;t ph&#x1ea3;i l&#xe0; khoa h&#x1ecd;c.&quot; --Henri Poincar&#xe9;"/>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_5710499" MODIFIED="1212778042305" TEXT="N&#xfa;t nhi&#x1ec1;u d&#xf2;ng ng&#x1eaf;n c&#xf3; xu&#x1ed1;ng d&#xf2;ng">
<node CREATED="1124560950717" ID="_Freemind_Link_1957797574" MODIFIED="1212778070270" TEXT="D&#xf2;ng,&#xa;th&#x1ee9; hai,&#xa;&#xa;th&#xea;m m&#x1ed9;t d&#xf2;ng n&#x1eef;a,&#xa;R&#x1ed3;i, b&#x1ea1;n ngh&#x129; sao?"/>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_331692355" MODIFIED="1212778199926" TEXT="D&#xf9;ng n&#xfa;t &#x111;&#x1ec3; gi&#x1ea3; l&#x1ead;p c&#xe1;c &#x111;&#x1b0;&#x1edd;ng n&#x1ed1;i">
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_810259854" MODIFIED="1212778205938" TEXT="C&#xe2;y">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1736834382" MODIFIED="1212778216365" TEXT="l&#xe0;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1045607374" MODIFIED="1212778233261" TEXT="S&#x1ed3;i">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_238870301" MODIFIED="1212778222678" TEXT="l&#xe0;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_822090058" MODIFIED="1212778260217" TEXT="D&#x1eeb;a">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1142791359" MODIFIED="1212778226462" TEXT="l&#xe0;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_687154358" MODIFIED="1212778269821" TEXT="B&#x1ea1;ch &#x111;&#xe0;n">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_600637247" MODIFIED="1212778211448" TEXT="C&#xe2;y">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1566093997" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1360724162" MODIFIED="1212778284996" TEXT="L&#xe1;">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_874353698" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_442156920" MODIFIED="1212778280357" TEXT="Th&#xe2;n">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="Freemind_Link_1642046031" MODIFIED="1212778124489" TEXT="C&#xf3; th&#x1ec3; th&#xea;m c&#xe1;c bi&#x1ec3;u t&#x1b0;&#x1ee3;ng v&#xe0;o trong n&#xfa;t">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_318937820" MODIFIED="1212778136336" TEXT="N&#xfa;t n&#x1eb1;m trong m&#xe2;y">
<cloud/>
<node CREATED="1124560950717" ID="Freemind_Link_127508145" MODIFIED="1212778144198" TEXT="V&#x1edb;i m&#xe0;u b&#x1ea5;t k&#x1ef3;">
<cloud COLOR="#f1ede6"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1750585847" MODIFIED="1212778302612" TEXT="T&#x1ea1;o c&#xe1;c li&#xea;n k&#x1ebf;t &#x111;&#x1ed3; ho&#x1ea1;">
<node CREATED="1124560950717" ID="_Freemind_Link_1212380407" MODIFIED="1212778315000" TEXT="N&#x1ed1;i n&#xfa;t n&#xe0;y">
<arrowlink DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="41;0;" STARTARROW="None" STARTINCLINATION="41;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1249400461" MODIFIED="1212778320025" TEXT="Sang n&#xfa;t kh&#xe1;c">
<arrowlink COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" STARTARROW="None" STARTINCLINATION="47;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_880551392" MODIFIED="1212778358043" TEXT="M&#xe0;u s&#x1eaf;c kh&#xe1;c nhau">
<arrowlink DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="87;57;" ID="Freemind_Arrow_Link_1672464612" STARTARROW="None" STARTINCLINATION="87;57;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1789233193" MODIFIED="1212778358052" TEXT="V&#xe0; &#x111;&#x1b0;&#x1edd;ng &#x111;i kh&#xe1;c nhau"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_127668276" MODIFIED="1212778379246" TEXT="C&#xf3; th&#x1ec3; &#x111;&#x1eb7;t n&#xfa;t &#x1edf; b&#x1ea5;t c&#x1ee9; &#x111;&#xe2;u">
<node CREATED="1124560950717" ID="_Freemind_Link_894936766" MODIFIED="1212778384220" TEXT="M&#x1ed9;t"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1942481455" MODIFIED="1212778388659" TEXT="N&#x1eef;a"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1709752669" MODIFIED="1212938378923" POSITION="right" TEXT="T&#x1ea1;o v&#xe0; xo&#xe1; n&#xfa;t">
<node CREATED="1124560950717" ID="Freemind_Link_466494929" MODIFIED="1212938410031" TEXT="Nh&#x1ea5;n INSERT &#x111;&#x1ec3; t&#x1ea1;o n&#xfa;t con."/>
<node CREATED="1124560950717" ID="Freemind_Link_1420629436" MODIFIED="1212938456267" TEXT="Nh&#x1ea5;n INSERT trong l&#xfa;c so&#x1ea1;n th&#x1ea3;o n&#xfa;t &#x111;&#x1ec3; t&#x1ea1;o n&#xfa;t con trong khi &#x111;ang so&#x1ea1;n th&#x1ea3;o n&#xfa;t."/>
<node CREATED="1124560950717" ID="Freemind_Link_1862216916" MODIFIED="1212938490736" TEXT="Nh&#x1ea5;n ENTER &#x111;&#x1ec3; t&#x1ea1;o m&#x1ed9;t n&#xfa;t anh b&#xea;n d&#x1b0;&#x1edb;i n&#xfa;t &#x111;ang l&#xe0;m vi&#x1ec7;c."/>
<node CREATED="1124560950717" ID="Freemind_Link_41397605" MODIFIED="1212938512183" TEXT="Nh&#x1ea5;n SHIFT+ENTER &#x111;&#x1ec3; t&#x1ea1;o n&#xfa;t anh b&#xea;n tr&#xea;n n&#xfa;t &#x111;ang l&#xe0;m vi&#x1ec7;c.."/>
<node CREATED="1124560950717" ID="Freemind_Link_1979720125" MODIFIED="1212938527676" TEXT="Nh&#x1ea5;n DELETE &#x111;&#x1ec3; xo&#xe1; n&#xfa;t &#x111;ang ch&#x1ecd;n."/>
<node CREATED="1124560950717" ID="Freemind_Link_635381308" MODIFIED="1212938567744" TEXT="Nh&#x1ea5;n CTRL+X &#x111;&#x1ec3; xo&#xe1; n&#xfa;t nh&#x1b0;ng v&#x1eab;n l&#x1b0;u v&#xe0;o b&#x1ea3;ng nh&#xe1;p &#x111;&#x1ec3; d&#xe1;n l&#x1ea1;i khi c&#x1ea7;n."/>
<node CREATED="1124560950717" ID="Freemind_Link_782501155" MODIFIED="1212938614028" TEXT="C&#x169;ng c&#xf3; th&#x1ec3; b&#x1ea5;m chu&#x1ed9;t ph&#x1ea3;i l&#xea;n n&#xfa;t &#x111;&#x1ec3; m&#x1edf; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1700974092" MODIFIED="1212938627475" POSITION="right" TEXT="So&#x1ea1;n th&#x1ea3;o n&#x1ed9;i dung n&#xfa;t">
<node CREATED="1124560950717" ID="_Freemind_Link_519923426" MODIFIED="1212938697164" TEXT="&#x110;&#x1ec3; so&#x1ea1;n th&#x1ea3;o n&#xfa;t, nh&#x1ea5;n F2, HOME ho&#x1eb7;c END, ho&#x1eb7;c ch&#x1ecd;n S&#x1eed;a trong tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t. &#x110;&#x1ec3; ho&#xe0;n t&#x1ea5;t vi&#x1ec7;c so&#x1ea1;n th&#x1ea3;o, nh&#x1ea5;n ENTER.">
<arrowlink DESTINATION="_Freemind_Link_519923426" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_1179992477" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_371020476" MODIFIED="1212938726075" TEXT="&#x110;&#x1ec3; thay th&#x1ebf; v&#x103;n b&#x1ea3;n trong m&#x1ed9;t n&#xfa;t, h&#xe3;y &#x111;&#xe1;nh v&#x103;n b&#x1ea3;n m&#x1edb;i."/>
<node CREATED="1124560950717" ID="Freemind_Link_49122571" MODIFIED="1212938763739" TEXT="Nh&#x1ea5;n ALT+ENTER &#x111;&#x1ec3; so&#x1ea1;n th&#x1ea3;o &#x1edf; ch&#x1ebf; &#x111;&#x1ed9; n&#xfa;t d&#xe0;i, ngay c&#x1ea3; khi n&#xfa;t &#x111;&#x1b0;&#x1ee3;c ch&#x1ecd;n l&#xe0; n&#xfa;t ng&#x1eaf;n."/>
<node CREATED="1124560950717" ID="Freemind_Link_1849848547" MODIFIED="1212938890183" TEXT="&#x110;&#x1ec3; t&#xe1;ch 1 n&#xfa;t d&#xe0;i, d&#xf9;ng n&#xfa;t T&#xe1;ch n&#xfa;t ho&#x1eb7;c nh&#x1ea5;n ALT+T trong &#xf4; so&#x1ea1;n th&#x1ea3;o n&#xfa;t d&#xe0;i."/>
<node CREATED="1124560950717" ID="Freemind_Link_445809524" MODIFIED="1212939146247" TEXT="&#x110;&#x1ec3; xu&#x1ed1;ng d&#xf2;ng m&#x1edb;i khi so&#x1ea1;n th&#x1ea3;o n&#xfa;t trong &#xf4; so&#x1ea1;n th&#x1ea3;o n&#xfa;t d&#xe0;i, nh&#x1ea5;n CTRL+ENTER. Kh&#xf4;ng th&#x1ec3; xu&#x1ed1;ng d&#xf2;ng khi so&#x1ea1;n th&#x1ea3;o n&#xfa;t ng&#x1eaf;n.">
<arrowlink DESTINATION="_Freemind_Link_1445647544" ENDARROW="Default" ENDINCLINATION="118;0;" ID="Freemind_Arrow_Link_1628309717" STARTARROW="None" STARTINCLINATION="118;0;"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1135920821" MODIFIED="1212939198507" TEXT="&#x110;&#x1ec3; ch&#xe9;p m&#x1ed9;t chu&#x1ed7;i v&#xe0;o trong b&#x1ea3;ng nh&#xe1;p trong khi s&#x1eed;a n&#xfa;t d&#xe0;i, nh&#x1ea5;n ph&#x1ea3;i chu&#x1ed9;t v&#xe0; ch&#x1ecd;n Ch&#xe9;p."/>
<node CREATED="1124560950717" ID="Freemind_Link_1742302905" MODIFIED="1212939252214" TEXT="&#x110;&#x1ec3; ch&#xe8;n c&#xe1;c k&#xfd; t&#x1ef1; &#x111;&#x1eb7;c bi&#x1ec7;t nh&#x1b0; &#xa9;, ch&#xe8;n ch&#xfa;ng trong tr&#xec;nh x&#x1eed; l&#xfd; v&#x103;n b&#x1ea3;n b&#x1ea1;n th&#xed;ch, nh&#x1b0; OpenOffice Writer ho&#x1eb7;c Microsoft Word, r&#x1ed3;i ch&#xe9;p v&#xe0; d&#xe1;n l&#x1ea1;i v&#xe0;o trong FreeMind."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1445647544" MODIFIED="1212939458991" TEXT="Theo thi&#x1ebf;t l&#x1ead;p m&#x1eb7;c &#x111;&#x1ecb;nh, g&#xf5; ENTER &#x111;&#x1ec3; k&#x1ebf;t th&#xfa;c vi&#x1ec7;c so&#x1ea1;n th&#x1ea3;o n&#xfa;t d&#xe0;i, CTRL+ENTER &#x111;&#x1ec3; xu&#x1ed1;ng d&#xf2;ng. Nh&#x1b0;ng n&#x1ebf;u kh&#xf4;ng ch&#x1ecd;n &#xf4; &quot;ENTER &#x111;&#x1ec3; k&#x1ebf;t th&#xfa;c vi&#x1ec7;c so&#x1ea1;n th&#x1ea3;o&quot; th&#xec; ng&#x1b0;&#x1ee3;c l&#x1ea1;i, ENTER s&#x1ebd; xu&#x1ed1;ng d&#xf2;ng v&#xe0; CTRL+ENTER s&#x1ebd; k&#x1ebf;t th&#xfa;c vi&#x1ec7;c so&#x1ea1;n th&#x1ea3;o. Gi&#xe1; tr&#x1ecb; m&#x1eb7;c &#x111;&#x1ecb;nh c&#x1ee7;a &#xf4; n&#xe0;y c&#xf3; th&#x1ec3; &#x111;&#x1b0;&#x1ee3;c thi&#x1ebf;t l&#x1ead;p trong ph&#x1ea7;n Tu&#x1ef3; ch&#x1ec9;nh. Ngo&#xe0;i ra, thi&#x1ebf;t l&#x1ead;p n&#xe0;y c&#xf2;n &#x111;&#x1b0;&#x1ee3;c l&#x1b0;u l&#x1ea1;i trong phi&#xea;n l&#xe0;m vi&#x1ec7;c tr&#xea;n FreeMind."/>
<node CREATED="1124560950717" ID="Freemind_Link_911192475" MODIFIED="1212938950572" TEXT="FreeMind ho&#xe0;n to&#xe0;n h&#x1ed7; tr&#x1ee3; Unicode n&#xea;n b&#x1ea1;n c&#xf3; th&#x1ec3; tho&#x1ea3;i m&#xe1;i s&#x1eed; d&#x1ee5;ng c&#xe1;c k&#xfd; t&#x1ef1; &#x111;&#x1eb7;c bi&#x1ec7;t trong ng&#xf4;n ng&#x1eef; c&#x1ee7;a m&#xec;nh."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1660149394" MODIFIED="1212939494464" POSITION="right" TEXT="&#x110;&#x1ecb;nh d&#x1ea1;ng n&#xfa;t">
<node CREATED="1124560950717" ID="Freemind_Link_901808509" MODIFIED="1212939507793" TEXT="&#x110;&#x1ec3; t&#xf4; &#x111;&#x1ead;m n&#xfa;t, nh&#x1ea5;n CTRL+B">
<edge WIDTH="thin"/>
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_887688331" MODIFIED="1212939523169" TEXT="&#x110;&#x1ec3; l&#xe0;m nghi&#xea;ng n&#xfa;t, nh&#x1ea5;n CTRL+I">
<edge WIDTH="thin"/>
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#6699ff" CREATED="1124560950717" ID="Freemind_Link_449007281" MODIFIED="1212939597449" TEXT="&#x110;&#x1ec3; &#x111;&#x1ed5;i m&#xe0;u ch&#x1eef; trong n&#xfa;t, nh&#x1ea5;n ALT+F.">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
<node BACKGROUND_COLOR="#ffff00" CREATED="1124560950717" ID="Freemind_Link_951654340" MODIFIED="1212939683537" TEXT="&#x110;&#x1ec3; &#x111;&#x1ed5;i m&#xe0;u n&#x1ec1;n c&#x1ee7;a n&#xfa;t, b&#x1ea5;m chu&#x1ed9;t ph&#x1ea3;i &#x111;&#x1ec3; m&#x1edf; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh v&#xe0; ch&#x1ecd;n &#x110;&#x1ecb;nh d&#x1ea1;ng &gt; M&#xe0;u n&#x1ec1;n."/>
<node CREATED="1124560950717" ID="Freemind_Link_466308270" MODIFIED="1212939765548" TEXT="&#x110;&#x1ec3; t&#x103;ng c&#x1ee1; ph&#xf4;ng cho n&#xfa;t, nh&#x1ea5;n CTRL++(kh&#xf4;ng ph&#x1ea3;i d&#x1ea5;u + trong &#xf4; s&#x1ed1;).">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="13"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_440360564" MODIFIED="1212939823815" TEXT="&#x110;&#x1ec3; gi&#x1ea3;m c&#x1ee1; ph&#xf4;ng cho n&#xfa;t, nh&#x1ea5;n CTRL+- (kh&#xf4;ng ph&#x1ea3;i d&#x1ea5;u - trong &#xf4; s&#x1ed1;).">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="11"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_652089543" MODIFIED="1212939860165" TEXT="&#x110;&#x1ec3; &#x111;&#x1ed5;i h&#x1ecd; ph&#xf4;ng, d&#xf9;ng &#xf4; n&#x1eb1;m tr&#xea;n thanh c&#xf4;ng c&#x1ee5; ch&#xed;nh.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_148953194" MODIFIED="1212939883261" TEXT="&#x110;&#x1ec3; ch&#xe9;p &#x111;&#x1ecb;nh d&#x1ea1;ng c&#x1ee7;a n&#xfa;t, nh&#x1ea5;n ALT+C"/>
<node CREATED="1124560950717" ID="Freemind_Link_1790383058" MODIFIED="1213113746548" TEXT="&#x110;&#x1ec3; d&#xe1;n &#x111;&#x1ecb;nh d&#x1ea1;ng v&#xe0;o n&#xfa;t kh&#xe1;c, nh&#x1ea5;n ALT+V.">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_526328879" MODIFIED="1124560950717" POSITION="right" TEXT="D&#xf9;ng ki&#x1ec3;u d&#xe1;ng hi&#x1ec7;n tr&#x1ea1;ng">
<node CREATED="1124560950717" ID="Freemind_Link_1931253902" MODIFIED="1213115031324" TEXT="&#x110;&#x1ec3; d&#xf9;ng m&#x1ed9;t ki&#x1ec3;u d&#xe1;ng hi&#x1ec7;n tr&#x1ea1;ng, trong tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh cho n&#xfa;t, ch&#x1ecd;n Ki&#x1ec3;u d&#xe1;ng hien&#x1eb9; tr&#x1ea1;ng &gt; Ki&#x1ec3;u d&#xe1;ng b&#x1ea1;n c&#x1ea7;n. &#x110;&#x1ec3; th&#x1ef1;c hi&#x1ec7;n vi&#x1ec7;c n&#xe0;y m&#x1ed9;t c&#xe1;ch nhanh ch&#xf3;ng, h&#xe3;y d&#xf9;ng c&#xe1;c ph&#xed;m t&#x1eaf;t nh&#x1b0; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh &#x111;&#xe3; ch&#x1ec9; ra."/>
<node CREATED="1124560950717" ID="Freemind_Link_607716845" MODIFIED="1213115115676" TEXT="&#x110;&#x1ec3; th&#xea;m c&#xe1;c ki&#x1ec3;u d&#xe1;ng hi&#x1ec7;n tr&#x1ea1;ng c&#x1ea7;n d&#xf9;ng, xin b&#x1ea1;n h&#xe3;y s&#x1eed;a l&#x1ea1;i t&#x1ead;p tin &quot;patterns.xml&quot; n&#x1eb1;m trong th&#x1b0; m&#x1ee5;c &quot;.freemind&quot; &#x1edf; th&#x1b0; m&#x1ee5;c ch&#xed;nh c&#x1ee7;a b&#x1ea1;n."/>
<node CREATED="1124560950717" ID="Freemind_Link_214851566" MODIFIED="1213115231404" TEXT="L&#x1b0;u &#xfd; l&#xe0; tr&#xea;n t&#x1ead;p tin patterns.xml, c&#xe1;c ki&#x1ec3;u d&#xe1;ng hi&#x1ec7;n tr&#x1ea1;ng d&#xf9;ng cho n&#xfa;t &#x111;&#x1b0;&#x1ee3;c &#x111;&#xe1;nh d&#x1ea5;u b&#x1eb1;ng th&#x1ebb; &lt;node&gt;. V&#x1edb;i c&#xe1;c &#x111;&#x1b0;&#x1edd;ng n&#x1ed1;i, th&#x1ebb; t&#x1b0;&#x1a1;ng &#x1ee9;ng l&#xe0; th&#x1ebb; &lt;edge&gt;. Th&#x1ebb; &lt;node&gt; c&#xf3; th&#x1ec3; ch&#x1ee9;a th&#x1ebb; &lt;font&gt; ch&#x1ec9;nh ph&#xf4;ng ch&#x1eef;. Xin xem t&#x1ead;p tin &quot;patterns.xml&quot; &#x111;i k&#xe8;m ch&#x1b0;&#x1a1;ng tr&#xec;nh &#x111;&#x1ec3; bi&#x1ebf;t c&#x1ee5; th&#x1ec3; h&#x1a1;n."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1697687428" MODIFIED="1213115890776" POSITION="right" TEXT="D&#xf9;ng m&#xe2;y &#x111;&#x1ec3; t&#xf4; &#x111;&#x1ead;m c&#xe1;c n&#xfa;t">
<node CREATED="1124560950717" ID="Freemind_Link_544523668" MODIFIED="1213115744169" TEXT="Ta v&#x1ebd; c&#xe1;c &#x111;&#xe1;m m&#xe2;y &#x111;&#x1ec3; t&#xf4; &#x111;&#x1ead;m m&#x1ed9;t v&#xf9;ng n&#xe0;o &#x111;&#xf3;. V&#xf9;ng &#x111;&#x1b0;&#x1ee3;c t&#xf4; &#x111;&#x1ead;m bao g&#x1ed3;m n&#xfa;t v&#xe0; c&#xe1;c n&#xfa;t con c&#x1ee7;a n&#xf3;."/>
<node CREATED="1124560950717" ID="Freemind_Link_1648784490" MODIFIED="1213115790803" TEXT="&#x110;&#x1ec3; th&#xea;m m&#x1ed9;t &#x111;&#xe1;m m&#xe2;y, nh&#x1ea5;n CTRL + SHIFT + B ho&#x1eb7;c m&#x1edf; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t v&#xe0; Ch&#xe8;n &gt; M&#xe2;y."/>
<node CREATED="1124560950717" ID="Freemind_Link_1284312875" MODIFIED="1213115825640" TEXT="&#x110;&#x1ec3; &#x111;&#x1ed5;i m&#xe0;u cho &#x111;&#xe1;m m&#xe2;y, m&#x1edf; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t v&#xe0; ch&#x1ecd;n &#x110;&#x1ecb;nh d&#x1ea1;ng &gt; M&#xe0;u m&#xe2;y."/>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1236353835" MODIFIED="1213115861772" TEXT="Ta c&#xf3; th&#x1ec3; t&#xf4; m&#xe2;y m&#xe0;u xanh...">
<cloud COLOR="#e1f2e1"/>
<node CREATED="1124560950717" ID="Freemind_Link_566702024" MODIFIED="1213115868739" TEXT="... ho&#x1eb7;c m&#xe0;u n&#xe2;u, n&#x1ebf;u th&#xed;ch.">
<cloud COLOR="#ede5d5"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_203858515" MODIFIED="1212778458695" POSITION="right" TEXT="Th&#xea;m si&#xea;u li&#xea;n k&#x1ebf;t">
<node CREATED="1124560950717" ID="Freemind_Link_758407944" MODIFIED="1213116016725" TEXT="&#x110;&#x1ec3; ch&#xe8;n si&#xea;u li&#xea;n k&#x1ebf;t v&#xe0;o n&#xfa;t, nh&#x1ea5;n Ctrl + K ho&#x1eb7;c m&#x1edf; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t v&#xe0; ch&#x1ecd;n Ch&#xe8;n &gt; Si&#xea;u li&#xea;n k&#x1ebf;t"/>
<node CREATED="1124560950717" ID="Freemind_Link_843180508" MODIFIED="1213116059133" TEXT="&#x110;&#x1ec3; xo&#xe1; si&#xea;u li&#xea;n k&#x1ebf;t, xo&#xe1; &#xf4; ch&#x1ee9;a si&#xea;u li&#xea;n k&#x1ebf;t th&#xe0;nh chu&#x1ed7;i r&#x1ed7;ng sau khi nh&#x1ea5;n Ctrl + K."/>
<node CREATED="1124560950717" ID="Freemind_Link_460506507" MODIFIED="1213116116691" TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &#x110;&#x1ec3; li&#xea;n k&#x1ebf;t t&#x1edb;i m&#x1ed9;t &#x111;&#x1ecb;a ch&#x1ec9; th&#x1b0; &#x111;i&#x1ec7;n t&#x1eed;, h&#xe3;y &#x111;&#x1ec3; si&#xea;u li&#xea;n k&#x1ebf;t d&#x1ea1;ng &lt;i&gt;mailto:don.bonton@supermail.com&lt;/i&gt;.&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;&#xa;">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1893502301" MODIFIED="1213116243122" TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &#x110;&#x1ec3; t&#x1ea1;o li&#xea;n k&#x1ebf;t t&#x1edb;i &#x111;&#x1ecb;a ch&#x1ec9; th&#x1b0; &#x111;i&#x1ec7;n t&#x1eed;, c&#xf3; th&#xea;m &#x111;&#x1ea7;u &#x111;&#x1ec1; th&#x1b0;, h&#xe3;y &#x111;&#x1eb7;t si&#xea;u li&#xea;n k&#x1ebf;t theo d&#x1ea1;ng &lt;i&gt;mailto:don.bonton@supermail.com?subject=Last &#xa;    phone call&lt;/i&gt;.&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;&#xa;"/>
<node CREATED="1124560950717" ID="Freemind_Link_654534923" MODIFIED="1213116285868" TEXT="Si&#xea;u li&#xea;n k&#x1ebf;t c&#xf3; th&#x1ec3; tr&#x1ecf; t&#x1edb;i trang web, c&#xe1;c t&#x1ead;p tin tr&#xea;n m&#xe1;y, ho&#x1eb7;c h&#xf2;m th&#x1b0; &#x111;i&#x1ec7;n t&#x1eed;."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1044397139" MODIFIED="1212778452263" POSITION="right" TEXT="Th&#xea;m bi&#x1ec3;u t&#x1b0;&#x1ee3;ng">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1829828780" MODIFIED="1213116335125" TEXT="C&#xf3; th&#x1ec3; th&#xea;m nhi&#x1ec1;u bi&#x1ec3;u t&#x1b0;&#x1ee3;ng cho n&#xfa;t."/>
<node CREATED="1124560950717" ID="Freemind_Link_749910938" MODIFIED="1213116457034" TEXT="&#x110;&#x1ec3; ch&#xe8;n bi&#x1ec3;u t&#x1b0;&#x1ee3;ng v&#xe0;o n&#xfa;t, ch&#x1ecd;n m&#x1ed9; n&#xfa;t v&#xe0; nh&#x1ea5;n m&#x1ed9;t trong c&#xe1;c bi&#x1ec3;u t&#x1b0;&#x1ee3;ng n&#x1eb1;m &#x1edf; thanh l&#x1ec1; tr&#xe1;i. Khi di chuy&#x1ec3;n con tr&#x1ecf; sang thanh l&#x1ec1; tr&#xe1;i, gi&#x1eef; ALT ho&#x1eb7;c CONTROL &#x111;&#x1ec3; khi chu&#x1ed9;t qua m&#x1ed9;t n&#xfa;t kh&#xe1;c, n&#xfa;t c&#x169; v&#x1eab;n &#x111;&#x1b0;&#x1ee3;c ch&#x1ecd;n."/>
<node CREATED="1124560950717" ID="Freemind_Link_1459983426" MODIFIED="1213116553045" TEXT="&#x110;&#x1ec3; xo&#xe1; m&#x1ed9;t bi&#x1ec3;u t&#x1b0;&#x1ee3;ng, nh&#x1ea5;n v&#xe0;o h&#xec;nh ch&#x1eef; X &#x111;&#x1ecf; tr&#xea;n thanh l&#x1ec1; tr&#xe1;i."/>
<node CREATED="1124560950717" ID="Freemind_Link_27863108" MODIFIED="1213116559061" TEXT="&#x110;&#x1ec3; xo&#xe1; t&#x1ea5;t c&#x1ea3; c&#xe1;c bi&#x1ec3;u t&#x1b0;&#x1ee3;ng, nh&#x1ea5;n v&#xe0;o h&#xec;nh th&#xf9;ng r&#xe1;c tr&#xea;n thanh l&#x1ec1; tr&#xe1;i."/>
<node CREATED="1124560950717" ID="Freemind_Link_866741606" MODIFIED="1213116587601" TEXT="Ngo&#xe0;i c&#xe1;ch ch&#x1ecd;n bi&#x1ec3;u t&#x1b0;&#x1ee3;ng tr&#xea;n thanh l&#x1ec1; tr&#xe1;i ra, ta c&#xf3; th&#x1ec3; nh&#x1ea5;n Alt + I."/>
<node CREATED="1124560950717" ID="Freemind_Link_1888291966" MODIFIED="1213116630917" TEXT="Ngo&#xe0;i c&#xe1;c bi&#x1ec3;u t&#x1b0;&#x1ee3;ng &#x111;&#x1b0;&#x1ee3;c Freemind cung c&#x1ea5;p, b&#x1ea1;n kh&#xf4;ng th&#x1ec3; d&#xf9;ng c&#xe1;c bi&#x1ec3;u t&#x1b0;&#x1ee3;ng n&#xe0;o kh&#xe1;c."/>
<node CREATED="1124560950717" ID="Freemind_Link_1922517135" MODIFIED="1213116749546" TEXT="&#x110;&#x1ec3; &#x1ea9;n ho&#x1eb7;c hi&#x1ec7;n thanh l&#x1ec1; tr&#xe1;i, tr&#xea;n tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#x1ec1;n v&#xf9;ng v&#x1ebd;, ch&#x1ecd;n &#x1ea8;n/hi&#x1ec7;n thanh l&#x1ec1; tr&#xe1;i. Thanh c&#xf4;ng c&#x1ee5; bi&#x1ec3;u t&#x1b0;&#x1ee3;ng n&#x1eb1;m b&#xea;n tr&#xe1;i s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c &#x1ea9;n &#x111;i ho&#x1eb7;c hi&#x1ec7;n ra."/>
<node CREATED="1124560950717" ID="Freemind_Link_1660196267" MODIFIED="1213116794303" TEXT="C&#xe1;c bi&#x1ec3;u t&#x1b0;&#x1ee3;ng c&#xf3; trong Freemind...">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1996597932" MODIFIED="1213142775692" POSITION="right" TEXT="Th&#xea;m li&#xea;n k&#x1ebf;t &#x111;&#x1ed3; ho&#x1ea1;">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1935222880" MODIFIED="1213142775699" TEXT="&#x110;&#x1ec3; t&#x1ea1;o li&#xea;n k&#x1ebf;t &#x111;&#x1ed3; ho&#x1ea1; gi&#x1eef;a 2 n&#xfa;t, k&#xe9;o m&#x1ed9;t n&#xfa;t v&#xe0; th&#x1ea3; n&#xf3; v&#xe0;o m&#x1ed9;t n&#xfa;t kh&#xe1;c trong khi gi&#x1eef; Shift + Control; nh&#x1ea3; chu&#x1ed9;t ra tr&#x1b0;&#x1edb;c khi nh&#x1ea3; Shift + Control.">
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="255;0;" ID="Freemind_Arrow_Link_1428344028" STARTARROW="None" STARTINCLINATION="255;0;"/>
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_215630885" MODIFIED="1213142775723" TEXT="C&#xe1;ch kh&#xe1;c: k&#xe9;o v&#xe0; th&#x1ea3; b&#x1eb1;ng chu&#x1ed9;t ph&#x1ea3;i.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_208378337" MODIFIED="1213142775728" TEXT="&#x110;&#x1ec3; thay &#x111;&#x1ed5;i m&#xe0;u s&#x1eaf;c cho li&#xea;n k&#x1ebf;t, m&#x1edf; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a li&#xea;n k&#x1ebf;t, b&#x1eb1;ng c&#xe1;ch nh&#x1eaf;p chu&#x1ed9;t ph&#x1ea3;i v&#xe0;o li&#xea;n k&#x1ebf;t.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1484370636" MODIFIED="1213142775750" TEXT="Ta c&#x169;ng c&#xf3; th&#x1ec3; thay &#x111;&#x1ed5;i h&#xec;nh m&#x169;i t&#xea;n cho li&#xea;n k&#x1ebf;t qua tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_220023730" MODIFIED="1213142775754" TEXT="&#x110;&#x1ec3; xo&#xe1; li&#xea;n k&#x1ebf;t, c&#x169;ng m&#x1edf; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xf3; v&#xe0; ch&#x1ecd;n Xo&#xe1; b&#x1ecf; m&#x169;i t&#xea;n.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_266716332" MODIFIED="1213142775760" TEXT="&#x110;&#x1ec3; di chuy&#x1ec3;n t&#x1edb;i m&#x1ed9;t trong hai &#x111;&#x1ea7;u li&#xea;n k&#x1ebf;t, m&#x1edf; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh v&#xe0; ch&#x1ecd;n n&#xfa;t c&#x1ea7;n chuy&#x1ec3;n t&#x1edb;i.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1015289745" MODIFIED="1213142775765" TEXT="&#x110;&#x1ec3; thay &#x111;&#x1ed5;i &#x111;&#x1b0;&#x1edd;ng &#x111;i c&#x1ee7;a li&#xea;n k&#x1ebf;t m&#x169;i t&#xea;n, b&#x1ea5;m chu&#x1ed9;t v&#xe0;o v&#xe0; di chuy&#x1ec3;n n&#xf3; &#x111;i.">
<arrowlink COLOR="#b0b0b0" DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="256;22;" ID="Freemind_Arrow_Link_1273596772" STARTARROW="None" STARTINCLINATION="244;32;"/>
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_178300422" MODIFIED="1213142775769" TEXT="M&#x1ed9;t v&#xed; d&#x1ee5; v&#x1ec1; li&#xea;n k&#x1ebf;t &#x111;&#x1ed3; ho&#x1ea1; &#x111;&#x1b0;&#x1ee3;c cho b&#xea;n d&#x1b0;&#x1edb;i.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_8762214" MODIFIED="1213142775774" TEXT="V&#xed; d&#x1ee5;">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1170112929" MODIFIED="1213116827285" TEXT="Li&#xea;n k&#x1ebf;t t&#x1edb;i m&#x1ed9;t ph&#x1ea7;n kh&#xe1;c">
<arrowlink COLOR="#9999ff" DESTINATION="_Freemind_Link_1492563156" ENDARROW="Default" ENDINCLINATION="91;0;" ID="Freemind_Arrow_Link_33407992" STARTARROW="Default" STARTINCLINATION="30;0;"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_974447884" MODIFIED="1213116849324" TEXT="N&#xfa;t c&#xf3; c&#xe1;c n&#xfa;t con &#x111;&#x1b0;&#x1ee3;c thu g&#x1ecd;n">
<node CREATED="1124560950717" ID="_Freemind_Link_1492563156" MODIFIED="1213116855618" TEXT="N&#xfa;t con"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1370577235" MODIFIED="1213116839655" TEXT="M&#x1ed9;t li&#xea;n k&#x1ebf;t n&#x1eef;a">
<arrowlink DESTINATION="_Freemind_Link_1170112929" ENDARROW="Default" ENDINCLINATION="61;0;" ID="Freemind_Arrow_Link_1872050149" STARTARROW="None" STARTINCLINATION="61;0;"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_423038022" MODIFIED="1212778439962" POSITION="right" TEXT="T&#xec;m ki&#x1ebf;m">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_84535966" MODIFIED="1213141954974" TEXT="&#x110;&#x1ec3; t&#xec;m v&#x103;n b&#x1ea3;n tr&#xea;n m&#x1ed9;t n&#xfa;t v&#xe0; c&#xe1;c n&#xfa;t c&#x1ea5;p th&#x1ea5;p h&#x1a1;n &#x1ee9;ng v&#x1edb;i n&#xf3;, nh&#x1ea5;n Ctrl + F ho&#x1eb7;c ch&#x1ecd;n N&#xfa;t &gt; T&#xec;m trong tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1130258952" MODIFIED="1213142001656" TEXT="&#x110;&#x1ec3; t&#xec;m chu&#x1ed7;i k&#x1ebf; ti&#x1ebf;p kh&#x1edb;p v&#x1edb;i m&#x1eab;u c&#x1ea7;n t&#xec;m, nh&#x1ea5;n Ctrl + G ho&#x1eb7;c ch&#x1ecd;n N&#xfa;t &gt; T&#xec;m ti&#x1ebf;p trong tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh..">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1114059074" MODIFIED="1213142043703" TEXT="&#x110;&#x1ec3; t&#xec;m m&#x1ed9;t chu&#x1ed7;i trong to&#xe0;n b&#x1ed9; s&#x1a1; &#x111;&#x1ed3;, chuy&#x1ec3;n v&#x1ec1; n&#xfa;t g&#x1ed1;c b&#x1eb1;ng c&#xe1;ch nh&#x1ea5;n Escape r&#x1ed3;i th&#x1ef1;c hi&#x1ec7;n t&#xec;m ki&#x1ebf;m."/>
<node CREATED="1124560950717" ID="Freemind_Link_794462371" MODIFIED="1213142155849" TEXT="Qu&#xe1; tr&#xec;nh t&#xec;m ki&#x1ebf;m di&#x1ec5;n ra theo chi&#x1ec1;u r&#x1ed9;ng, t&#x1ee9;c l&#xe0; t&#xec;m t&#x1eeb; c&#x1ea5;p cao xu&#x1ed1;ng c&#xe1;c c&#x1ea5;p th&#x1ea5;p h&#x1a1;n, &#x111;&#x1ec3; ph&#xf9; h&#x1ee3;p v&#x1edb;i nguy&#xea;n t&#x1eaf;c c&#x1ee7;a s&#x1a1; &#x111;&#x1ed3; t&#x1b0; duy: c&#x1ea5;p th&#x1ea5;p t&#x1b0;&#x1a1;ng &#x1ee9;ng v&#x1edb;i c&#xe1;c kh&#xe1;i ni&#x1ec7;m, v&#x1ea5;n &#x111;&#x1ec1; chi ti&#x1ebf;t h&#x1a1;n c&#x1ea5;p cao."/>
<node CREATED="1124560950717" ID="Freemind_Link_878322173" MODIFIED="1213142204880" TEXT="L&#x1b0;u &#xfd; r&#x1eb1;ng qu&#xe1; tr&#xec;nh t&#xec;m ki&#x1ebf;m ch&#x1ec9; b&#x1eaf;t &#x111;&#x1ea7;u t&#x1eeb; n&#xfa;t &#x111;&#x1b0;&#x1ee3;c ch&#x1ecd;n v&#xe0; bao g&#x1ed3;m c&#xe1;c n&#xfa;t c&#x1ea5;p th&#x1ea5;p h&#x1a1;n."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_653540280" MODIFIED="1212778434777" POSITION="right" TEXT="Ch&#x1ecd;n nhi&#x1ec1;u n&#xfa;t">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1882743579" MODIFIED="1213142239676" TEXT="&#x110;&#x1ec3; ch&#x1ecd;n nhi&#x1ec1;u n&#xfa;t, b&#x1ea5;m chu&#x1ed9;t tr&#xe1;i l&#xea;n ch&#xfa;ng trong l&#xfa;c gi&#x1eef; CTRL ho&#x1eb7;c SHIFT.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1587507778" MODIFIED="1213142284583" TEXT="&#x110;&#x1ec3; ch&#x1ecd;n th&#xea;m m&#x1ed9;t n&#xfa;t khi &#x111;&#xe3; ch&#x1ecd;n c&#xe1;c n&#xfa;t kh&#xe1;c r&#x1ed3;i, gi&#x1eef; CTRL khi b&#x1ea5;m chu&#x1ed9;t l&#xea;n n&#xfa;t m&#x1edb;i.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_397848217" MODIFIED="1213142354321" TEXT="&#x110;&#x1ec3; ch&#x1ecd;n nhi&#x1ec1;u n&#xfa;t li&#xea;n ti&#x1ebf;p nhau, gi&#x1eef; SHIFT khi b&#x1ea5;m chu&#x1ed9;t, ho&#x1eb7;c gi&#x1eef; SHIFT v&#xe0; nh&#x1ea5;n c&#xe1;c ph&#xed;m m&#x169;i t&#xea;n &#x111;&#x1ec3; di chuy&#x1ec3;n qua c&#xe1;c n&#xfa;t c&#x1ea7;n ch&#x1ecd;n.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_45178554" MODIFIED="1213142456318" TEXT="&#x110;&#x1ec3; ch&#x1ecd;n to&#xe0;n b&#x1ed9; m&#x1ed9;t n&#xfa;t v&#xe0; c&#xe1;c n&#xfa;t c&#x1ea5;p th&#x1ea5;p h&#x1a1;n n&#xfa;t &#x111;&#xf3;, gi&#x1eef; ALT v&#xe0; chu&#x1ed9;t tr&#xe1;i v&#xe0;o n&#xfa;t c&#x1ea7;n ch&#x1ecd;n, ho&#x1eb7;c gi&#x1eef; SHIFT r&#x1ed3;i d&#xf9;ng c&#xe1;c m&#x169;i t&#xea;n &#x111;&#x1ec3; di chuy&#x1ec3;n t&#x1edb;i n&#xfa;t cha c&#x1ee7;a n&#xfa;t hi&#x1ec7;n th&#x1edd;i."/>
<node CREATED="1124560950717" ID="Freemind_Link_1368745556" MODIFIED="1213142486704" TEXT="&#x110;&#x1ec3; b&#x1ecf; ch&#x1ecd;n, b&#x1ea5;m chu&#x1ed9;t tr&#xe1;i l&#xea;n n&#x1ec1;n ho&#x1eb7;c ch&#x1ecd;n m&#x1ed9;t n&#xfa;t kh&#xe1;c."/>
<node CREATED="1124560950717" ID="Freemind_Link_253575646" MODIFIED="1213142658924" TEXT="&#x110;&#x1ec3; ch&#x1ecd;n t&#x1ea5;t c&#x1ea3; c&#xe1;c n&#xfa;t nh&#xec;n th&#x1ea5;y, ch&#x1ecd;n Ch&#x1ec9;nh s&#x1eed;a &gt; Ch&#x1ecd;n m&#x1ecd;i th&#x1ee9; &#x111;ang &#x111;&#x1b0;&#x1ee3;c hi&#x1ec7;n."/>
<node CREATED="1124560950717" ID="Freemind_Link_1045127422" MODIFIED="1213142682545" TEXT="&#x110;&#x1ec3; ch&#x1ecd;n t&#x1ea5;t c&#x1ea3; c&#xe1;c n&#xfa;t &#x111;ang nh&#xec;n th&#x1ea5;y tr&#xea;n 1 nh&#xe1;nh, ch&#x1ecd;n Ch&#x1ec9;nh s&#x1eed;a &gt; Ch&#x1ecd;n nh&#xe1;nh &#x111;ang &#x111;&#x1b0;&#x1ee3;c hi&#x1ec7;n."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1024903226" MODIFIED="1212778428135" POSITION="right" TEXT="K&#xe9;o v&#xe0; th&#x1ea3;">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1929297435" MODIFIED="1213142829417" TEXT="Di chuy&#x1ec3;n n&#xfa;t b&#x1eb1;ng c&#xe1;ch k&#xe9;o v&#xe0; th&#x1ea3; n&#xf3; ra v&#x1ecb; tr&#xed; m&#x1edb;i.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_642775932" MODIFIED="1213142985511" TEXT="&#x110;&#x1ec3; &#x111;&#x1b0;a 1 n&#xfa;t th&#xe0;nh n&#xfa;t con c&#x1ee7;a 1 n&#xfa;t kh&#xe1;c, &#x111;&#x1eb7;t con tr&#x1ecf; &#x1edf; r&#xec;a ngo&#xe0;i c&#x1ee7;a n&#xfa;t &#x111;&#xed;ch khi th&#x1ea3; chu&#x1ed9;t.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_64428371" MODIFIED="1213142990694" TEXT="&#x110;&#x1ec3; &#x111;&#x1b0;a 1 n&#xfa;t th&#xe0;nh n&#xfa;t anh c&#x1ee7;a 1 n&#xfa;t kh&#xe1;c, ta th&#x1ea3; chu&#x1ed9;t &#x1edf; r&#xec;a tr&#xea;n c&#x1ee7;a n&#xfa;t &#x111;&#xed;ch.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1994214827" MODIFIED="1213143025301" TEXT="&#x110;&#x1ec3; sao ch&#xe9;p n&#xfa;t thay v&#xec; di chuy&#x1ec3;n, gi&#x1eef; th&#xea;m CTRL l&#xfa;c k&#xe9;o chu&#x1ed9;t, ho&#x1eb7;c k&#xe9;o chu&#x1ed9;t gi&#x1eef;a thay v&#xec; chu&#x1ed9;t tr&#xe1;i.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1473452780" MODIFIED="1213143083293" TEXT="&#x110;&#x1ec3; s&#x1eed;a l&#x1ea1;i m&#x1ed9;t s&#x1a1; &#x111;&#x1ed3; &#x111;&#xe3; c&#xf3;, k&#xe9;o t&#x1ead;p tin t&#x1b0;&#x1a1;ng &#x1ee9;ng v&#xe0; th&#x1ea3; v&#xe0;o tr&#xea;n n&#x1ec1;n c&#x1eed;a s&#x1ed5; FreeMind; thao t&#xe1;c n&#xe0;y ho&#x1ea1;t &#x111;&#x1ed9;ng t&#x1ed1;t tr&#xea;n n&#x1ec1;n Microsoft Windows."/>
<node CREATED="1124560950717" ID="Freemind_Link_1807305640" MODIFIED="1213143106012" TEXT="&#x110;&#x1ec3; t&#x1ea1;o li&#xea;n k&#x1ebf;t &#x111;&#x1ed3; ho&#x1ea1;, k&#xe9;o v&#xe0; th&#x1ea3; b&#x1eb1;ng chu&#x1ed9;t ph&#x1ea3;i."/>
<node CREATED="1124560950717" ID="Freemind_Link_1852229635" MODIFIED="1213143134718" TEXT="N&#x1ebf;u &#x111;&#xe3; ch&#x1ecd;n nhi&#x1ec1;u n&#xfa;t, t&#x1ea5;t c&#x1ea3; ch&#xfa;ng s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c di chuy&#x1ec3;n ho&#x1eb7;c sao ch&#xe9;p.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_367758036" MODIFIED="1213143194162" TEXT="C&#xf3; th&#x1ec3; k&#xe9;o d&#x1eef; li&#x1ec7;u t&#x1eeb; c&#xe1;c &#x1ee9;ng d&#x1ee5;ng b&#xea;n ngo&#xe0;i nh&#x1b0; c&#xe1;c t&#x1ead;p tin tr&#xea;n Microsoft Windows, ho&#x1eb7;c v&#x103;n b&#x1ea3;n &#x111;&#x1b0;&#x1ee3;c ch&#x1ecd;n tr&#xea;n Mozilla Firefox."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_958781924" MODIFIED="1212778423691" POSITION="right" TEXT="Ch&#xe9;p v&#xe0; d&#xe1;n">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1119887646" MODIFIED="1213143293638" TEXT="C&#xf3; th&#x1ec3; sao ch&#xe9;p v&#xe0; d&#xe1;n nhi&#x1ec1;u n&#xfa;t gi&#x1eef;a 2 s&#x1a1; &#x111;&#x1ed3; trong Freemind. Ngo&#xe0;i ra, c&#xf2;n c&#xf3; th&#x1ec3; d&#xe1;n v&#x103;n b&#x1ea3;n ho&#x1eb7;c HTML t&#x1eeb; c&#xe1;c &#x1ee9;ng d&#x1ee5;ng kh&#xe1;c v&#xe0;o trong Freemind.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_601715130" MODIFIED="1213143371309" TEXT="N&#x1ebf;u d&#xe1;n v&#x103;n b&#x1ea3;n th&#xf4;, c&#xe1;c v&#x103;n b&#x1ea3;n c&#xf3; nhi&#x1ec1;u d&#xf2;ng s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c chuy&#x1ec3;n th&#xe0;nh nhi&#x1ec1;u n&#xfa;t, m&#x1ed7;i n&#xfa;t &#x1ee9;ng v&#x1edb;i m&#x1ed9;t d&#xf2;ng, v&#xe0; c&#x1ea5;p c&#x1ee7;a c&#xe1;c n&#xfa;t &#x111;&#xf3; &#x111;&#x1b0;&#x1ee3;c &#x111;&#x1eb7;t theo s&#x1ed1; k&#xfd; t&#x1ef1; tr&#x1ed1;ng n&#x1eb1;m &#x1edf; &#x111;&#x1ea7;u d&#xf2;ng. Xem v&#xed; d&#x1ee5; sau."/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1360620372" MODIFIED="1124560950717" TEXT="Tree&#xa;     Oak&#xa;     Beech&#xa;     ">
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_235754153" MODIFIED="1213143389208" TEXT="S&#x1ebd; th&#xe0;nh">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1241327831" MODIFIED="1124560950717" TEXT="Tree">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Oak">
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Beech">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_469573315" MODIFIED="1213143486411" TEXT="Khi ta d&#xe1;n HTML, n&#x1ed9;i dung HTML s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c chuy&#x1ec3;n v&#x1ec1; d&#x1ea1;ng v&#x103;n b&#x1ea3;n th&#xf4;. Ngo&#xe0;i ra, c&#xe1;c li&#xea;n k&#x1ebf;t c&#xf3; trong &#x111;&#xf3; s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c chuy&#x1ec3;n th&#xe0;nh n&#xfa;t con c&#x1ee7;a m&#x1ed9;t n&#xfa;t t&#xea;n l&#xe0; &quot;Links&quot;. Xem v&#xed; d&#x1ee5; sau."/>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1169179618" MODIFIED="1213143507547" TEXT="V&#xed; d&#x1ee5; sau khi d&#xe1;n:">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Shopping (120236)">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Urban Living (19)">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1859471211" MODIFIED="1124560950717" TEXT="Links">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" LINK="http://directory.google.com/Top/Shopping/" MODIFIED="1124560950717" TEXT="Shopping">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950717" LINK="http://directory.google.com/Top/Home/Urban_Living/" MODIFIED="1124560950717" TEXT="Urban Living">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_88012936" MODIFIED="1213143568897" TEXT="N&#x1ebf;u d&#xe1;n t&#x1ead;p tin t&#x1eeb; c&#x1eed;a s&#x1ed5; Explorer tr&#xea;n Microsoft Windows, m&#x1ed9;t danh s&#xe1;ch c&#xe1;c li&#xea;n k&#x1ebf;t t&#x1edb;i t&#x1ead;p tin s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c t&#x1ea1;o ra."/>
<node CREATED="1124560950717" ID="Freemind_Link_1257690332" MODIFIED="1213143656088" TEXT="N&#x1ebf;u trong FreeMind b&#x1ea1;n ch&#xe9;p m&#x1ed9;t nh&#xe1;nh v&#xe0; d&#xe1;n n&#xf3; v&#xe0;o m&#x1ed9;t tr&#xec;nh so&#x1ea1;n th&#x1ea3;o v&#x103;n b&#x1ea3;n, c&#x1ea5;u tr&#xfa;c c&#xe2;y s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c bi&#x1ec3;u di&#x1ec5;n b&#x1eb1;ng vi&#x1ec7;c th&#x1ee5;t l&#x1ec1; c&#xe1;c d&#xf2;ng, &#x1ee9;ng v&#x1edb;i c&#xe1;c n&#xfa;t. C&#xe1;c li&#xea;n k&#x1ebf;t s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c &#x111;&#x1eb7;t trong d&#x1ea5;u ngo&#x1eb7;c nh&#x1ecd;n &lt;&gt;. V&#xed; d&#x1ee5; sau."/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_903550993" MODIFIED="1124560950717" TEXT="Tree">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Oak">
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1997185283" MODIFIED="1124560950717" TEXT="Beech">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_511199508" MODIFIED="1213143669976" TEXT="khi d&#xe1;n v&#xe0;o tr&#xec;nh so&#x1ea1;n th&#x1ea3;o s&#x1ebd; th&#xe0;nh">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" MODIFIED="1124560950732" TEXT="Tree&#xa;     Oak&#xa;     Beech&#xa;     Google &lt;http://www.google.com/&gt;&#xa;">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950732" LINK="http://www.google.com/" MODIFIED="1124560950732" TEXT="Google">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1371120807" MODIFIED="1213143824267" TEXT="Khi ch&#xe9;p m&#x1ed9;t nh&#xe1;nh v&#xe0; d&#xe1;n v&#xe0;o m&#x1ed9;t tr&#xec;nh so&#x1ea1;n th&#x1ea3;o v&#x103;n b&#x1ea3;n h&#x1ed7; tr&#x1ee3; v&#x103;n b&#x1ea3;n ph&#x1ee9;c h&#x1ee3;p, c&#xe1;c &#x111;&#x1ecb;nh d&#x1ea1;ng v&#x1ec1; m&#xe0;u s&#x1eaf;c v&#xe0; ph&#xf4;ng ch&#x1eef; c&#x169;ng s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c gi&#x1eef; nguy&#xea;n. C&#xe1;c li&#xea;n k&#x1ebf;t s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c &#x111;&#x1eb7;t trong d&#x1ea5;u ngo&#x1eb7;c &lt;&gt;, nh&#x1b0; l&#xfa;c d&#xe1;n ra v&#x103;n b&#x1ea3;n th&#xf4;. C&#xe1;c tr&#xec;nh so&#x1ea1;n th&#x1ea3;o v&#x103;n b&#x1ea3;n ph&#x1ee9;c h&#x1ee3;p bao g&#x1ed3;m OpenOffice Writer ho&#x1eb7;c Thunderbird."/>
<node CREATED="1124560950732" ID="Freemind_Link_900654975" MODIFIED="1213143965049" TEXT="&#x110;&#x1ec3; ch&#x1ec9; ch&#xe9;p ri&#xea;ng 1 n&#xfa;t, b&#x1ecf; qua c&#xe1;c c&#x1ea5;p con c&#x1ee7;a n&#xfa;t &#x111;&#xf3;, ta nh&#x1ea5;n Ctrl+Shift+C ho&#x1eb7;c ch&#x1ecd;n Ch&#xe9;p ri&#xea;ng trong tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="_Freemind_Link_1540212684" MODIFIED="1212778419527" POSITION="right" TEXT="Di chuy&#x1ec3;n">
<node CREATED="1124560950732" ID="Freemind_Link_1664676263" MODIFIED="1213144031999" TEXT="D&#xf9;ng c&#xe1;c ph&#xed;m m&#x169;i t&#xea;n &#x111;&#x1ec3; di chuy&#x1ec3;n con tr&#x1ecf;."/>
<node CREATED="1124560950732" ID="Freemind_Link_202325925" MODIFIED="1213144090124" TEXT="&#x110;&#x1ec3; v&#x1ec1; n&#xfa;t anh &#x111;&#x1ea7;u ti&#xea;n, nh&#x1ea5;n ph&#xed;m PageUp."/>
<node CREATED="1124560950732" ID="Freemind_Link_733460390" MODIFIED="1213144113022" TEXT="&#x110;&#x1ec3; v&#x1ec1; n&#xfa;t anh cu&#x1ed1;i c&#xf9;ng, nh&#x1ea5;n PageDown."/>
<node CREATED="1124560950732" ID="Freemind_Link_1566432871" MODIFIED="1213144137170" TEXT="&#x110;&#x1ec3; v&#x1ec1; n&#xfa;t g&#x1ed1;c, nh&#x1ea5;n Escape."/>
<node CREATED="1124560950732" ID="_Freemind_Link_97763226" MODIFIED="1213144311905" TEXT="&#x110;&#x1ec3; &#x111;&#x1b0;a n&#xfa;t ra v&#x1ecb; tr&#xed; b&#x1ea5;t k&#x1ef3;, ta b&#x1ea5;m gi&#x1eef; chu&#x1ed9;t l&#xea;n ch&#x1ed1;t v&#xf4; h&#xec;nh (n&#x1eb1;m &#x1edf; m&#xe9;p g&#x1ea7;n n&#xfa;t g&#x1ed1;c h&#x1a1;n), r&#x1ed3;i sau &#x111;&#xf3; di chuy&#x1ec3;n chu&#x1ed9;t ra v&#x1ecb; tr&#xed; kh&#xe1;c."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_4727471" MODIFIED="1213144332539" POSITION="right" TEXT="Thu g&#x1ecd;n v&#xe0; m&#x1edf; r&#x1ed9;ng">
<node CREATED="1124560950732" ID="Freemind_Link_743738104" MODIFIED="1213144387654" TEXT="&#x110;&#x1ec3; thu g&#x1ecd;n m&#x1ed9;t n&#xfa;t, nh&#x1ea5;n ph&#xed;m c&#xe1;ch, ho&#x1eb7;c ch&#x1ecd;n M&#x1edf; r&#x1ed9;ng/Thu g&#x1ecd;n t&#x1eeb; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh."/>
<node CREATED="1124560950732" ID="Freemind_Link_991022370" MODIFIED="1213144430836" TEXT="&#x110;&#x1ec3; m&#x1edf; r&#x1ed9;ng m&#x1ed9;t n&#xfa;t, nh&#x1ea5;n ph&#xed;m c&#xe1;ch, ho&#x1eb7;c ch&#x1ecd;n M&#x1edf; r&#x1ed9;ng/Thu g&#x1ecd;n t&#x1eeb; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh, ho&#x1eb7;c nh&#x1ea5;n ph&#xed;m m&#x169;i t&#xea;n &#x111;&#x1ec3; di chuy&#x1ec3;n theo h&#x1b0;&#x1edb;ng s&#x1ebd; m&#x1edf; r&#x1ed9;ng."/>
<node CREATED="1124560950732" ID="Freemind_Link_769693110" MODIFIED="1213144529528" TEXT="&#x110;&#x1ec3; m&#x1edf; r&#x1ed9;ng ho&#x1eb7;c thu g&#x1ecd;n c&#xe1;c n&#xfa;t theo c&#x1ea5;p, gi&#x1eef; ALT khi xoay chu&#x1ed9;t, ho&#x1eb7;c nh&#x1ea5;n Alt + PageUp v&#xe0; Alt + PageDown. Xin l&#x1b0;u &#xfd; l&#xe0; &#x111;&#x1ed1;i v&#x1edb;i c&#xe1;c s&#x1a1; &#x111;&#x1ed3; l&#x1edb;n, thao t&#xe1;c n&#xe0;y c&#xf3; th&#x1ec3; d&#x1eab;n &#x111;&#x1ebf;n t&#xec;nh tr&#x1ea1;ng treo m&#xe1;y do thi&#x1ebf;u b&#x1ed9; nh&#x1edb;."/>
<node CREATED="1124560950732" ID="Freemind_Link_1851044946" MODIFIED="1213144624887" TEXT="&#x110;&#x1ec3; m&#x1edf; r&#x1ed9;ng t&#x1ea5;t c&#x1ea3; c&#xe1;c n&#xfa;t, nh&#x1ea5;n d&#x1ea5;u c&#x1ed9;ng m&#xe0;u x&#xe1;m &#x1edf; tr&#xea;n thanh c&#xf4;ng c&#x1ee5; ch&#xed;nh, ho&#x1eb7;c ch&#x1ecd;n Di chuy&#x1ec3;n &gt; M&#x1edf; r&#x1ed9;ng t&#x1ea5;t."/>
<node CREATED="1124560950732" ID="Freemind_Link_1144518569" MODIFIED="1213144671055" TEXT="&#x110;&#x1ec3; thu g&#x1ecd;n t&#x1ea5;t c&#x1ea3; c&#xe1;c n&#xfa;t, nh&#x1ea5;n d&#x1ea5;u tr&#x1eeb; m&#xe0;u x&#xe1;m &#x1edf; tr&#xea;n thanh c&#xf4;ng c&#x1ee5; ch&#xed;nh, ho&#x1eb7;c ch&#x1ecd;n Di chuy&#x1ec3;n &gt; Thu g&#x1ecd;n t&#x1ea5;t."/>
<node CREATED="1124560950732" ID="Freemind_Link_1949931044" MODIFIED="1213144696139" TEXT="C&#xe1;c n&#xfa;t &#x111;&#x1b0;&#x1ee3;c thu g&#x1ecd;n s&#x1ebd; c&#xf3; d&#x1ea5;u tr&#xf2;n n&#x1eb1;m &#x1edf; m&#xe9;p ngo&#xe0;i."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_516331171" MODIFIED="1213144715606" POSITION="right" TEXT="Chuy&#x1ec3;n sang s&#x1a1; &#x111;&#x1ed3; kh&#xe1;c">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_888544630" MODIFIED="1213144763417" TEXT="&#x110;&#x1ec3; chuy&#x1ec3;n sang m&#x1ed9;t s&#x1a1; &#x111;&#x1ed3; kh&#xe1;c &#x111;&#xe3; m&#x1edf;, b&#x1ea5;m chu&#x1ed9;t ph&#x1ea3;i l&#xea;n n&#x1ec1;n v&#xe0; ch&#x1ecd;n t&#xea;n s&#x1a1; &#x111;&#x1ed3; m&#xec;nh c&#x1ea7;n t&#x1eeb; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh hi&#x1ec7;n ra.">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_467411537" MODIFIED="1213144773265" POSITION="right" TEXT="Cu&#x1ed9;n s&#x1a1; &#x111;&#x1ed3;">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1417375329" MODIFIED="1213144844934" TEXT="&#x110;&#x1ec3; cu&#x1ed9;n s&#x1a1; &#x111;&#x1ed3;, h&#xe3;y b&#x1ea5;m chu&#x1ed9;t l&#xea;n n&#x1ec1;n v&#xe0; di chu&#x1ed9;t, ho&#x1eb7;c xoay chu&#x1ed9;t. &#x110;&#x1ec3; cu&#x1ed9;n ngang, gi&#x1eef; SHIFT ho&#x1eb7;c m&#x1ed9;t n&#xfa;t tr&#xe1;i chu&#x1ed9;t, r&#x1ed3;i xoay b&#xe1;nh l&#x103;n.">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913137192" MODIFIED="1213144874260" POSITION="right" TEXT="Thu ph&#xf3;ng">
<node CREATED="1124560950732" ID="Freemind_Link_937668100" MODIFIED="1213144923043" TEXT="&#x110;&#x1ec3; ph&#xf3;ng to ho&#x1eb7;c thu nh&#x1ecf;, h&#xe3;y xoay chu&#x1ed9;t khi gi&#x1eef; CTRL, ho&#x1eb7;c nh&#x1ea5;n Alt + m&#x169;i t&#xea;n l&#xea;n/xu&#x1ed1;ng. Ho&#x1eb7;c, ta c&#xf3; th&#x1ec3; &#x111;&#x1eb7;t l&#x1ea1;i gi&#xe1; tr&#x1ecb; thu ph&#xf3;ng &#x1edf; tr&#xea;n thanh c&#xf4;ng c&#x1ee5;."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1318678369" MODIFIED="1213144941248" POSITION="right" TEXT="Hu&#x1ef7; b&#x1b0;&#x1edb;c v&#xe0; l&#xe0;m l&#x1ea1;i">
<node CREATED="1124560950732" ID="Freemind_Link_1059130241" MODIFIED="1213144971907" TEXT="&#x110;&#x1ec3; hu&#x1ef7; c&#xe1;c thao t&#xe1;c l&#xe0;m nh&#x1ea7;m, sai, h&#xe3;y nh&#x1ea5;n CTRL + Z, ho&#x1eb7;c ch&#x1ecd;n Ch&#x1ec9;nh s&#x1eed;a &gt; Hu&#x1ef7; b&#x1b0;&#x1edb;c."/>
<node CREATED="1124560950732" ID="Freemind_Link_844042911" MODIFIED="1213145001824" TEXT="&#x110;&#x1ec3; l&#xe0;m l&#x1ea1;i m&#x1ed9;t thao t&#xe1;c v&#x1eeb;a hu&#x1ef7;, nh&#x1ea5;n CTRL + Y, ho&#x1eb7;c ch&#x1ecd;n Ch&#x1ec9;nh s&#x1eed;a &gt; L&#xe0;m l&#x1ea1;i."/>
<node CREATED="1124560950732" ID="Freemind_Link_988819426" MODIFIED="1213145037790" TEXT="M&#x1edf; C&#xf4;ng c&#x1ee5; &gt; Tu&#x1ef3; th&#xed;ch... &#x111;&#x1ec3; &#x111;&#x1eb7;t s&#x1ed1; b&#x1b0;&#x1edb;c l&#x1b0;u trong b&#x1ed9; nh&#x1edb;, cho ph&#xe9;p hu&#x1ef7; ho&#x1eb7;c l&#xe0;m l&#x1ea1;i."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_22510332" MODIFIED="1212779034059" POSITION="right" TEXT="Xu&#x1ea5;t ra HTML">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1318019585" MODIFIED="1212779122174" TEXT="&#x110;&#x1ec3; xu&#x1ea5;t m&#x1ed9;t nh&#xe1;nh ra HTML, nh&#x1ea5;n Control + H. Trang HTML &#x111;&#x1b0;&#x1ee3;c xu&#x1ea5;t ra c&#xf3; th&#x1ec3; h&#x1ed7; tr&#x1ee3; thu g&#x1ecd;n tu&#x1ef3; theo thi&#x1ebf;t l&#x1ead;p trong ph&#x1ea7;n tu&#x1ef3; th&#xed;ch."/>
<node CREATED="1124560950732" ID="Freemind_Link_330882549" MODIFIED="1212779172290" TEXT="&#x110;&#x1ec3; xu&#x1ea5;t ra &#x111;&#x1ecb;nh d&#x1ea1;ng kh&#xe1;c, ch&#x1ecd;n Xu&#x1ea5;t &gt; D&#x1ea1;ng XHTML (c&#xf3; Javascript)."/>
<node CREATED="1124560950732" ID="Freemind_Link_113578015" MODIFIED="1213145075384" TEXT="&#x110;&#x1ec3; xu&#x1ea5;t s&#x1a1; &#x111;&#x1ed3; ra m&#x1ed9;t &#x1ea3;nh t&#x1ed5;ng h&#x1ee3;p d&#x1ea1;ng HTML, ch&#x1ecd;n Xu&#x1ea5;t &gt; D&#x1ea1;ng XHTML (s&#x1a1; &#x111;&#x1ed3; &#x1ea3;nh c&#xf3; th&#x1ec3; t&#x1b0;&#x1a1;ng t&#xe1;c)."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1908686168" MODIFIED="1213145110531" POSITION="right" TEXT="Xu&#x1ea5;t th&#xe0;nh &#x1ea3;nh bitmap ho&#x1eb7;c vector">
<node CREATED="1124560950732" ID="Freemind_Link_1262228561" MODIFIED="1213145144072" TEXT="&#x110;&#x1ec3; xu&#x1ea5;t ra d&#x1ea1;ng &#x1ea3;nh PNG, ch&#x1ecd;n T&#x1ead;p tin &gt; Xu&#x1ea5;t &gt; D&#x1ea1;ng PNG..."/>
<node CREATED="1124560950732" ID="Freemind_Link_168834767" MODIFIED="1213145167124" TEXT="&#x110;&#x1ec3; xu&#x1ea5;t ra d&#x1ea1;ng &#x1ea3;nh JPEG, ch&#x1ecd;n T&#x1ead;p tin &gt; Xu&#x1ea5;t &gt; D&#x1ea1;ng JPEG..."/>
<node CREATED="1124560950732" ID="Freemind_Link_1754131207" MODIFIED="1213145208051" TEXT="&#x110;&#x1ec3; xu&#x1ea5;t ra d&#x1ea1;ng &#x1ea3;nh SVG, ch&#x1ecd;n T&#x1ead;p tin &gt; Xu&#x1ea5;t &gt; D&#x1ea1;ng SVG... L&#x1b0;u &#xfd; l&#xe0; ph&#x1ea3;i c&#xe0;i tr&#xec;nh b&#x1ed5; sung SVG th&#xec; ch&#x1ee9;c n&#x103;ng n&#xe0;y m&#x1edb;i ho&#x1ea1;t &#x111;&#x1ed9;ng."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_329770204" MODIFIED="1213145242092" POSITION="right" TEXT="Xu&#x1ea5;t ra c&#xe1;c &#x111;&#x1ecb;nh d&#x1ea1;ng XML kh&#xe1;c">
<node CREATED="1124560950732" ID="Freemind_Link_109825007" MODIFIED="1213145325307" TEXT="&#x110;&#x1ec3; xu&#x1ea5;t s&#x1a1; &#x111;&#x1ed3; th&#xe0;nh m&#x1ed9;t &#x111;&#x1ecb;nh d&#x1ea1;ng XML kh&#xe1;c, b&#x1ea1;n ph&#x1ea3;i c&#xf3; m&#x1ed9;t b&#x1ed9; l&#x1ecd;c XSLT, r&#x1ed3;i ch&#x1ecd;n T&#x1ead;p tin &gt; Xu&#x1ea5;t &gt; D&#xf9;ng XSLT."/>
<node CREATED="1124560950732" ID="Freemind_Link_1007437950" MODIFIED="1213145380613" TEXT="&#x110;&#x1ec3; xu&#x1ea5;t s&#x1a1; &#x111;&#x1ed3; th&#xe0;nh t&#xe0;i li&#x1ec7;u OpenOffice Writer, ta ch&#x1ecd;n T&#x1ead;p tin &gt; Xu&#x1ea5;t &gt; D&#x1ea1;ng t&#xe0;i li&#x1ec7;u c&#x1ee7;a OpenOffice Writer."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1841136119" MODIFIED="1213145416657" POSITION="right" TEXT="Nh&#x1ead;p c&#x1ea5;u tr&#xfa;c c&#xe2;y th&#x1b0; m&#x1ee5;c">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1609103531" MODIFIED="1213145506249" TEXT="&#x110;&#x1ec3; nh&#x1ead;p c&#x1ea5;u tr&#xfa;c th&#x1b0; m&#x1ee5;c, trong tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh c&#x1ee7;a n&#xfa;t, ta ch&#x1ecd;n Nh&#xe1;nh &gt; Nh&#x1ead;p c&#x1ea5;u tr&#xfa;c th&#x1b0; m&#x1ee5;c. Ch&#x1ecd;n th&#x1b0; m&#x1ee5;c c&#x1ea7;n nh&#x1ead;p. M&#x1ecd;i t&#x1ead;p tin v&#xe0; th&#x1b0; m&#x1ee5;c con trong &#x111;&#xf3; s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c &#x111;&#x1b0;a v&#xe0;o s&#x1a1; &#x111;&#x1ed3;. Xem v&#xed; d&#x1ee5; b&#xea;n d&#x1b0;&#x1edb;i."/>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_122139198" MODIFIED="1213145516875" TEXT="V&#xed; d&#x1ee5;">
<font NAME="Dialog" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_802327256" MODIFIED="1213145527709" TEXT="Th&#x1b0; m&#x1ee5;c &#x111;&#x1b0;&#x1ee3;c ch&#x1ecd;n">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" LINK="C:\Program Files\Microsoft Office\Office\Bitmaps" MODIFIED="1124560950732" TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_945130228" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/" MODIFIED="1124560950732" TEXT="Dbwiz">
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/ASSETS.GIF" MODIFIED="1124560950732" TEXT="ASSETS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF" MODIFIED="1124560950732" TEXT="CONTACTS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF" MODIFIED="1124560950732" TEXT="EVTMGMT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF" MODIFIED="1124560950732" TEXT="EXPENSES.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF" MODIFIED="1124560950732" TEXT="INVENTRY.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/LEDGER.GIF" MODIFIED="1124560950732" TEXT="LEDGER.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF" MODIFIED="1124560950732" TEXT="ORDPROC.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF" MODIFIED="1124560950732" TEXT="RESOURCE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/SERVICE.GIF" MODIFIED="1124560950732" TEXT="SERVICE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF" MODIFIED="1124560950732" TEXT="TIMEBILL.GIF"/>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1154399846" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/" MODIFIED="1124560950732" TEXT="Styles">
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF" MODIFIED="1124560950732" TEXT="ACBLENDS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF" MODIFIED="1124560950732" TEXT="ACBLUPRT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF" MODIFIED="1124560950732" TEXT="ACEXPDTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF" MODIFIED="1124560950732" TEXT="ACINDSTR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF" MODIFIED="1124560950732" TEXT="ACRICEPR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF" MODIFIED="1124560950732" TEXT="ACSNDSTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF" MODIFIED="1124560950732" TEXT="ACSUMIPT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_269203785" MODIFIED="1213324088093" POSITION="right" TEXT="Nh&#x1ead;p c&#xe1;c li&#xea;n k&#x1ebf;t &#x1b0;a th&#xed;ch trong Internet Explorer">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_960597950" MODIFIED="1213324188687" TEXT="&#x110;&#x1ec3; nh&#x1ead;p c&#xe1;c li&#xea;n k&#x1ebf;t hay d&#xf9;ng t&#x1eeb; th&#x1b0; m&#x1ee5;c Favorites c&#x1ee7;a Internet Explorer v&#xe0;o FreeMind, ch&#x1ecd;n T&#x1ead;p tin &gt; Nh&#x1ead;p &gt; Explorer Favorites. Ch&#x1b0;&#x1a1;ng tr&#xec;nh s&#x1ebd; y&#xea;u c&#x1ea7;u b&#x1ea1;n nh&#x1ead;p v&#xe0;o th&#x1b0; m&#x1ee5;c ch&#x1ee9;a c&#xe1;c li&#xea;n k&#x1ebf;t hay d&#xf9;ng. Th&#xf4;ng th&#x1b0;&#x1edd;ng, th&#x1b0; m&#x1ee5;c n&#xe0;y t&#xea;n l&#xe0; &quot;Favorites&quot; v&#xe0; n&#x1eb1;m trong C:\Documents and Settings\&lt;t&#xea;n ng&#x1b0;&#x1edd;i d&#xf9;ng&gt;\Favorites."/>
<node COLOR="#999999" CREATED="1124560950732" MODIFIED="1124560950732" TEXT="Key words: Microsoft Internet Explorer, MSIE, MS IE.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1709974530" MODIFIED="1213323992859" POSITION="right" TEXT="Nh&#x1ead;p c&#xe1;c s&#x1a1; &#x111;&#x1ed3; t&#x1ea1;o b&#x1edf;i MindManager X5">
<node CREATED="1124560950732" ID="Freemind_Link_1792019047" MODIFIED="1213324055812" TEXT="&#x110;&#x1ec3; nh&#x1ead;p c&#xe1;c s&#x1a1; &#x111;&#x1ed3; &#x111;&#x1b0;&#x1ee3;c t&#x1ea1;o b&#x1edf;i ch&#x1b0;&#x1a1;ng tr&#xec;nh MindManager X5, h&#xe3;y ch&#x1ecd;n T&#x1ead;p tin &gt; Nh&#x1ead;p &gt; S&#x1a1; &#x111;&#x1ed3; MindManager X5."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913645795" MODIFIED="1213324219031" POSITION="right" TEXT="Li&#xea;n k&#x1ebf;t v&#x1edb;i Word ho&#x1eb7;c Outlook">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_387394810" MODIFIED="1213324313156" TEXT="Ta c&#xf3; th&#x1ec3; d&#xe1;n s&#x1a1; &#x111;&#x1ed3; ho&#x1eb7;c nh&#xe1;nh m&#xec;nh c&#x1ea7;n v&#xe0;o Microsoft Word, Wordpad hay Outlook. N&#xf3;i chung, m&#x1ecd;i &#x1ee9;ng d&#x1ee5;ng x&#x1eed; l&#xfd; &#x111;&#x1b0;&#x1ee3;c v&#x103;n b&#x1ea3;n ph&#x1ee9;c h&#x1ee3;p &#x111;&#x1ec1;u h&#x1ed7; tr&#x1ee3; vi&#x1ec7;c d&#xe1;n d&#x1eef; li&#x1ec7;u t&#x1eeb; Freemind. &#x110;&#x1ecb;nh d&#x1ea1;ng v&#x103;n b&#x1ea3;n c&#x169;ng nh&#x1b0; li&#xea;n k&#x1ebf;t s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c gi&#x1eef; nguy&#xea;n khi d&#xe1;n.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1374270907" LINK="mailto:don.bonton@supermail.com" MODIFIED="1213324547937" TEXT="B&#x1ea5;m chu&#x1ed9;t l&#xea;n m&#x1ed9;t li&#xea;n k&#x1ebf;t th&#x1b0; &#x111;i&#x1ec7;n t&#x1eed; (nh&#x1b0; mailto:don.bonton@supermail.com), Freemind s&#x1ebd; m&#x1edf; ch&#x1b0;&#x1a1;ng tr&#xec;nh so&#x1ea1;n th&#x1b0; m&#x1eb7;c &#x111;&#x1ecb;nh tr&#xea;n m&#xe1;y b&#x1ea1;n (tr&#xea;n Windows c&#xf3; th&#x1ec3; l&#xe0; Outlook) &#x111;&#x1ec3; so&#x1ea1;n th&#x1b0; t&#x1edb;i &#x111;&#x1ecb;a ch&#x1ec9; &#x111;&#xf3;.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1769132615" LINK="mailto:don.bonton@supermail.com?subject=Last phone call" MODIFIED="1213324576125" TEXT="Ta c&#xf3; th&#x1ec3; vi&#x1ebf;t ti&#xea;u &#x111;&#x1ec1; cho th&#x1b0; n&#x1ebf;u mu&#x1ed1;n"/>
<node CREATED="1124560950732" ID="Freemind_Link_608770378" MODIFIED="1213324621296" TEXT="M&#x1ed9;t c&#xe1;ch kh&#xe1;c &#x111;&#x1ec3; d&#xe1;n s&#x1a1; &#x111;&#x1ed3; v&#xe0;o Microsoft Word l&#xe0; xu&#x1ea5;t s&#x1a1; &#x111;&#x1ed3; ra HTML d&#x1ef1;a v&#xe0;o ti&#xea;u &#x111;&#x1ec1;, sau &#x111;&#xf3; d&#xe1;n n&#x1ed9;i dung HTML v&#xe0;o Word."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1822195277" MODIFIED="1213145687123" POSITION="right" TEXT="Thi&#x1ebf;t l&#x1ead;p c&#xe1;c tu&#x1ef3; ch&#x1ec9;nh">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1709388931" MODIFIED="1213145817507" TEXT="&#x110;&#x1ec3; s&#x1eed;a c&#xe1;c tu&#x1ef3; ch&#x1ec9;nh, ta m&#x1edf; C&#xf4;ng c&#x1ee5; &gt; Tu&#x1ef3; th&#xed;ch... Th&#xf4;ng th&#x1b0;&#x1edd;ng, c&#xe1;c thi&#x1ebf;t l&#x1ead;p s&#x1ebd; c&#xf3; t&#xe1;c d&#x1ee5;ng &#x1edf; l&#x1ea7;n ch&#x1ea1;y sau."/>
<node CREATED="1124560950732" ID="Freemind_Link_516597155" MODIFIED="1213145826421" TEXT="Tu&#x1ef3; th&#xed;ch bao g&#x1ed3;m ph&#xed;m t&#x1eaf;t b&#xe0;n ph&#xed;m, ph&#x1b0;&#x1a1;ng th&#x1ee9;c xu&#x1ea5;t HTML, th&#x1edd;i gian ch&#x1edd; tr&#x1b0;&#x1edb;c khi t&#x1ef1; &#x111;&#x1ed9;ng ch&#x1ecd;n n&#xfa;t b&#xea;n d&#x1b0;&#x1edb;i chu&#x1ed9;t, ph&#x1b0;&#x1a1;ng ph&#xe1;p l&#xe0;m tr&#x1a1;n c&#x1ea1;nh..."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1528828442" MODIFIED="1213145851893" POSITION="right" TEXT="In &#x1ea5;n">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_562577939" MODIFIED="1213145923515" TEXT="Ta c&#xf3; th&#x1ec3; in to&#xe0;n b&#x1ed9; s&#x1a1; &#x111;&#x1ed3; ra 1 trang gi&#x1ea5;y, ho&#x1eb7;c in ra nhi&#x1ec1;u trang kh&#xe1;c nhau. &#x110;&#x1ec3; s&#x1eed;a thi&#x1ebf;t l&#x1ead;p in, ta ch&#x1ecd;n T&#x1ead;p tin &gt; Thi&#x1ebf;t l&#x1ead;p trang..."/>
<node CREATED="1124560950732" ID="Freemind_Link_1781825973" MODIFIED="1213146012396" TEXT="&#x110;&#x1ec3; ti&#x1ebf;t ki&#x1ec7;m kh&#xf4;ng gian, n&#xea;n ch&#x1ecd;n in ngang (landscape) trong ph&#x1ea7;n Thi&#x1ebf;t l&#x1ead;p trang.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1966612586" MODIFIED="1213146160197" TEXT="Ta c&#x169;ng c&#xf3; th&#x1ec3; xu&#x1ea5;t s&#x1a1; &#x111;&#x1ed3; ra HTML r&#x1ed3;i m&#x1edf; b&#x1eb1;ng tr&#xec;nh duy&#x1ec7;t v&#xe0; in t&#x1eeb; tr&#xec;nh duy&#x1ec7;t c&#x1ee7;a m&#xec;nh, ho&#x1eb7;c ch&#xe9;p s&#x1a1; &#x111;&#x1ed3; v&#xe0;o Writer v&#xe0; in ra. Ta c&#xf3; th&#x1ec3; ch&#x1ecd;n xu&#x1ea5;t HTML c&#xf3; ti&#xea;u &#x111;&#x1ec1;, ch&#xe9;p v&#xe0; d&#xe1;n v&#xe0;o Writer r&#x1ed3;i in t&#x1eeb; &#x111;&#xf3;. B&#x1eb1;ng c&#xe1;ch n&#xe0;y, ta c&#xf3; th&#x1ec3; hi&#x1ec7;u &#x111;&#xed;nh v&#x103;n b&#x1ea3;n k&#x1ef9; h&#x1a1;n tr&#x1b0;&#x1edb;c khi in.">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_841140408" MODIFIED="1213146186256" POSITION="right" TEXT="D&#xf9;ng v&#x103;n b&#x1ea3;n ph&#x1ee9;c h&#x1ee3;p d&#x1ea1;ng HTML trong n&#xfa;t">
<node CREATED="1124560950732" ID="Freemind_Link_1923265571" MODIFIED="1213146241846" TEXT="N&#xfa;t &#x111;&#x1b0;&#x1ee3;c m&#x1edf; &#x111;&#x1ea7;u b&#x1eb1;ng th&#x1ebb; &lt;html&gt; s&#x1ebd; &#x111;&#x1b0;&#x1ee3;c l&#x1ecd;c b&#x1eb1;ng ng&#xf4;n ng&#x1eef; HTML. T&#xed;nh n&#x103;ng n&#xe0;y ch&#x1ec9; th&#x1ef1;c s&#x1ef1; h&#x1eef;u d&#x1ee5;ng v&#x1edb;i nh&#x1eef;ng ng&#x1b0;&#x1edd;i d&#xf9;ng bi&#x1ebf;t HTML. Xem v&#xed; d&#x1ee5;."/>
<node CREATED="1124560950732" ID="Freemind_Link_1221553642" MODIFIED="1213146447870" TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;h3&gt;&#xa;      V&#xed; d&#x1ee5; v&#x1ec1; vi&#x1ec7;c d&#xf9;ng HTML&#xa;    &lt;/h3&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      T&#x1ea1;o danh s&#xe1;ch:&#xa;    &lt;/p&gt;&#xa;    &lt;ul type=&quot;disc&quot;&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;M&#x1ee5;c 1&#xa;      &lt;/li&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;M&#x1ee5;c 2&#xa;      &lt;/li&gt;&#xa;    &lt;/ul&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Ta c&#xf2;n c&#xf3; th&#x1ec3; &#x111;&#x1ecb;nh d&#x1ea1;ng &lt;b&gt;ch&#x1eef; &#x111;&#x1ead;m&lt;/b&gt; ho&#x1eb7;c &lt;i&gt;ch&#x1eef; nghi&#xea;ng&lt;/i&gt;. Ti&#x1ebf;p,  &lt;u&gt;g&#x1ea1;ch ch&#xe2;n&lt;/u&gt;, &lt;strike&gt;g&#x1ea1;ch ngang&lt;/strike&gt; n&#x1eef;a! Th&#x1ead;m ch&#xed;, k&#x1ebb; b&#x1ea3;ng:&#xa;    &lt;/p&gt;&#xa;    &lt;table cellpadding=&quot;0&quot; style=&quot;border: none&quot; class=&quot;msonormaltable&quot; border=&quot;1&quot; cellspacing=&quot;0&quot;&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;border: solid windowtext 1.0pt; padding-left: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-top: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;&#xd4; th&#x1ee9; nh&#x1ea5;t&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border: solid windowtext 1.0pt; border-left: none; padding-left: .75pt; padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;&#xd4; th&#x1ee9; hai&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;border: solid windowtext 1.0pt; border-top: none; padding-left: .75pt; padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;&#xd4; th&#x1ee9; ba&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border-bottom: solid windowtext 1.0pt; border-top: none; border-left: none; padding-left: .75pt; padding-right: .75pt; border-right: solid windowtext 1.0pt; padding-top: .75pt; padding-bottom: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;&#xd4; th&#x1ee9; t&#x1b0;&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;    &lt;/table&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      V&#x1ec1; m&#xe0;u s&#x1eaf;c ch&#x1eef;: &#x111;&#x1eb7;t &lt;font color=&quot;#999900&quot;&gt;m&#xe0;u&lt;/font&gt; &lt;font color=&quot;#336600&quot;&gt;cho ch&#x1eef;&lt;/font&gt;.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;&#xa;"/>
<node CREATED="1124560950732" ID="Freemind_Link_1411363315" MODIFIED="1213146533998" TEXT="Khi xu&#x1ea5;t s&#x1a1; &#x111;&#x1ed3; ra v&#x103;n b&#x1ea3;n ph&#x1ee9;c h&#x1ee3;p, c&#xe1;c thu&#x1ed9;c t&#xed;nh HTML s&#x1ebd; b&#x1ecb; b&#x1ecf; qua. Tuy nhi&#xea;n, vi&#x1ec7;c d&#xf9;ng HTML trong n&#xfa;t &#x111;&#x1b0;&#x1ee3;c h&#x1ed7; tr&#x1ee3; r&#x1ea5;t t&#x1ed1;t khi &#x111;&#x1b0;a s&#x1a1; &#x111;&#x1ed3; l&#xea;n m&#x1ea1;ng b&#x1eb1;ng c&#xe1;ch nh&#xfa;ng ti&#x1ec3;u d&#x1ee5;ng Freemind v&#xe0;o tr&#xec;nh duy&#x1ec7;t.">
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_384678455" MODIFIED="1213146556028" POSITION="right" TEXT="Th&#xea;m &#x1ea3;nh v&#xe0;o n&#xfa;t">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_105057297" MODIFIED="1213146685402" TEXT="&#x110;&#x1ec3; ch&#xe8;n &#x1ea3;nh v&#xe0;o trong FreeMind, nh&#x1ea5;n Alt + K, ho&#x1eb7;c ch&#x1ecd;n Ch&#xe8;n &gt; &#x1ea2;nh t&#x1eeb; tr&#xec;nh &#x111;&#x1a1;n ng&#x1eef; c&#x1ea3;nh. Khi ch&#xe8;n &#x1ea3;nh, m&#x1ecd;i v&#x103;n b&#x1ea3;n c&#xf3; trong n&#xfa;t s&#x1ebd; b&#x1ecb; xo&#xe1; b&#x1ecf;. Tuy nhi&#xea;n, ta kh&#xf4;ng th&#x1ec3; ch&#xe9;p &#x1ea3;nh v&#xe0; d&#xe1;n v&#xe0;o c&#xe1;c &#x1ee9;ng d&#x1ee5;ng kh&#xe1;c, c&#x169;ng nh&#x1b0; xu&#x1ea5;t &#x1ea3;nh ra HTML. Do v&#x1ead;y, n&#xea;n h&#x1ea1;n ch&#x1ebf; d&#xf9;ng ch&#x1ee9;c n&#x103;ng n&#xe0;y."/>
<node CREATED="1124560950732" ID="Freemind_Link_831132288" MODIFIED="1213146701653" TEXT="C&#xe1;c &#x111;&#x1ecb;nh d&#x1ea1;ng &#x1ea3;nh &#x111;&#x1b0;&#x1ee3;c h&#x1ed7; tr&#x1ee3; l&#xe0; PNG, JPEG v&#xe0; GIF."/>
<node CREATED="1124560950732" ID="Freemind_Link_657212533" MODIFIED="1213146790423" TEXT="&#x110;&#x1ec3; chuy&#xea;n li&#xea;n k&#x1ebf;t t&#x1edb;i &#x1ea3;nh th&#xe0;nh &#x1ea3;nh, ta nh&#x1ea5;n Alt + K. Ho&#x1eb7;c, k&#xe9;o v&#xe0; th&#x1ea3; m&#x1ed9;t v&#xe0;i t&#x1ea5;m &#x1ea3;nh v&#xe0;o trong FreeMind &#x111;&#x1ec3; t&#x1ea1;o c&#xe1;c li&#xea;n k&#x1ebf;t t&#x1edb;i ch&#xfa;ng, sau &#x111;&#xf3; ch&#x1ecd;n li&#xea;n k&#x1ebf;t v&#xe0; chuy&#x1ec3;n th&#xe0;nh &#x1ea3;nh (Alt + K)."/>
<node COLOR="#000000" CREATED="1124560950732" ID="Freemind_Link_812648089" MODIFIED="1213146838256" TEXT="M&#x1ed9;t c&#xe1;ch kh&#xe1;c l&#xe0; d&#xf9;ng th&#x1ebb; &lt;html&gt; &#x111;&#x1ec3; &#x111;&#x1ecb;nh d&#x1ea1;ng n&#x1ed9;i dung n&#xfa;t d&#x1b0;&#x1edb;i d&#x1ea1;ng HTML, r&#x1ed3;i ch&#xe8;n &#x1ea3;nh b&#x1eb1;ng th&#x1ebb; &lt;img&gt;.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_854977241" MODIFIED="1213146881574" TEXT="V&#xed; d&#x1ee5;:&#xa; &lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;&#xa; &lt;html&gt;&lt;img src=&quot;file://C:/Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;&#xa;">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_1503495647" MODIFIED="1213146897671" TEXT="C&#xf3; th&#x1ec3; &#x111;&#x1eb7;t li&#xea;n k&#x1ebf;t t&#x1b0;&#x1a1;ng &#x111;&#x1ed1;i t&#x1edb;i &#x1ea3;nh.">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_842741213" MODIFIED="1213146941114" TEXT="V&#xed; d&#x1ee5; v&#x1ec1; &#x1ea3;nh, ch&#x1ea1;y tr&#xea;n Windows">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" MODIFIED="1124560950732" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF&quot;&gt;"/>
<node CREATED="1124560950732" MODIFIED="1124560950732" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF&quot;&gt;"/>
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_138986292" MODIFIED="1124560950732" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF&quot;&gt;">
<node CREATED="1124560950732" MODIFIED="1124560950732" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF&quot;&gt;"/>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_675267710" MODIFIED="1124560950732" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF&quot;&gt;">
<node CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_801785253" MODIFIED="1124560950732" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF&quot;&gt;">
<node CREATED="1124560950732" MODIFIED="1124560950732" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF&quot;&gt;"/>
</node>
</node>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1382863138" MODIFIED="1213324652078" POSITION="right" TEXT="D&#xf9;ng ch&#x1ee9;c n&#x103;ng kh&#xf3;a t&#x1ead;p tin (th&#x1eed; nghi&#x1ec7;m)">
<node CREATED="1124560950732" ID="Freemind_Link_417147004" MODIFIED="1213324731875" TEXT="Phi&#xea;n b&#x1ea3;n hi&#x1ec7;n th&#x1edd;i c&#x1ee7;a FreeMind c&#xf3; ch&#x1ee9;c n&#x103;ng kh&#xf3;a t&#x1ead;p tin, nh&#x1b0;ng n&#xf3; &#x111;ang trong giai &#x111;o&#x1ea1;n th&#x1eed; nghi&#x1ec7;m, n&#xea;n theo m&#x1eb7;c &#x111;&#x1ecb;nh, t&#xed;nh n&#x103;ng n&#xe0;y b&#x1ecb; t&#x1eaf;t &#x111;i. M&#x1eb7;c d&#xf9; ch&#x1b0;a ho&#xe0;n h&#x1ea3;o, nh&#x1b0;ng t&#xed;nh n&#x103;ng n&#xe0;y &#x111;&#xe3; h&#x1ed7; tr&#x1ee3; h&#x1ea7;u h&#x1ebf;t c&#xe1;c nhu c&#x1ea7;u th&#x1ef1;c t&#x1ebf;."/>
<node CREATED="1124560950732" ID="Freemind_Link_1172860856" MODIFIED="1213324789812" TEXT="Vi&#x1ec7;c kh&#xf3;a t&#x1ead;p tin gi&#xfa;p &#x111;&#x1ea3;m b&#x1ea3;o r&#x1eb1;ng nhi&#x1ec1;u ng&#x1b0;&#x1edd;i d&#xf9;ng kh&#xf4;ng th&#x1ec3; &#x111;&#x1ed3;ng th&#x1edd;i s&#x1eed;a &#x111;&#x1ed5;i c&#xf9;ng 1 s&#x1a1; &#x111;&#x1ed3;, ng&#x103;n kh&#xf4;ng cho ng&#x1b0;&#x1edd;i n&#xe0;y s&#x1eed;a &#x111;&#x1ed5;i th&#xf4;ng tin ng&#x1b0;&#x1edd;i kia v&#x1eeb;a t&#x1ea1;o ra."/>
<node CREATED="1124560950732" ID="Freemind_Link_772992782" MODIFIED="1213324807812" TEXT="&#x110;&#x1ec3; m&#x1edf; ch&#x1ee9;c n&#x103;ng n&#xe0;y, b&#x1ea1;n ch&#x1ecd;n C&#xf4;ng c&#x1ee5; &gt; T&#xf9;y th&#xed;ch."/>
</node>
</node>
</map>
